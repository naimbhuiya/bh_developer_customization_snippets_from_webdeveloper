<?php
function bhdcsfw_admin_enqueue_styles_scripts() {
    
    // Enqueue Bootstrap CSS

    wp_enqueue_style('bootstrap', 'https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css');
    
    // Enqueue Bootstrap JavaScript (after jQuery)
    wp_enqueue_script('jquery');
    wp_enqueue_script('bhdcsfw-script-parsonal_dettils', plugin_dir_url(__FILE__) . 'asset/js/script.js', array(), '1.0.0', true);
    wp_enqueue_script('bootstrap-js', 'https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js', array(), null, true);
    
    }
    add_action('admin_enqueue_scripts', 'bhdcsfw_admin_enqueue_styles_scripts');

//plugin deshboard work function
function bhdcsfw_menu_page_function(){
    profile_admin_function();
}

/** 
* inclueds admin php file
*/    
    // Profile admin file inclueded... 
    require_once(plugin_dir_path(__FILE__) . 'profile_admin/profile_admin.php');
    // Profile admin file inclueded... 
    require_once(plugin_dir_path(__FILE__) . 'ads_admin/ads_admin.php');
