<?php 



register_nav_menu('mobile-sliding-menu' , __('Mobile Sliding Menu'));

function bhwd_slid_out_nav_admin_menu() {
    add_submenu_page(
        'bhdcsfw-bh-customaization',    // Parent menu slug (ensure this menu exists)
        'Slide Out Options',         // Page title
        'Slide Out Options',         // Submenu title
        'manage_options',               // Capability required to access this menu
        'bhwd-slid-out-nav-menu-style',             // Menu slug
        'bhwd_slid_out_nav_menu_style'  // Callback function to display the page content
    );
}
add_action('admin_menu', 'bhwd_slid_out_nav_admin_menu');


function slid_col_bhwd_enque_style() {
    // Enqueue an existing admin CSS handle
    $handle = 'wp-admin'; // This is a core WordPress admin style handle.

    // Enqueue the style if not already included
    wp_enqueue_style($handle);

    // Add your custom inline CSS
    $custom_css = "
		.slid_out_admin_options_container{
		display: flex ;
		flex-wrap: wrap ;
        justify-content: space-between;
        width: 99% ;
		}
        .slid_col_6{
			width: 31.5% ;
			background: #fff ;
			padding: 10px ;
			
		}
		.slid_col_6 label{
			display: block ;
			font-size: 18px ; 
			color: #000 ; 
			margin-top: 10px ;
			margin-bottom: 5px ;
		}
		.slid_col_6 input{
			padding: 5px ;
			display: block ;
			color: #000 ;
			font-size: 16px ;
			width: 100% ;
			height: 40px;
		}
        .slid_col_6 input[type='color'] {
            -webkit-appearance: none; /* Remove default styling for better control */
            -moz-appearance: none;
            appearance: none;
            
            border-radius: 5px;
            
            cursor: pointer;
            padding: 0;
            margin: 0;
            overflow: hidden;
            background-color: transparent;
            
            transition: all 0.3s ease;
        }
		
		.bhwd-custom-style{
			
		}
        
        .bhwd_row{
            display: flex ; 
            justify-content: space-between;
            flex-wrap:  wrap ; 
        }    
        .bhwd_col_12{
            width: 100% ;
        }
        .bhwd_col_6{
            width: 48% ;
        }
        .bhwd_slide_out_style{
        text-align: center;
        font-size: 25px ; 
        }
        ";
    
    // Attach the custom inline CSS
    wp_add_inline_style($handle, $custom_css);
}
add_action('admin_enqueue_scripts', 'slid_col_bhwd_enque_style');






// Menu Item Style Field Function 
function bhwd_menu_item_field_style(){
    ?>
    <div class="bhwd_row">
        <div class="bhwd_col_12">
            <!-- Menu Item Font Size -->
				<label for="bhwd_menu_item_font_size"><?php esc_attr_e('Menu Item Font Size', 'bhwd'); ?></label>
				<input type="number" name="bhwd_menu_item_font_size" value="<?php echo esc_attr(get_option('bhwd_menu_item_font_size')); ?>" placeholder="<?php esc_attr_e('Enter font size in px', 'bhwd'); ?>">
        </div>
        <div class="bhwd_col_6">
            <!-- Menu Item Color -->
				<label for="bhwd_menu_item_color"><?php esc_attr_e('Menu Item Color', 'bhwd'); ?></label>
				<input type="color" name="bhwd_menu_item_color" value="<?php echo esc_attr(get_option('bhwd_menu_item_color')); ?>" placeholder="<?php esc_attr_e('Pick a color', 'bhwd'); ?>">
        </div>
        <div class="bhwd_col_6">
            <!-- Menu Item Background Color -->
				<label for="bhwd_menu_item_bg_color"><?php esc_attr_e('Menu Item Background Color', 'bhwd'); ?></label>
				<input type="color" name="bhwd_menu_item_bg_color" value="<?php echo esc_attr(get_option('bhwd_menu_item_bg_color')); ?>">
        </div>
    </div>
    <?php
}


// Menu Item Border style
function bhwd_menu_item_border_style(){
    ?>
        <h3><?php esc_attr_e('Border Style', 'bhwd'); ?></h3>
        <div class="bhwd_row">
            <div class="bhwd_col_6">
				<!-- Menu Item Border Top -->
				<label for="bhwd_menu_item_border_top"><?php esc_attr_e('Top (px)', 'bhwd'); ?></label>
				<input type="number" name="bhwd_menu_item_border_top" value="<?php echo esc_attr(get_option('bhwd_menu_item_border_top')); ?>" placeholder="<?php esc_attr_e('Enter border width', 'bhwd'); ?>">
            </div>


            <div class="bhwd_col_6">
				<!-- Menu Item Border Colors -->
				<label for="bhwd_menu_item_border_top_color"><?php esc_attr_e('Top', 'bhwd'); ?></label>
				<input type="color" name="bhwd_menu_item_border_top_color" value="<?php echo esc_attr(get_option('bhwd_menu_item_border_top_color')); ?>">
            </div>



            <div class="bhwd_col_6">

                <!-- Menu Item Border Left -->
				<label for="bhwd_menu_item_border_left"><?php esc_attr_e('Left (px)', 'bhwd'); ?></label>
				<input type="number" name="bhwd_menu_item_border_left" value="<?php echo esc_attr(get_option('bhwd_menu_item_border_left')); ?>" placeholder="<?php esc_attr_e('Enter border width', 'bhwd'); ?>">

            </div>



            <div class="bhwd_col_6">
                <label for="bhwd_menu_item_border_left_color"><?php esc_attr_e('Left', 'bhwd'); ?></label>
				<input type="color" name="bhwd_menu_item_border_left_color" value="<?php echo esc_attr(get_option('bhwd_menu_item_border_left_color')); ?>">
            </div>



            <div class="bhwd_col_6">
                <!-- Menu Item Border Bottom -->
				<label for="bhwd_menu_item_border_bottom"><?php esc_attr_e('Bottom (px)', 'bhwd'); ?></label>
				<input type="number" name="bhwd_menu_item_border_bottom" value="<?php echo esc_attr(get_option('bhwd_menu_item_border_bottom')); ?>" placeholder="<?php esc_attr_e('Enter border width', 'bhwd'); ?>">
            </div>



            <div class="bhwd_col_6">
				<label for="bhwd_menu_item_border_bottom_color"><?php esc_attr_e('Bottom', 'bhwd'); ?></label>
				<input type="color" name="bhwd_menu_item_border_bottom_color" value="<?php echo esc_attr(get_option('bhwd_menu_item_border_bottom_color')); ?>">
            </div>




            <div class="bhwd_col_6">
				<!-- Menu Item Border Right -->
				<label for="bhwd_menu_item_border_right"><?php esc_attr_e('Right (px)', 'bhwd'); ?></label>
				<input type="number" name="bhwd_menu_item_border_right" value="<?php echo esc_attr(get_option('bhwd_menu_item_border_right')); ?>" placeholder="<?php esc_attr_e('Enter border width', 'bhwd'); ?>">
            </div>



            <div class="bhwd_col_6">
                <label for="bhwd_menu_item_border_right_color"><?php esc_attr_e('Right', 'bhwd'); ?></label>
				<input type="color" name="bhwd_menu_item_border_right_color" value="<?php echo esc_attr(get_option('bhwd_menu_item_border_right_color')); ?>">
            </div>



            <div class="bhwd_col_12">
                <!-- Border Last Child Border Style -->
				<label for="bhwd_menu_item_border_style_child"><?php esc_attr_e('Border Style Last Child', 'bhwd'); ?></label>
				<input type="text" name="bhwd_menu_item_border_style_child" value="<?php echo esc_attr(get_option('bhwd_menu_item_border_style_child')); ?>" placeholder="<?php esc_attr_e('Enter border width', 'bhwd'); ?>">
            </div>
        </div>

        <!-- Border Hover Style -->
        <h3><?php esc_attr_e('Hover: Border Style', 'bhwd'); ?></h3>
        <div class="bhwd_row">
            <div class="bhwd_col_6">
                <!-- Hover: Menu Item Border Options -->
				<label for="bhwd_menu_item_hover_border_top"><?php esc_attr_e('Top (px)', 'bhwd'); ?></label>
				<input type="number" name="bhwd_menu_item_hover_border_top" value="<?php echo esc_attr(get_option('bhwd_menu_item_hover_border_top')); ?>" placeholder="<?php esc_attr_e('Enter border width', 'bhwd'); ?>">
            </div>
            <div class="bhwd_col_6">
                <!-- Hover: Menu Item Border Colors -->
				<label for="bhwd_menu_item_hover_border_top_color"><?php esc_attr_e('Top', 'bhwd'); ?></label>
				<input type="color" name="bhwd_menu_item_hover_border_top_color" value="<?php echo esc_attr(get_option('bhwd_menu_item_hover_border_top_color')); ?>">
            </div>
            <div class="bhwd_col_6">
                <label for="bhwd_menu_item_hover_border_left"><?php esc_attr_e('Left (px)', 'bhwd'); ?></label>
				<input type="number" name="bhwd_menu_item_hover_border_left" value="<?php echo esc_attr(get_option('bhwd_menu_item_hover_border_left')); ?>" placeholder="<?php esc_attr_e('Enter border width', 'bhwd'); ?>">
            </div>
            <div class="bhwd_col_6">
                <label for="bhwd_menu_item_hover_border_left_color"><?php esc_attr_e('Left', 'bhwd'); ?></label>
				<input type="color" name="bhwd_menu_item_hover_border_left_color" value="<?php echo esc_attr(get_option('bhwd_menu_item_hover_border_left_color')); ?>">
            </div>
            <div class="bhwd_col_6">
                <label for="bhwd_menu_item_hover_border_bottom"><?php esc_attr_e('Bottom (px)', 'bhwd'); ?></label>
				<input type="number" name="bhwd_menu_item_hover_border_bottom" value="<?php echo esc_attr(get_option('bhwd_menu_item_hover_border_bottom')); ?>" placeholder="<?php esc_attr_e('Enter border width', 'bhwd'); ?>">
            </div>
            <div class="bhwd_col_6">
                <label for="bhwd_menu_item_hover_border_bottom_color"><?php esc_attr_e('Bottom', 'bhwd'); ?></label>
				<input type="color" name="bhwd_menu_item_hover_border_bottom_color" value="<?php echo esc_attr(get_option('bhwd_menu_item_hover_border_bottom_color')); ?>">
            </div>
            <div class="bhwd_col_6">
                <label for="bhwd_menu_item_hover_border_right"><?php esc_attr_e('Right (px)', 'bhwd'); ?></label>
				<input type="number" name="bhwd_menu_item_hover_border_right" value="<?php echo esc_attr(get_option('bhwd_menu_item_hover_border_right')); ?>" placeholder="<?php esc_attr_e('Enter border width', 'bhwd'); ?>">
            </div>
            <div class="bhwd_col_6">
                <label for="bhwd_menu_item_hover_border_right_color"><?php esc_attr_e('Right', 'bhwd'); ?></label>
				<input type="color" name="bhwd_menu_item_hover_border_right_color" value="<?php echo esc_attr(get_option('bhwd_menu_item_hover_border_right_color')); ?>">
            </div>
        </div>
    <?php
}

function bhwd_slid_out_nav_menu_style(){
	echo '<h2 class="bhwd_slide_out_style" > Slid out nav options </h2>';
	?>
	<form action="options.php" method="post" >
		<?php wp_nonce_field('update-options'); ?>
		<div class="slid_out_admin_options_container">
			<div class="slid_col_6">
				
				<?php

                    bhwd_menu_item_field_style(); 
                    bhwd_menu_item_border_style();
                 
                 ?>

			</div>
			
			
			<div class="slid_col_6">
				<!-- Menu Container Width -->
				<label for="bhwd_menu_container_width"><?php esc_attr_e('Menu Conainer Width (use anything : px , % , rem , em and others....)', 'bhwd'); ?></label>
				<input type="text" name="bhwd_menu_container_width" value="<?php echo esc_attr(get_option('bhwd_menu_container_width')); ?>" placeholder="<?php esc_attr_e('Menu Conainer Width (use anything : px , % , rem , em and others....)', 'bhwd'); ?>">

			</div>

            <div class="slid_col_6"></div>
			
		</div>
		<div class="bhwd-custom-style" >
				<input type="hidden" name="action" value="update" >
				<input type="hidden" name="page_options" value="bhwd_menu_item_font_size , bhwd_menu_item_color , bhwd_menu_item_bg_color , bhwd_menu_item_border_top , bhwd_menu_item_border_bottom , bhwd_menu_item_border_left , bhwd_menu_item_border_right , bhwd_menu_item_border_top_color , bhwd_menu_item_border_bottom_color , bhwd_menu_item_border_left_color , bhwd_menu_item_border_right_color , bhwd_menu_item_hover_border_top , bhwd_menu_item_hover_border_bottom , bhwd_menu_item_border_style_child , bhwd_menu_item_hover_border_left , bhwd_menu_item_hover_border_right , bhwd_menu_item_hover_border_top_color , bhwd_menu_item_hover_border_bottom_color , bhwd_menu_item_hover_border_left_color , bhwd_menu_item_border_right_color , bhwd_menu_container_width " >
				<input class="button  button-primary" style="margin-top: 15px ;" type="submit" name="submit" value="<?php _e('Save Change' , 'bhwd') ?>" >
			</div>
	</form>
	<?php
}