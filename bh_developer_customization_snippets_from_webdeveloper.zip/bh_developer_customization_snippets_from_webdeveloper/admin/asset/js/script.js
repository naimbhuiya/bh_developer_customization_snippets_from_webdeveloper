const shortcodeListBhdcsfw = {
  bhdcsfw_custom_mobile_ads: "[bhdcsfw_custom_mobile_ads]",
  bhdcsfw_custom_ads: "[bhdcsfw_custom_ads]",
  random_ads_shortcode_desktop: "[random_ads_shortcode_desktop]",
  random_ads_shortcode_mobile: "[random_ads_shortcode_mobile]",
  scheda_clienti: "[scheda-clienti]",
};

document.addEventListener("DOMContentLoaded", () => {
  const shortCodeListBhdcsfw = document.getElementById("shortCodeListBhdcsfw");
  if (shortCodeListBhdcsfw) {
    Object.entries(shortcodeListBhdcsfw).forEach(([key, value]) => {
      const button = document.createElement("button");
      button.className = "btn customButtonStyle btn-warning mb-2 me-2";
      button.innerText = `Click For Copy: ${value}`;
      button.addEventListener("click", () => {
        button.innerText = "Copied...";
        navigator.clipboard
          .writeText(value)
          .then(() => {
            setTimeout(() => {
              button.innerText = `Click To Copy: ${value}`;
            }, 3000);
          })
          .catch((error) => console.error("Error copying text:", error));
      });
      shortCodeListBhdcsfw.appendChild(button);
    });
  } else {
    console.error("Element with ID 'shortCodeListBhdcsfw' not found.");
  }
});
