const shortcodeListBhdcsfw = {
    "bhdcsfw_custom_mobile_ads": "[bhdcsfw_custom_mobile_ads]",
    "bhdcsfw_custom_ads": "[bhdcsfw_custom_ads]"
};

document.addEventListener("DOMContentLoaded", () => {
    const shortCodeListBhdcsfw = document.getElementById("shortCodeListBhdcsfw");
    if (shortCodeListBhdcsfw) {
        Object.entries(shortcodeListBhdcsfw).forEach(([key, value]) => {
            const button = document.createElement("button");
            button.className = "btn btn-warning me-2";
            button.innerText = `Click For Copy: ${value}`;
            button.addEventListener("click", () => {
                button.innerText = "Copied...";
                navigator.clipboard.writeText(value)
                    .then(() => {
                        setTimeout(() => {
                            button.innerText = `Click To Copy: ${value}`;
                        }, 3000);
                    })
                    .catch(error => console.error("Error copying text:", error));
            });
            shortCodeListBhdcsfw.appendChild(button);
        });
    } else {
        console.error("Element with ID 'shortCodeListBhdcsfw' not found.");
    }
});
