<?php

function bhwd_woo_cat_slider() {
	register_post_type('woocat_slider',
		array(
			'labels'      => array(
				'name'          => __( 'Woo Cat Slider', 'textdomain' ),
				'singular_name' => __( 'Woo Cat Slider', 'textdomain' ),
			),
			'public'      => true,
			'has_archive' => true,
			'rewrite'     => array( 'slug' => 'woocat-woocat_slider' ), // my custom slug
            'supports'    => array('title', 'thumbnail'), // Remove editor by excluding 'editor'
		)
	);
}
add_action('init', 'bhwd_woo_cat_slider');


function bhwd_remove_woo_cat_slide_to_editor() {
    remove_post_type_support('woocat_slider', 'editor');
}
add_action('init', 'bhwd_remove_woo_cat_slide_to_editor');

function wporg_add_custom_meta_boxes() {
    add_meta_box(
        'woocat_slider', // Meta box ID
        __('Woo Cat Settings', 'textdomain'), // Title
        'bhwd_woocat_meta_callback', // Callback function
        'woocat_slider', // Post type
        'normal', // Context (side, normal, advanced)
        'default' // Priority
    );
}
add_action('add_meta_boxes', 'wporg_add_custom_meta_boxes');

function bhwd_woocat_meta_callback($post) {
    // Retrieve current values (saved as colon-separated string)
    $selected_cats = get_post_meta($post->ID, '_woo_selected_cats', true);
    $selected_cats = !empty($selected_cats) ? explode(':', $selected_cats) : [];

    // Get WooCommerce categories
    $categories = get_terms([
        'taxonomy'   => 'product_cat',
        'hide_empty' => false,
    ]);

    // Security nonce
    wp_nonce_field('bhwd_product_meta_nonce', 'bhwd_product_meta_nonce_field');

    ?>
    <p>
        <?php 
          echo '<span><strong>Post ID"s: </strong></span>' . get_post_meta( $post->ID, "_woo_selected_cats", true ) . '<br>';
          echo '<span><strong>Post ID: </strong></span>' . $post->ID . '<br>';
        ?>
    </p>
    <p><strong><?php _e('Select WooCommerce Categories:', 'textdomain'); ?></strong></p>
    <ul class="bhwlCategoriesList">
        <?php foreach ($categories as $category) { ?>
            <li class="bhwdCategories ">
                <label>
                    <input type="checkbox" name="woocats_for_slider[]" value="<?php echo esc_attr($category->term_id); ?>" 
                        <?php echo in_array($category->term_id, $selected_cats) ? 'checked' : ''; ?>>
                    <?php echo esc_html($category->name); ?>
                </label>
            </li>
        <?php } ?>
    </ul>
    <?php
}



function bhwd_woo_cat_slider_meta_save($post_id) {
    // Verify nonce
    if (!isset($_POST['bhwd_product_meta_nonce_field']) || 
        !wp_verify_nonce($_POST['bhwd_product_meta_nonce_field'], 'bhwd_product_meta_nonce')) {
        return;
    }

    // Check autosave
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
        return;
    }

    // Check permissions
    if (!current_user_can('edit_post', $post_id)) {
        return;
    }

    // Save selected categories as colon-separated string
    if (isset($_POST['woocats_for_slider']) && is_array($_POST['woocats_for_slider'])) {
        $selected_cats = implode(':', array_map('sanitize_text_field', $_POST['woocats_for_slider']));
        update_post_meta($post_id, '_woo_selected_cats', $selected_cats);
    } else {
        delete_post_meta($post_id, '_woo_selected_cats');
    }
}
add_action('save_post', 'bhwd_woo_cat_slider_meta_save');




