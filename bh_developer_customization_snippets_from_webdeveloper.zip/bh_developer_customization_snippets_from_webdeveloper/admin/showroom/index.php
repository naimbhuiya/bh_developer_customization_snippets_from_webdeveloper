<?php

function bhwd_showroom_carousel_admin_menu() {
    add_submenu_page(
        'bhdcsfw-bh-customaization',            // Parent menu slug
        'Showroom Settings',                    // Page title
        'Showroom Settings',                    // Submenu title
        'manage_options',                       // Capability required
        'bhwd-showroom-settings',               // Menu slug
        'bhwd_showroom_selector_settings_page'  // Callback function
    );
}

add_action('admin_menu', 'bhwd_showroom_carousel_admin_menu');

function bhwd_showroom_selector_settings_page() {
    if (!current_user_can('manage_options')) {
        return;
    }

    // Save the form data when submitted
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        if (isset($_POST['bhwd_showroom_carousel_category'])) {
            update_option('bhwd_showroom_carousel_category', sanitize_text_field($_POST['bhwd_showroom_carousel_category']));
        }
        if (isset($_POST['bhwd_showroom_add_short_code'])) {
            update_option('bhwd_showroom_add_short_code', sanitize_text_field($_POST['bhwd_showroom_add_short_code']));
        }
        if (isset($_POST['bhwd_get_selected_page_slug'])) {
            update_option('bhwd_get_selected_page_slug', sanitize_text_field($_POST['bhwd_get_selected_page_slug']));
        }
        if (isset($_POST['bhwd_showroom_email'])) {
            update_option('bhwd_showroom_email', sanitize_email($_POST['bhwd_showroom_email']));
        }

        // Show the saved message
        echo '<div id="message" class="updated notice is-dismissible"><p>Settings saved.</p></div>';
    }

    // Get saved options
    $selected_category = get_option('bhwd_showroom_carousel_category');
    $selected_form = get_option('bhwd_showroom_add_short_code');
    $selected_page = get_option('bhwd_get_selected_page_slug');
    $contact_email = get_option('bhwd_showroom_email', 'info@disegnarecasa.com');

    ?>
    <div class="wrap">
        <h1>Carousel Settings</h1>
        <form method="post" action="">
            <!-- Category Selector -->
            <label for="bhwd_showroom_carousel_category">Select Carousel Category:</label><br>
            <select name="bhwd_showroom_carousel_category" id="bhwd_showroom_carousel_category">
                <?php
                $categories = get_categories(['taxonomy' => 'category', 'hide_empty' => false]);
                foreach ($categories as $category) {
                    ?>
                    <option value="<?php echo esc_attr($category->slug); ?>" <?php selected($selected_category, $category->slug); ?>>
                        <?php echo esc_html($category->name); ?>
                    </option>
                    <?php
                }
                ?>
            </select>
            <br><br>

            <!-- Contact Form 7 Dropdown Selector -->
            <label for="bhwd_showroom_add_short_code">Select Contact Form:</label><br>
            <select name="bhwd_showroom_add_short_code" id="bhwd_showroom_add_short_code">
                <?php
                $wpcf7_forms = get_posts(['post_type' => 'wpcf7_contact_form', 'posts_per_page' => -1]);
                foreach ($wpcf7_forms as $form) {
                    ?>
                    <option value="<?php echo esc_attr($form->ID); ?>" <?php selected($selected_form, $form->ID); ?>>
                        <?php echo esc_html($form->post_title); ?>
                    </option>
                    <?php
                }
                ?>
            </select>
            <br><br>

            <!-- Page Selector -->
            <label for="bhwd_get_selected_page_slug">Select a Page:</label><br>
            <select name="bhwd_get_selected_page_slug" id="bhwd_get_selected_page_slug">
                <?php
                $pages = get_posts([
                    'post_type'      => 'page',
                    'posts_per_page' => -1,
                    'orderby'        => 'title',
                    'order'          => 'ASC',
                ]);
                foreach ($pages as $page) {
                    $page_slug = $page->post_name;
                    ?>
                    <option value="<?php echo esc_attr($page_slug); ?>" <?php selected($selected_page, $page_slug); ?>>
                        <?php echo esc_html($page->post_title); ?>
                    </option>
                    <?php
                }
                ?>
            </select>
            <br><br>

            <!-- Contact Email -->
            <label for="bhwd_showroom_email">If error, provide contact Email:</label><br>
            <input type="email" name="bhwd_showroom_email" id="bhwd_showroom_email" value="<?php echo esc_attr($contact_email); ?>" placeholder="Enter the contact email">
            <br><br>

            <!-- Save Button -->
            <input type="submit" value="Save" class="button-primary" />
        </form>
    </div>
    <?php
}

function bhwd_showroom_register_settings() {
    register_setting('bhwd_carousel_settings_group', 'bhwd_showroom_carousel_category');
    register_setting('bhwd_carousel_settings_group', 'bhwd_showroom_add_short_code');
    register_setting('bhwd_carousel_settings_group', 'bhwd_get_selected_page_slug');
    register_setting('bhwd_carousel_settings_group', 'bhwd_showroom_email');
}

add_action('admin_init', 'bhwd_showroom_register_settings');
