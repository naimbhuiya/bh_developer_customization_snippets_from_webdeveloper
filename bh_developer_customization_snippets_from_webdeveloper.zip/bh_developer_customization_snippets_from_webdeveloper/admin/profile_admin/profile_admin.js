let token_s = false;
    let isCount = 0;
    document.addEventListener('DOMContentLoaded', function() {
        let bhdcsfw_button_counters = document.getElementById("bhdcsfw-add-emlement-counters");
        let bhdcsfw_remove_button_counters = document.getElementById("bhdcsfw-Remove-emlement-counters");
        let bhdcsfw_count = document.getElementById("bhdcsfw-add-emlement-count");
        let bhdcsfw_err = document.getElementById("bhdcsfw_err");
        let bhdcsfw_Item_count = document.getElementById("bhdcsfw_Item_count");
        let bhdcsfw_save_change_effact = document.getElementById("bhdcsfw_save_change_effact");

        bhdcsfw_button_counters.addEventListener("click", function() {
            let positive_counter = parseInt(bhdcsfw_count.value);
             bhdcsfw_count.value = positive_counter + 1;
             let conterValue = bhdcsfw_count.value 

            bhdcsfw_Item_count.innerText = `Total Item: ${bhdcsfw_count.value}`;
            if(bhdcsfw_count.value < conterValue | bhdcsfw_count.value > conterValue ){
                bhdcsfw_save_change_effact.classList.add("d-block")
                bhdcsfw_save_change_effact.classList.remove("d-none")
            }
        });
        bhdcsfw_remove_button_counters.addEventListener("click", function() {
            if (parseInt(bhdcsfw_count.value) >= 3) {
                bhdcsfw_count.value = parseInt(bhdcsfw_count.value) - 1;
                bhdcsfw_Item_count.innerText = `Total Item: ${bhdcsfw_count.value}`;
            } else {
                token_s = true;
               if(token_s){
                bhdcsfw_err.classList.add("d-block" , "text-muted" , "text-danger" , "bg-light", "text-center" , "rounded" , "p-3" , "mt-2" , "h6")
                bhdcsfw_err.classList.remove("d-none")
                 bhdcsfw_err.innerText = 'Entered Minimum: 2';
                 setTimeout(() => {
                    bhdcsfw_err.classList.add("d-none")
                    bhdcsfw_err.classList.remove("d-block " , "text-muted")
                 }, 2000);
               }
            }
        });
    });