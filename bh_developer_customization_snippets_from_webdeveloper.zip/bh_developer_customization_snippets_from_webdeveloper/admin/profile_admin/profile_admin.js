let tokenS = false;
let itemCount = 0;

document.addEventListener('DOMContentLoaded', function() {
    let addButton = document.getElementById("bhdcsfw-add-emlement-counters");
    let removeButton = document.getElementById("bhdcsfw-Remove-emlement-counters");
    let countInput = document.getElementById("bhdcsfw-add-emlement-count");
    let errorMessage = document.getElementById("bhdcsfw_err");

	if(addButton){
		addButton.addEventListener("click", function() {
        itemCount++;
        countInput.value = itemCount;
        updateItemCountDisplay();
    });
	}
    
	if(removeButton){
		  removeButton.addEventListener("click", function() {
			if (itemCount >= 3) {
				itemCount--;
				countInput.value = itemCount;
				updateItemCountDisplay();
			} else {
				tokenS = true;
				if (tokenS) {
					displayErrorMessage("Entered Minimum: 2");
				}
			}
		});
	}



    function displayErrorMessage(message) {
        if (errorMessage) {
            errorMessage.innerText = message;
            errorMessage.classList.add("d-block", "text-muted", "text-danger", "bg-light", "text-center", "rounded", "p-3", "mt-2", "h6");
            errorMessage.classList.remove("d-none");
            setTimeout(() => {
                errorMessage.classList.add("d-none");
                errorMessage.classList.remove("d-block", "text-muted");
            }, 2000);
        }
    }
});
