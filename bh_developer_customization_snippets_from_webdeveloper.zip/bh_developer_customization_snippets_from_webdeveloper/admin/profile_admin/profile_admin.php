<?php 
// Define a function to enqueue styles and scripts
function bhdcsfw_enqueue_admin_scripts() {
    // Enqueue your styles
    wp_enqueue_style('bhdcsfw-admin-styles', plugin_dir_url(__FILE__) . 'style.css' , array(), '1.0', 'all');

    // Enqueue your scripts
    wp_enqueue_script('bhdcsfw-admin-scripts', plugin_dir_url(__FILE__) . 'profile_admin.js', array('jquery'), '1.0', true);
}

// Hook the function to the admin_enqueue_scripts action
add_action('admin_enqueue_scripts', 'bhdcsfw_enqueue_admin_scripts');
function profile_admin_function(){ $clck_for_copy = 'Click For Copy'; ?>
<form action="options.php" method="post">
  <?php wp_nonce_field( 'update-options' ); ?>
    <div class="container-fluid">
       <div class="row">
<!--             <div class="col-md-12">
                   <?php
                    #STYLESHEET TEXT ARIYA EXIQUTION 
                   // custom_css_editor_page_BHD() ; ?>
            </div> -->
            <div class="col-md-6">
                   <!-- TITLE COLOR CHANGING FIELDS -->
                   <label 
                       class="bhdcsfw-label_styling"  
                       for="bhdcsfw-title-color" 
                       name='bhdcsfw-title-color' >
                       <?php print esc_attr( "Title Color" ); ?>
                   </label>
                   <input 
                       class="bhdcsfw-input-fields form-control border border-info"  
                       type="color" 
                       name="bhdcsfw-title-color" 
                       value="<?php print get_option( 'bhdcsfw-title-color' ); ?>" >    
                   <!-- TITLE BACKGROUND COLOR CHANGING FIELDS -->
                   <label 
                       class="bhdcsfw-label_styling border border-info" 
                       for="bhdcsfw-title-background-color" 
                       name='bhdcsfw-title-background-color' >
                       <?php print esc_attr( "Title Background Color" ); ?>
                   </label>
                   <input 
                       class="bhdcsfw-input-fields form-control border border-info"  
                       type="color" 
                       name="bhdcsfw-title-background-color" 
                       value="<?php print get_option( 'bhdcsfw-title-background-color' ); ?>" >    
                   <!-- TITLE FONT-SIZE CHANGING FIELDS -->
                   <label 
                       class="bhdcsfw-label_styling"  
                       for="bhdcsfw-title-fontsize" 
                       name='bhdcsfw-title-fontsize' >
                       <?php print esc_attr( "Title Font size (px)" ); ?>
                   </label>
                   <input 
                       class="bhdcsfw-input-fields form-control border border-info"  
                       type="number" 
                       name="bhdcsfw-title-fontsize" 
                       value="<?php print get_option( 'bhdcsfw-title-fontsize' ); ?>" 
                       placeholder="Enter Desktop Font size" > 
                   <!-- TITLE MOBILE FONT-SIZE CHANGING FIELDS -->
                   <label 
                       class="bhdcsfw-label_styling" 
                       for="bhdcsfw-title-mobile-fontsize" 
                       name='bhdcsfw-title-mobile-fontsize' >
                       <?php print esc_attr( "Title Mobile Font size (px)" ); ?>
                   </label>
                   <input 
                       class="bhdcsfw-input-fields form-control border border-info"  
                       type="number" 
                       name="bhdcsfw-title-mobile-fontsize" 
                       value="<?php print get_option( 'bhdcsfw-title-mobile-fontsize' ); ?>" 
                       placeholder="Enter Mobile Font size" >    
                   <!-- TITLE MOBILE font-family CHANGING FIELDS -->
                   <label 
                       class="bhdcsfw-label_styling" 
                       for="bhdcsfw-font-family" 
                       name='bhdcsfw-font-family' >
                       <?php print esc_attr( "Title font-family ( 'Poppins', sans-serif )" ); ?>
                   </label>
                   <input 
                       class="bhdcsfw-input-fields form-control border border-info" 
                       type="text" 
                       name="bhdcsfw-font-family" 
                       value="<?php print get_option( 'bhdcsfw-font-family' ); ?>" 
                       placeholder="Enter font-family" >
                    
                       <?php
                        #RECENT PRODUCT GRID ADMIN FUNCTION
                        bhd_recent_product_admin_panel() ?>
            </div>
            <div class="col-md-6">
                   <!-- TITLE MOBILE FONT-SIZE CHANGING FIELDS -->
                   <label 
                       class="bhdcsfw-label_styling " 
                       for="bhdcsfw-title-mobile-fontsize" 
                       name='bhdcsfw-title-mobile-fontsize' >
                       <?php print esc_attr( "Title Mobile Font size (px)" ); ?>
                   </label>
                   <input 
                       class="bhdcsfw-input-fields form-control border border-info"  
                       type="number" 
                       name="bhdcsfw-title-mobile-fontsize" 
                       value="<?php print get_option( 'bhdcsfw-title-mobile-fontsize' ); ?>" 
                       placeholder="Enter Mobile Font size" >    
                   <!-- TITLE DESKTOP FONT-WEIGHT CHANGING FIELDS -->
                   <label 
                       class="bhdcsfw-label_styling" 
                       for="bhdcsfw-title-font-weight" 
                       name='bhdcsfw-title-font-weight' >
                       <?php print esc_attr( "Title Desktop Font Weight" ); ?>
                   </label>
                   <input 
                       class="bhdcsfw-input-fields form-control border border-info"  
                       type="number" 
                       name="bhdcsfw-title-font-weight" 
                       value="<?php print get_option( 'bhdcsfw-title-font-weight' ); ?>" 
                       placeholder="Title Desktop Font Weight" min="400" >   
                   <?php echo bhdcsfw_ads_admin_function(); // ADS Admin function called ?> 
               </div>
		   <div class="col-md-12">
			   <?php echo custom_css_editor_page_BHD(); ?>
		   </div>
           </div>
        <!-- BUTTONS AND SECURITY FIELDS -->
        <input type="hidden" name="action" value="update" >
        <input type="hidden" name="page_options" value="bhdcsfw-title-color , bhdcsfw-title-background-color , bhdcsfw-title-fontsize , bhdcsfw-title-mobile-fontsize , bhdcsfw-title-mobile-font-weight , bhdcsfw-title-font-weight , bhdcsfw-add-emlement-count , <?php bhdcsfw_page_option_return(); ?> ,  <?php fieldNameReturnFromRecentProductAdmin() ?> , bhdcsfw-custom-stylesheet-BHD " >
        <input class="bhdcsfw-save-change-buttons btn btn-primary mt-3 e-button e-button" type="submit" name="submit" value="<?php _e( 'Save Changes' , 'bhdcsfw' ); ?>">
    </div>
</form>
<div>
	
   
</div>
<?php } ?>