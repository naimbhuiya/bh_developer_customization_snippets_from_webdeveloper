<?php
function custom_admin_scripts() {
    wp_enqueue_style('codemirror-css', 'https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.7/codemirror.min.css');
    wp_enqueue_style('codemirror-theme-material', 'https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.7/theme/material.min.css');
    wp_enqueue_script('jquery');
    wp_enqueue_script('codemirror-js', 'https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.7/codemirror.min.js', array('jquery'), null, true);
    wp_enqueue_script('codemirror-css-js', 'https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.7/mode/css/css.min.js', array('codemirror-js'), null, true);
    wp_enqueue_script('codemirror-lint-js', 'https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.7/addon/lint/lint.min.js', array('codemirror-js'), null, true);
    wp_enqueue_script('codemirror-css-lint-js', 'https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.7/addon/lint/css-lint.min.js', array('codemirror-lint-js'), null, true);
    wp_enqueue_style('codemirror-lint-css', 'https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.7/addon/lint/lint.min.css');
}
add_action('admin_enqueue_scripts', 'custom_admin_scripts');

function custom_css_editor_page_BHD() {
    ?>
    <div class="" style="margin-bottom: 25px;" >
        <label class="bhdcsfw-label_styling" for="bhdcsfw-custom-stylesheet-BHD">
            <?php esc_attr_e("Custom Css Code"); ?>
        </label>               
        <textarea id="code-editor" class="height-100 border  border-info" name="bhdcsfw-custom-stylesheet-BHD"><?php echo esc_textarea(get_option('bhdcsfw-custom-stylesheet-BHD')); ?></textarea>
    </div>
    <script>
        jQuery(document).ready(function ($) {
            var editor = CodeMirror.fromTextArea(document.getElementById("code-editor"), {
                lineNumbers: true,
                mode: "css",
                theme: "material",
                gutters: ["CodeMirror-lint-markers"],
                lint: true
            });
        });
    </script>
    <?php
}

// add_action('admin_menu', 'bhd_add_custom_css_submenu');

// function bhd_add_custom_css_submenu() {
//     // Add submenu under the custom parent menu slug 'bhdcsfw-bh-customaization'
//     add_submenu_page(
//         'bhdcsfw-bh-customaization',    // Parent menu slug
//         'Custom CSS Editor',            // Page title
//         'Custom CSS',                   // Submenu title
//         'manage_options',               // Capability
//         'custom-css-editor',            // Menu slug
//         'custom_css_editor_page_BHD'    // Callback function to display the page
//     );
// }