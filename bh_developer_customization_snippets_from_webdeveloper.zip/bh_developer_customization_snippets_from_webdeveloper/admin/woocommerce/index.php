<?php
// Add a submenu item for custom category selection under a WooCommerce customization menu
function bhwd_add_wc_admin_menu() {
    add_submenu_page(
        'bhdcsfw-bh-customaization',    // Parent menu slug (ensure this menu exists)
        'Woocommerce Settings',         // Page title
        'Woocommerce Settings',         // Submenu title
        'manage_options',               // Capability required to access this menu
        'wo-carasoul-bhwd',             // Menu slug
        'bhwd_category_selector_settings_page'  // Callback function to display the page content
    );
}
add_action('admin_menu', 'bhwd_add_wc_admin_menu');

// Settings page HTML content
function bhwd_category_selector_settings_page() {
    ?>
    <div class="wrap">
        <h1>Select a Category and Enter Text</h1>
        <form method="post" action="options.php">
            <?php
                // Register and display the necessary fields
                settings_fields('bhwd_settings_group');  
                do_settings_sections('bhwd-category-selector');
                submit_button();  // Displays a submit button
            ?>
        </form>
    </div>
    <?php
}

// Register the settings to store selected category and text field
function bhwd_register_settings() {
    // Register the category option
    register_setting('bhwd_settings_group', 'bhwd_selected_category');
    
    // Register the text field option
    register_setting('bhwd_settings_group', 'bhwd_custom_text_field');

    // Add settings section
    add_settings_section(
        'bhwd_main_section',               // Section ID
        'Main Settings',                   // Section title
        null,                              // Section callback (can be null)
        'bhwd-category-selector'           // Page slug to display this section
    );

    // Add category selection field
    add_settings_field(
        'bhwd_category_field',             // Field ID
        'Select Category',                 // Field label
        'bhwd_category_field_html',        // HTML rendering callback
        'bhwd-category-selector',          // Page slug to display this field
        'bhwd_main_section'                // Section ID where this field will be displayed
    );

    // Add text field
    add_settings_field(
        'bhwd_custom_text_field',          // Field ID
        'Enter Custom Text',               // Field label
        'bhwd_custom_text_field_html',     // HTML rendering callback
        'bhwd-category-selector',          // Page slug to display this field
        'bhwd_main_section'                // Section ID where this field will be displayed
    );
}
add_action('admin_init', 'bhwd_register_settings');

// HTML for the category dropdown field
function bhwd_category_field_html() {
    $categories = get_terms(['taxonomy' => 'product_cat', 'hide_empty' => false]);
    $selected_category = get_option('bhwd_selected_category');

    echo '<select name="bhwd_selected_category">';
    echo '<option value="">None</option>';  // Default option
    foreach ($categories as $category) {
        echo '<option value="' . esc_attr($category->term_id) . '" ' . selected($selected_category, $category->term_id, false) . '>' . esc_html($category->name) . '</option>';
    }
    echo '</select>';
}

// HTML for the text input field
function bhwd_custom_text_field_html() {
    $custom_text = get_option('bhwd_custom_text_field', '');  // Default is empty
    ?>
    <input 
        type="text" 
        name="bhwd_custom_text_field" 
        value="<?php echo esc_attr($custom_text); ?>" 
        class="regular-text"
    >
    <?php
}
?>