<?php function bhdcsfw_ads_admin_function() {
    $bhdcsfw_counter = 1;
    $index_counter_bhdcsfw = 0;
    $page_options = array();

    // Function to return page options
    function bhdcsfw_page_option_return() {
        global $page_options;
        echo implode(' , ', $page_options);
    }
?>
<!-- Ads FIELDS -->
<div class="container-fluid p-0 m-0" id="formItem-Bhdcsfw">
    <h3 class="mt-3">Ads Add+</h3>
    <div id="shortCodeListBhdcsfw" class="container-fluid p-0 m-0 mb-2"></div>
    <?php
        function checkOddEven($number) {
            if ($number % 2 == 0) {
                return "bg-light";
            } else {
                return "bg-white";
            }
        }
        global $page_options;
        for ($index_counter_bhdcsfw = 0; $index_counter_bhdcsfw < intval($bhdcsfw_counter) + intval(get_option('bhdcsfw-add-emlement-count', 0)); $index_counter_bhdcsfw++) {
            // Output the current value of the loop counter
            $page_options[] = 'bhdcsfw-desktop-image-url-' . $index_counter_bhdcsfw;
            $page_options[] = 'bhdcsfw-mobile-image-url-' . $index_counter_bhdcsfw;
            $page_options[] = 'bhdcsfw-ads-url-' . $index_counter_bhdcsfw;
            $page_options[] = 'bhdcsfw-categories-' . $index_counter_bhdcsfw; ?>
    <div class="row mb-3 ms-1 me-1 rounded shadow-sm <?php echo checkOddEven($index_counter_bhdcsfw) ?>">
        <div class="col-md-6">
            <label class="bhdcsfw-label_styling" for="bhdcsfw-desktop-image-url-<?php print $index_counter_bhdcsfw; ?>" name='bhdcsfw-desktop-image-url-<?php print $index_counter_bhdcsfw; ?>'>
                <?php print esc_attr("Image Desktop"); ?>
            </label><br>
            <input class="bhdcsfw-input-fields form-control border border-info" type="text" name="bhdcsfw-desktop-image-url-<?php print $index_counter_bhdcsfw; ?>" value="<?php print get_option('bhdcsfw-desktop-image-url-' . $index_counter_bhdcsfw); ?>" placeholder="Image Desktop (/img.jpg or png , webp , gif , avi)"><br>

            <label class="bhdcsfw-label_styling" for="bhdcsfw-mobile-image-url-<?php print $index_counter_bhdcsfw; ?>" name='bhdcsfw-mobile-image-url-<?php print $index_counter_bhdcsfw; ?>'>
                <?php print esc_attr("Image Mobile"); ?>
            </label><br>
            <input class="bhdcsfw-input-fields form-control border border-info" type="text" name="bhdcsfw-mobile-image-url-<?php print $index_counter_bhdcsfw; ?>" value="<?php print get_option('bhdcsfw-mobile-image-url-' . $index_counter_bhdcsfw); ?>" placeholder="Image Mobile (/img.jpg or png , webp , gif , avi)"><br>
        </div>
        <div class="col-md-6">
            <label class="bhdcsfw-label_styling" for="bhdcsfw-ads-url-<?php print $index_counter_bhdcsfw; ?>" name='bhdcsfw-ads-url-<?php print $index_counter_bhdcsfw; ?>'>
                <?php print esc_attr("Image Ads Url"); ?>
            </label><br>
            <input class="bhdcsfw-input-fields form-control border border-info" type="text" name="bhdcsfw-ads-url-<?php print $index_counter_bhdcsfw; ?>" value="<?php print get_option('bhdcsfw-ads-url-' . $index_counter_bhdcsfw); ?>" placeholder="Image Ads Url"><br>

            <label class="bhdcsfw-label_styling" for="bhdcsfw-categories-<?php print $index_counter_bhdcsfw; ?>" name='bhdcsfw-categories-<?php print $index_counter_bhdcsfw; ?>'>
                <?php print esc_attr("Which Categories...."); ?>
            </label><br>
            <input class="bhdcsfw-input-fields form-control border border-info" type="text" name="bhdcsfw-categories-<?php print $index_counter_bhdcsfw; ?>" value="<?php print get_option('bhdcsfw-categories-' . $index_counter_bhdcsfw); ?>" placeholder="Which Categories...."><br>
        </div>
    </div>
    <?php } ?>
    <div class="row bg-light rounded pt-2 pb-2">
        <div class="col-md-6 d-flex align-items-center">
            <input class="d-none bhdcsfw-input-fields form-control border border-info" type="number" name="bhdcsfw-add-emlement-count" id="bhdcsfw-add-emlement-count" value="<?php print get_option('bhdcsfw-add-emlement-count'); ?>" placeholder="How Much Fields" min="2">
            <p class="mt-1 mb-1" id="bhdcsfw_Item_count" >Total Item: <?php print intval(get_option('bhdcsfw-add-emlement-count')) + 1 ; ?></p>
            <p class="d-none" id="bhdcsfw_save_change_effact">Save Change More Items</p>
        </div>
        <div class="col-md-6 d-flex justify-content-center">
            <input class="btn button w-50 btn-info btn-sm" style="margin-right: 2.5px;" id="bhdcsfw-add-emlement-counters" type="button" value="Add More">
            <input class="btn button w-50 btn-info btn-sm" style="margin-left: 2.5px;" id="bhdcsfw-Remove-emlement-counters" type="button" value="Remove">
        </div>
    </div>
    <p class="d-none" id="bhdcsfw_err"></p>
</div>

<?php } ?>