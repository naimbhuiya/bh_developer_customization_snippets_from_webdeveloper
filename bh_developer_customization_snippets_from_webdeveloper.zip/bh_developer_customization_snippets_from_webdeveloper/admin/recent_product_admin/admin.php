<?php 

function bhd_recent_product_admin_panel()  {
    ?>
    <div class="container" >
                        <h5 class="titleStyle" >
                            Recent Product Style
                        </h5>
                          <div class="row">
                            <div class="col-md-6">
                                <!-- CARD BACKGROUND COLOR CHANGE -->
                                <label 
                                    class="bhdcsfw-label_styling" 
                                    for="bhdcsfw-card-bg-color" 
                                    name='bhdcsfw-card-bg-color' >
                                    <?php print esc_attr( "Card Background Color With # or rgb" ); ?>
                                </label>
                                <input 
                                    class="bhdcsfw-input-fields form-control border border-info" 
                                    type="text" 
                                    name="bhdcsfw-card-bg-color" 
                                    value="<?php print get_option( 'bhdcsfw-card-bg-color' ); ?>" 
                                    placeholder="Enter Color Code With # or rgb" >

                                <!-- CARD BORDER-RADIUS -->
                                <label 
                                    class="bhdcsfw-label_styling" 
                                    for="bhdcsfw-card-border-radius" 
                                    name='bhdcsfw-card-border-radius' >
                                    <?php print esc_attr( "Card Border Radius" ); ?>
                                </label>
                                <input 
                                    class="bhdcsfw-input-fields form-control border border-info" 
                                    type="text" 
                                    name="bhdcsfw-card-border-radius" 
                                    value="<?php print get_option( 'bhdcsfw-card-border-radius' ); ?>" 
                                    placeholder="Enter Border Radius" >
                                
                                <!-- CARD BORDER -->
                                <label 
                                    class="bhdcsfw-label_styling" 
                                    for="bhdcsfw-card-border" 
                                    name='bhdcsfw-card-border' >
                                    <?php print esc_attr( "Card Border" ); ?>
                                </label>
                                <input 
                                    class="bhdcsfw-input-fields form-control border border-info" 
                                    type="text" 
                                    name="bhdcsfw-card-border" 
                                    value="<?php print get_option( 'bhdcsfw-card-border' ); ?>" 
                                    placeholder="Enter Border" >

                                <!-- CARD TITLE COLOR CHANGE -->
                                <label 
                                    class="bhdcsfw-label_styling" 
                                    for="bhdcsfw-card-title-color" 
                                    name='bhdcsfw-card-title-color' >
                                    <?php print esc_attr( "Card Title Color With # or rgb" ); ?>
                                </label>
                                <input 
                                    class="bhdcsfw-input-fields form-control border border-info" 
                                    type="text" 
                                    name="bhdcsfw-card-title-color" 
                                    value="<?php print get_option( 'bhdcsfw-card-title-color' ); ?>" 
                                    placeholder="Enter Color Code With # or rgb" >
                                
                                <!-- CARD TITLE FONT-SIZE CHANGE -->
                                <label 
                                    class="bhdcsfw-label_styling" 
                                    for="bhdcsfw-card-title-font-size" 
                                    name='bhdcsfw-card-title-font-size' >
                                    <?php print esc_attr( "Card Title Font-size with px , em , rem" ); ?>
                                </label>
                                <input 
                                    class="bhdcsfw-input-fields form-control border border-info" 
                                    type="text" 
                                    name="bhdcsfw-card-title-font-size" 
                                    value="<?php print get_option( 'bhdcsfw-card-title-font-size' ); ?>" 
                                    placeholder="Enter size with px , em , rem" >

                                <!-- CARD TITLE FONT-FMALY CHANGE -->
                                <label 
                                    class="bhdcsfw-label_styling" 
                                    for="bhdcsfw-card-title-font-fmaly" 
                                    name='bhdcsfw-card-title-font-fmaly' >
                                    <?php print esc_attr( "Card Title Font-fmaly" ); ?>
                                </label>
                                <input 
                                    class="bhdcsfw-input-fields form-control border border-info" 
                                    type="text" 
                                    name="bhdcsfw-card-title-font-fmaly" 
                                    value="<?php print get_option( 'bhdcsfw-card-title-font-fmaly' ); ?>" 
                                    placeholder="Enter font fmaly" >
                                
                                <!-- CARD PRICE COLOR CHANGE -->
                                <label 
                                    class="bhdcsfw-label_styling" 
                                    for="bhdcsfw-card-price-color" 
                                    name='bhdcsfw-card-price-color' >
                                    <?php print esc_attr( "Card price Color" ); ?>
                                </label>
                                <input 
                                    class="bhdcsfw-input-fields form-control border border-info" 
                                    type="text" 
                                    name="bhdcsfw-card-price-color" 
                                    value="<?php print get_option( 'bhdcsfw-card-price-color' ); ?>" 
                                    placeholder="Enter Color Code" >

                                <!-- CARD PRICE FONT-SIZE CHANGE -->
                                <label 
                                    class="bhdcsfw-label_styling" 
                                    for="bhdcsfw-card-price-font-size" 
                                    name='bhdcsfw-card-price-font-size' >
                                    <?php print esc_attr( "Card Price Font Size" ); ?>
                                </label>
                                <input 
                                    class="bhdcsfw-input-fields form-control border border-info" 
                                    type="text" 
                                    name="bhdcsfw-card-price-font-size" 
                                    value="<?php print get_option( 'bhdcsfw-card-price-font-size' ); ?>" 
                                    placeholder="Enter Font Size" >

                                <!-- CARD PRICE FONT-FAMILY CHANGE -->
                                <label 
                                    class="bhdcsfw-label_styling" 
                                    for="bhdcsfw-card-price-font-family" 
                                    name='bhdcsfw-card-price-font-family' >
                                    <?php print esc_attr( "Card Title Font Size" ); ?>
                                </label>
                                <input 
                                    class="bhdcsfw-input-fields form-control border border-info" 
                                    type="text" 
                                    name="bhdcsfw-card-price-font-family" 
                                    value="<?php print get_option( 'bhdcsfw-card-price-font-family' ); ?>" 
                                    placeholder="Enter Font Size" >

                                
                                <!-- CARD description FONT-SIZE CHANGE -->
                                <label 
                                    class="bhdcsfw-label_styling" 
                                    for="bhdcsfw-card-description-font-size" 
                                    name='bhdcsfw-card-description-font-size' >
                                    <?php print esc_attr( "Card Description font-size" ); ?>
                                </label>
                                <input 
                                    class="bhdcsfw-input-fields form-control border border-info" 
                                    type="text" 
                                    name="bhdcsfw-card-description-font-size" 
                                    value="<?php print get_option( 'bhdcsfw-card-description-font-size' ); ?>" 
                                    placeholder="Card Description font-size" >
                                
                                
                                <!-- CARD description FONT-SIZE CHANGE -->
                                <label 
                                    class="bhdcsfw-label_styling" 
                                    for="bhdcsfw-card-description-color" 
                                    name='bhdcsfw-card-description-color' >
                                    <?php print esc_attr( "bhdcsfw-card-description-color" ); ?>
                                </label>
                                <input 
                                    class="bhdcsfw-input-fields form-control border border-info" 
                                    type="text" 
                                    name="bhdcsfw-card-description-color" 
                                    value="<?php print get_option( 'bhdcsfw-card-description-color' ); ?>" 
                                    placeholder="Card Description color" >

                                
                                <!-- CARD description FONT-FMALY CHANGE -->
                                <label 
                                    class="bhdcsfw-label_styling" 
                                    for="bhdcsfw-card-description-font-fmaly" 
                                    name='bhdcsfw-card-description-font-fmaly' >
                                    <?php print esc_attr( "Card Description font-fmaly" ); ?>
                                </label>
                                <input 
                                    class="bhdcsfw-input-fields form-control border border-info" 
                                    type="text" 
                                    name="bhdcsfw-card-description-font-fmaly" 
                                    value="<?php print get_option( 'bhdcsfw-card-description-font-fmaly' ); ?>" 
                                    placeholder="Card Description font-fmaly" >
								
								<!-- CARD Product Count -->
                                <label 
                                    class="bhdcsfw-label_styling" 
                                    for="bhdcsfw-product-card-count" 
                                    name='bhdcsfw-product-card-count' >
                                    <?php print esc_attr( "Card Description font-fmaly" ); ?>
                                </label>
                                <input 
                                    class="bhdcsfw-input-fields form-control border border-info" 
                                    type="text" 
                                    name="bhdcsfw-product-card-count" 
                                    value="<?php print get_option( 'bhdcsfw-product-card-count' ); ?>" 
                                    placeholder="Card Product Count" >
                            </div>
                            <div class="col-md-6">
                            <!-- CARD Style -->
                                <label 
                                    class="bhdcsfw-label_styling" 
                                    for="bhdcsfw-card-style" 
                                    name='bhdcsfw-card-style' >
                                    <?php print esc_attr( "Card Custom Css" ); ?>
                                </label>               
                                <textarea class="bhdcsfw-input-fields form-control heigth-100 border border-info"  name="bhdcsfw-card-style" id="" value="<?php print get_option( 'bhdcsfw-card-style' ); ?>" ><?php print get_option( 'bhdcsfw-card-style' ); ?></textarea>
                            </div>
                          </div>
                        
                    </div>
    <?php
}

function fieldNameReturnFromRecentProductAdmin() {
    echo 'bhdcsfw-card-border , bhdcsfw-card-style , bhdcsfw-card-border-radius , bhdcsfw-card-description-font-fmaly  , bhdcsfw-card-description-color , bhdcsfw-card-description-font-size , bhdcsfw-card-price-font-family , bhdcsfw-card-price-font-size ,bhdcsfw-card-price-color , bhdcsfw-card-title-font-fmaly , bhdcsfw-card-title-font-size , bhdcsfw-card-title-color , bhdcsfw-card-bg-color , bhdcsfw-product-card-count';
}