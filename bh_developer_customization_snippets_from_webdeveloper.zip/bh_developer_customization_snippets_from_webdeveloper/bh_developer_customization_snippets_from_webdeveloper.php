<?php
/**
 * The plugin bootstrap file
 *
 * This file is read by WordPress to generate the plugin information in the plugin
 * admin area. This file also includes all of the dependencies used by the plugin,
 * registers the activation and deactivation functions, and defines a function
 * that starts the plugin.
 *
 * @link              https://devshark.net
 * @since             1.1.3
 * @package           Bh_developer_customization_snippets_from_webdeveloper
 *
 * @wordpress-plugin
 * Plugin Name:       BH developer customization snippets from webdeveloper
 * Plugin URI:        https://dise.sviluppo.host/bh_developer_customization_snippets_from_webdeveloper
 * Description:       Boost your coding efficiency with the 'BH Developer Customization Snippets' plugin—your go-to resource for web development snippets curated for seamless customization and enhanced productivity.
 * Version:           1.1.4
 * Author:            Disegnarecasa Developer
 * Author URI:        https://devshark.net/
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       bhdcsfw
 * Domain Path:       /languages
 */

function bhwd_common_scripts (){
    wp_enqueue_style( 'bhwd_common_style', plugin_dir_url( __FILE__ ) . 'bhwd_common.css', [], true );
};
add_action( 'wp_enqueue_scripts',  'bhwd_common_scripts');



function bhdcsfw_administrator(){
    add_menu_page( ' BHDCSFW Customaization' , 'BHDCSFW Customaization' , 'manage_options' , 'bhdcsfw-bh-customaization',  'bhdcsfw_menu_page_function'   , 'dashicons-shortcode' , 101 );
}
add_action('admin_menu' , 'bhdcsfw_administrator' );
/**
 *  inclueds File hare
 */
// admin.php file inclueds..
require_once(plugin_dir_path(__FILE__) . 'admin/admin.php');
// inclueds.php file is inclueds..
require_once(plugin_dir_path(__FILE__) . 'inclueds/incluedes.php');


function remove_empty_files() {
    global $wp_styles, $wp_scripts;

    // Remove Empty CSS Files
    if (!empty($wp_styles->registered)) {
        foreach ($wp_styles->registered as $handle => $style) {
            $src = $style->src;
            if (!empty($src)) {
                $local_path = str_replace(site_url(), ABSPATH, $src);
                if (file_exists($local_path) && filesize($local_path) === 0) {
                    wp_dequeue_style($handle);
                    wp_deregister_style($handle);
                }
            }
        }
    }

    // Remove Empty JS Files
    if (!empty($wp_scripts->registered)) {
        foreach ($wp_scripts->registered as $handle => $script) {
            $src = $script->src;
            if (!empty($src)) {
                $local_path = str_replace(site_url(), ABSPATH, $src);
                if (file_exists($local_path) && filesize($local_path) === 0) {
                    wp_dequeue_script($handle);
                    wp_deregister_script($handle);
                }
            }
        }
    }
}
add_action('wp_enqueue_scripts', 'remove_empty_files', 100);



