<?php
// Enqueue Slick Slider and custom assets
// Enqueue Slick Slider and custom assets
function bhwd_showroom_enqueue_scripts() {
    // Enqueue jQuery first
    wp_enqueue_script('jquery');

    // Slick CSS
    wp_enqueue_style('slick-css', plugin_dir_url(__FILE__) . 'addon/slick-css.min.css');
    wp_enqueue_style('slick-theme-css', plugin_dir_url(__FILE__) . 'addon/slick-theme-css.min.css');

    // Slick JS (ensure it's loaded after jQuery)
    wp_enqueue_script('slick-js', plugin_dir_url(__FILE__) . 'addon/slick.min.js', array('jquery'), '', true);

    // Custom CSS and JS
    wp_enqueue_style('bhwd_showroom-css', plugin_dir_url(__FILE__) . 'assest/style.css', array(), '1.0.0');
    wp_enqueue_script('bhwd_showroom-js', plugin_dir_url(__FILE__) . 'assest/script.js', array(), '1.0.0', true);
    wp_localize_script( 'bhwd_showroom-js', 'bhwdSmAjxScript', array(
    'bhwdSmAjxUrl' => admin_url( 'admin-ajax.php' ),
    // 'otherParam' => 'some value',
) );
}
add_action('wp_enqueue_scripts', 'bhwd_showroom_enqueue_scripts');

// Slick Slider initialization

function get_pages_with_elementor_content_and_meta() {
    $args = array(
        'post_type'      => 'page',
        'posts_per_page' => -1,
        'orderby'        => 'menu_order',
        'order'          => 'ASC',
        'meta_query'     => array(
            array(
                'key'     => 'select_city', // Filter by the specific meta key
                'compare' => 'EXISTS',     // Ensure only pages with this meta key are included
            ),
        ),
    );

    $query = new WP_Query($args);
    
     $relationalMeta = [];

    $form_id = get_option('bhwd_showroom_add_short_code');
    $formContent = '';
	// Check if the form ID is valid and exists
	if ($form_id) {
		// Load the form by ID and display it using Contact Form 7 API
		$contact_form = wpcf7_contact_form( $form_id );
		if ($contact_form) {
			$formContent = $contact_form->form_html(); // Display the form HTML directly
		} else {
			$formContent = '<h4>Contact form not found. Please check your settings or contact us at <a href="mailto:' . esc_attr(get_option('bhwd_showroom_email', 'info@disegnarecasa.com')) . '"><strong>Email Us</strong></a></h4>';
		}
	} else {
		$formContent = '<h4>Contact form not selected. Please select a form in the settings.</h4>';
	}

if ($query->have_posts()) {
    $relationalMeta = array(  );

    while ($query->have_posts()) {
        $query->the_post();

        // Fetch the value of the `select_city` meta key
        $meta_value = get_post_meta(get_the_ID(), 'select_city', true);

        // Check if the page is built with Elementor
        if (did_action('elementor/loaded') && \Elementor\Plugin::$instance->documents->get(get_the_ID())->is_built_with_elementor()) {
            // Render the content using Elementor's frontend renderer
            $page_content = \Elementor\Plugin::instance()->frontend->get_builder_content(get_the_ID());
        } else {
            // For non-Elementor pages, use the default WordPress content filter
            $page_content = apply_filters('the_content', get_post_field('post_content', get_the_ID()));
        }

        // Handle Contact Form 7 integration
        $form_id = get_option('bhwd_showroom_add_short_code', 0); // Default to 0 if not set
        $page_contact_form = '';
        if (function_exists('wpcf7_contact_form')) {
            $contact_form = wpcf7_contact_form($form_id);
            if ($contact_form) {
                $page_contact_form = $contact_form->form_html(); // Get the form HTML
            } else {
                $page_contact_form = '<h4>Contact form not found. Please check your settings or contact us at <a href="mailto:' . esc_attr(get_option('bhwd_showroom_email', 'info@disegnarecasa.com')) . '"><strong>Email Us</strong></a></h4>';
            }
        } else {
            $page_contact_form = '<p>Contact Form 7 plugin is not active or installed.</p>';
        }

        // Handle post thumbnail
        $post_thumbnail_id = get_post_meta(get_the_ID(), 'page_custom_image', true);
        $post_thumbnail = '';
        if (!empty($post_thumbnail_id)) {
            $post_thumbnail = wp_get_attachment_image($post_thumbnail_id, 'full'); // Get custom image
        } else {
            $post_thumbnail = has_post_thumbnail() ? get_the_post_thumbnail_url(get_the_ID(), 'full') : false; // Fallback to default thumbnail
        }

        // Handle "scopri" global option
        $scopri = get_option('bhwd_get_selected_page_slug', false);

        // Replace and normalize text
        $text = bhwd_replace_text($meta_value);

        // Add page data to the array
        $page_data = array(
            'ID'            => get_the_ID(),
            'title'         => get_the_title(),
            'content'       => $page_content,       // Rendered Elementor content or regular content
            'select_city'   => $meta_value,         // Include the specific meta value
            'contact_form'  => $page_contact_form,  // Include contact form HTML
            'post_thumbnail'=> $post_thumbnail,     // Include the thumbnail
            'scopri'        => $scopri,            // Include the "scopri" value
            'contactForm'   => $formContent
        );

        // Handle cases and add to the correct category
        switch ($text) {
            case "north-cities":
                $relationalMeta["northCites"][] = $page_data; // Append to north cities
                break;
            case "center-cities":
                $relationalMeta["centerCites"][] = $page_data; // Append to center cities
                break;
            case "south-cities":
                $relationalMeta["southCites"][] = $page_data; // Append to south cities
                break;
            case "aborad":
                $relationalMeta["aborad"][] = $page_data; // Append to abroad
                break;
            default:
                $relationalMeta["message"] = "Some pages don't belong to any showroom category.";
                break;
        }
    }

    wp_reset_postdata(); // Reset the global post data
} else {
    // No posts found
    $relationalMeta = array(
        "err"     => true,
        "message" => "No pages found in showroom.",
    );
}

    wp_send_json($relationalMeta);
    // wp_die();
    // return $pages_with_meta;
}


// Register AJAX actions
add_action('wp_ajax_bhwd_showroom_data_access', 'get_pages_with_elementor_content_and_meta');
add_action('wp_ajax_nopriv_bhwd_showroom_data_access', 'get_pages_with_elementor_content_and_meta');

// Register the shortcode
// add_shortcode('bhwdElementorShortCode', 'display_elementor_pages_with_meta');
function bhwd_replace_text($text) {
    return strtolower(str_replace(' ', '-', $text));
}



function bhwd_showroom_section(){
    ob_start();
    ?>
    <div class="bhwd_MainCarousel" ></div>
    <?php
    return ob_get_clean();
}
add_shortcode('bhwd_car', 'bhwd_showroom_section')

?>