jQuery(document).ready(function ($) {
  function bhwd_called_func_if_finished_request() {
    // Selecting necessary elements
    const $contactButtons = $(".bhwd_pp_content_btn.contatti");
    const $infoButtons = $(".bhwd_pp_content_btn.info");
    // const $nestedCarousels = $(".bhwdNestedCarousel");
    const $pageContents = $(".bhwd-page-content");
    const $formShortCodes = $(".bhwd-form-short-code");
    const $nestedCarouselItems = $(".bhwd-carousel-nested-item");
    const $mainCarousel = $(".bhwd_MainCarousel");

    // Log the number of buttons and content elements for debugging
    console.log("Number of contact buttons:", $contactButtons.length);
    console.log("Number of content elements:", $pageContents.length);

    // Initialize popup logic by attaching event listeners to buttons
    function initPopupListeners() {
      // Attach click event listener to each contact button
      $contactButtons.each(function (index) {
        $(this).on("click", function () {
          closeExistingPopup();
          createPopup(false, index); // 'false' indicates it's not a form popup
        });
      });

      // Attach click event listener to each info button
      $infoButtons.each(function (index) {
        $(this).on("click", function () {
          closeExistingPopup();
          createPopup(true, index); // 'true' indicates it's a form popup
        });
      });
    }

    // Create and display a popup
    function createPopup(isForm, index) {
      const $popupElement = $(`
      <div class="bhwd_popup_content">
        <div class="bhwd-popup-container">
          <div class="bhwd_content">${getContent(isForm, index)}</div>
          <div class="bhwd_close">
            <button class="bhwd-close-button">
              <i class="fa fa-close"></i>
            </button>
          </div>
        </div>
        <div class="bhwd-overly"></div>
      </div>
    `);

      // Append the popup to the appropriate container based on screen size
      if ($(window).width() > 768 || !$nestedCarouselItems.eq(index).length) {
        $("body").append($popupElement);
      } else {
        $mainCarousel.append($popupElement);
      }

      // Set up event listeners for closing the popup
      setupPopupCloseEvents($popupElement);
    }

    // Set up popup close events
    function setupPopupCloseEvents($popupElement) {
      $popupElement.find(".bhwd-close-button").on("click", function () {
        closePopup($popupElement);
      });
      $popupElement.find(".bhwd-overly").on("click", function () {
        closePopup($popupElement);
      });
    }

    // Close popup with animation
    function closePopup($popupElement) {
      $popupElement.addClass("bhwd-overly-puse");
      setTimeout(function () {
        $popupElement.remove();
      }, 400); // Delay to allow for closing animation
    }

    // Close any existing popups before opening a new one
    function closeExistingPopup() {
      const $existingPopup = $(".bhwd_popup_content");
      if ($existingPopup.length) closePopup($existingPopup);
    }

    // Get the content for the popup (page content or form shortcode)
    function getContent(isForm, index) {
      console.log(isForm);

      if (isForm && $formShortCodes.eq(index).length) {
        return $formShortCodes.eq(index).html();
      } else if ($pageContents.eq(index).length) {
        return $pageContents.eq(index).html();
      }
      return `<p>Content not available</p>`;
    }

    // Initialize popup listeners
    initPopupListeners();
  }

  $.ajax({
    type: "GET", // Use POST if needed for security or large payloads
    url: bhwdSmAjxScript.bhwdSmAjxUrl, // The AJAX URL provided by WordPress
    data: {
      action: "bhwd_showroom_data_access", // Specify the action for the backend handler
    },
    beforeSend: function () {
      $(".bhwd_MainCarousel").append(
        `<div style="display: flex ; justify-content: center ;" >
          <div class="spinner-border text-primary" role="status">
            <span class="visually-hidden">Loading...</span>
          </div>
        </div>`
      );
    },
    success: function (data, status) {
      $(".bhwd_MainCarousel").empty(
        `<div class="spinner-border text-primary" role="status">
          <span class="visually-hidden">Loading...</span>
        </div>`
      );
      // console.log(status);
      // console.log(data);
      bhwd_create_showroom_section(data);
      bhwdSlickSlider(".bhwdNestedCarousel");
      bhwd_called_func_if_finished_request();
      // Initialize popup listeners
    },
    error: function (xhr, status, error) {
      console.error("AJAX error: ", status, error); // Handle AJAX errors
    },
  });

  function bhwd_create_showroom_section(data) {
    // Check if there's no error in the data
    if (!data["err"]) {
      if (data["northCites"]) {
        bhwdAppendCity(data["northCites"], "North Cities");
      }
      if (data["centerCites"]) {
        bhwdAppendCity(data["centerCites"], "Center Cities");
      }
      if (data["southCites"]) {
        bhwdAppendCity(data["southCites"], "South Cities");
      }
      if (data["aborad"]) {
        bhwdAppendCity(data["aborad"], "Aborad");
      }
      if (data["message"]) {
        $(".bhwd_MainCarousel").append(
          `<div class="alert alert-warning" role="alert">${data["message"]}</div>`
        );
      }
    } else {
      // Display an alert if there is an error
      $(".bhwd_MainCarousel").append(
        `<div class="alert alert-warning" role="alert">${data["message"]}</div>`
      );
    }
  }

  // Replace spaces with hyphens and convert text to lowercase (slug-like format)
  function bhwd_replace_text(text) {
    return text.replace(/\s+/g, "-").toLowerCase();
  }

  // Append a city section to the main carousel
  function bhwdAppendCity(data, title) {
    $(".bhwd_MainCarousel").append(bhwdMainElement(data, title));
  }

  // Create the main carousel element for a city
  function bhwdMainElement(data, title) {
    return `<div class="bhwd-carousel-item"><div><h2 class="bhwd_sm_title" >${title}</h2></div>${bhwdNestedElement(data)}</div>`;
  }

  // Create the nested carousel inside a city section
  function bhwdNestedElement(data) {
    return `<div class="slick-slider bhwdNestedCarousel">${bhwdCarouselNestedItems(
      data
    )}</div>`;
  }

  // Generate all nested items inside the nested carousel
  function bhwdCarouselNestedItems(data) {
    let nestedItems = ""; // Initialize an empty string to hold all nested items
    $.each(data, function (key, value) {
      nestedItems += `<div class="bhwd-carousel-nested-item slick-slide slick-initialized slick-dotted" data-dot="${value.title}" > `;
      nestedItems += `<div class="bhwd-mobile-overly"></div>`;
      nestedItems += `<div class="bhwd_information_button">`;
      nestedItems += `<div class="bhwd_button_container">`;
      nestedItems += `<button class="bhwd_pp_content_btn contatti">Contatti</button>`;
      nestedItems += `</div>`;
      nestedItems += `<div class="bhwd_button_container">`;
      nestedItems += `<button class="bhwd_pp_content_btn info">Info</button>`;
      nestedItems += `</div>`;
      nestedItems += `<div class="bhwd_button_container">`;
      nestedItems += `<a href="${
        value.scopri ? value.scopri : "#"
      }" class="bhwd_pp_content_btn scopri" >`;
      nestedItems += `<button>Scopri</button>`;
      nestedItems += ` </a>`;
      nestedItems += `</div>`;
      nestedItems += `</div>`;
      nestedItems += `<img src="${
        value.post_thumbnail
          ? value.post_thumbnail
          : "https://via.placeholder.com/800x300?text=Non+trovato"
      }" class="bhwd-d-block bhwd-w-100" alt="${
        value.title || "have no title"
      }"></img>`;
      nestedItems += `<div class="d-none bhwd-page-content">`;
      nestedItems += `<h2 class="bhwdPostPopUpTitle">${
        value.title || "have no title"
      }</h2>`;
      nestedItems += `<h2 class="bhwdMainpoupTitle" >Contatti</h2>`;
      nestedItems += `<div class="bhwdPostContentContainer" >${value.content}</div>`;
      nestedItems += `</div>`;
      nestedItems += `<div class="bhwd-form-short-code d-none">`;
      nestedItems += `<h2 class="bhwdMainpoupTitle">Informarsi</h2>`;
      nestedItems += `<div class="bhwdPostContentContainer">${value.contactForm}</div>`;
      nestedItems += `</div>`;
      // nestedItems += titleObjectForDotPagination(value);
      nestedItems += `</div> `;

      // nestedItems += `<p>${titleObjectForDotPagination(value)}</p>`;
    });
    return nestedItems; // Return the concatenated nested items
  }

  function bhwdSlickSlider(selector) {
    $(selector).slick({
      slidesToShow: 3,
      slidesToScroll: 1,
      dots: true,
      infinite: true,
      centerMode: true,
      focusOnSelect: true,
      arrows: true,
      arrows: false,
      customPaging: function (slider, i) {
        var dotText = $(slider.$slides[i]).attr("data-dot");
        return '<span class="custom-dot-text">' + dotText + "</span>";
      },
      responsive: [
        {
          breakpoint: 768,
          settings: {
            slidesToShow: 1,
            slidesToScroll: 1,
            centerPadding: "0px",
            arrows: false,
          },
        },
      ],
    });
  }
});
