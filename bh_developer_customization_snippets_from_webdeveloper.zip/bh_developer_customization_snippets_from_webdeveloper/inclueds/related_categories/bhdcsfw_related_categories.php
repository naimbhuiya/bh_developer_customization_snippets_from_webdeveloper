<?php

function bhdcsfw_get_related_categories_sliders_shortcode() {
    // Get the current category object
    $product_current_archive_page_bhdcsfw = get_queried_object();

    // Check if the current page is a category archive
    if (is_a($product_current_archive_page_bhdcsfw, 'WP_Term') && isset($product_current_archive_page_bhdcsfw->term_id)) {
        // Get the product category IDs
        $get_product_ids_bhdcsfw = wp_get_post_terms($product_current_archive_page_bhdcsfw->term_id, 'product_cat', array('fields' => 'ids'));

        // Initialize an empty array to store related category IDs
        $related_category_ids = array();

        // Loop through the product category IDs
        foreach ($get_product_ids_bhdcsfw as $product_id_bhdcsfw) {
            // Get the related categories for each product category
            $related_terms_bhdcsfw = get_term_meta($product_id_bhdcsfw, 'product_cat_related', true);
            if (!empty($related_terms_bhdcsfw)) {
                $related_category_ids = array_merge($related_category_ids, $related_terms_bhdcsfw);
            }
        }

        // Check if there are related category IDs
        if (!empty($related_category_ids)) {
            // Output the related category IDs
            return implode(', ', $related_category_ids);
        } else {
            // Return message when there are no related categories
            return 'No related categories found.';
        }
    }
    
    // Return message when not on a category archive page
    return 'Not a category page.';
}

add_shortcode("related_categories_slider_bhdcsfw", "bhdcsfw_get_related_categories_sliders_shortcode");
