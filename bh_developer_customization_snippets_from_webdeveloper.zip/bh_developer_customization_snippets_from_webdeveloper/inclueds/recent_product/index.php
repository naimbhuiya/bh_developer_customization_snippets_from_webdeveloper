<?php
function enqueue_recent_product_list_page_script() {
    // Enqueue Bootstrap CSS from a CDN
    wp_enqueue_style('bhdcsfw_recent_product_list_page_script', plugin_dir_url(__FILE__) . 'asset/style.css?inline', array(), '1.0.0' , 'all');
}
add_action( 'wp_enqueue_scripts', 'enqueue_recent_product_list_page_script' );
// d-clear ShortCode Function 
// Function to display recent products with customizable styling
// Function to display recent products with customizable styling
function recent_product_list_shortcode() {
    // Retrieve options with defaults for product display count and styles
    $products_count = get_option('bhdcsfw-product-card-count', 5);
    $bg_color = esc_attr(get_option('bhdcsfw-card-bg-color', '#fff'));
    $border_radius = esc_attr(get_option('bhdcsfw-card-border-radius', '8px'));
    $title_color = esc_attr(get_option('bhdcsfw-card-title-color', '#333'));
    $title_font_size = esc_attr(get_option('bhdcsfw-card-title-font-size', '16px'));
    $title_font_family = esc_attr(get_option('bhdcsfw-card-title-font-family', 'Arial, sans-serif'));
    $price_color = esc_attr(get_option('bhdcsfw-card-price-color', '#333'));
    $price_font_size = esc_attr(get_option('bhdcsfw-card-price-font-size', '14px'));
    $price_font_family = esc_attr(get_option('bhdcsfw-card-price-font-family', 'Arial, sans-serif'));
    $description_color = esc_attr(get_option('bhdcsfw-card-description-color', '#555'));
    $description_font_size = esc_attr(get_option('bhdcsfw-card-description-font-size', '14px'));
    $description_font_family = esc_attr(get_option('bhdcsfw-card-description-font-family', 'Arial, sans-serif'));
    $custom_style = wp_kses_post(get_option('bhdcsfw-card-style'));

    // Query arguments for recent products
    $args = array(
        'post_type' => 'product',
        'posts_per_page' => $products_count,
        'orderby' => 'date',
        'order' => 'DESC',
    );

    $recent_products = new WP_Query($args);
    ob_start();

    // Inline CSS for styling from options
    ?>
    <style>
        .customBackgroundStyle {
            background: <?php echo $bg_color; ?>;
            border-radius: <?php echo $border_radius; ?>;
        }
        .customCardTitleStyle {
            color: <?php echo $title_color; ?>;
            font-size: <?php echo $title_font_size; ?>;
            font-family: <?php echo $title_font_family; ?>;
        }
        .priceStyleCss {
            color: <?php echo $price_color; ?>;
            font-size: <?php echo $price_font_size; ?>;
            font-family: <?php echo $price_font_family; ?>;
        }
        .productDescription {
            color: <?php echo $description_color; ?>;
            font-size: <?php echo $description_font_size; ?>;
            font-family: <?php echo $description_font_family; ?>;
        }
        <?php echo $custom_style; ?>
    </style>

    <div class="container-fluid justify-content-center">
        <div class="row">
            <?php
			$bhwd_count = 0 ;
            if ($recent_products->have_posts()) {
    while ($recent_products->have_posts()) {
		$bhwd_count++;
        $recent_products->the_post();
        $product_id = get_the_ID();
        $product = wc_get_product($product_id);

        // Retrieve product details
        $thumbnail_url = get_the_post_thumbnail_url($product_id, 'woocommerce_thumbnail') ?: '/wp-content/uploads/2024/05/Err-Image.png';
        $regular_price = $product->get_regular_price();
        $sale_price = $product->get_sale_price();
        $product_title = wp_trim_words(get_the_title(), 4);

        // Add Wishlist Button (Based on the active plugin)
        // Example: YITH WooCommerce Wishlist
        if (shortcode_exists('yith_wcwl_add_to_wishlist')) {
            $wishlist_button = do_shortcode('[yith_wcwl_add_to_wishlist product_id="' . esc_attr($product_id) . '"]');
        }
        // Example: TI WooCommerce Wishlist
        elseif (shortcode_exists('ti_wishlists_addtowishlist')) {
            $wishlist_button = do_shortcode('[ti_wishlists_addtowishlist product_id="' . esc_attr($product_id) . '"]');
        }
        // Example: JetWishlist
        elseif (shortcode_exists('jet-woo-wishlist-button')) {
            $wishlist_button = do_shortcode('[jet-woo-wishlist-button item="' . esc_attr($product_id) . '"]');
        } else {
            $wishlist_button = ''; // Fallback if no wishlist plugin is installed
        }
        ?>
        <div class="col-md-3 mt-2 mb-2">
            <div class="card border-0 animationTop customBackgroundStyle rounded <?php echo $bhwd_count % 2 === 0 ? 'oddProduct' : 'evenProduct'; ?>">
                
                <!-- Wishlist Button -->
                <div class="wishlist-button-wrapper">
                    <?php echo $wishlist_button; ?>
                </div>
                
                <a href="<?php the_permalink(); ?>" class="text-decoration-none text-dark">
                    <img class="card-img-top bhwd_resent_product_image" src="<?php echo esc_url($thumbnail_url); ?>" alt="<?php echo esc_attr($product_title); ?>">
                    <div class="card-body">
                        <h5 class="card-title customCardTitleStyle mb-2"><?php echo esc_html($product_title); ?></h5>
                        <div class="container p-0">
                            <h5 class="card-title price mb-2">
                                <p class="priceStyleCss">
                                    <span class="dollarSignStyle"><i class="fa-solid fa-dollar-sign"></i></span>
                                    <?php if ($product->is_on_sale() && $sale_price) : ?>
                                        <span class="ifSalePrice"><?php echo wc_price($sale_price); ?></span>
                                        <span class="ifSalePriceForRegularPrice"><?php echo wc_price($regular_price); ?></span>
                                    <?php else : ?>
                                        <span class="<?php echo $regular_price ? 'regularPrice' : 'ifSalePriceForRegularPrice'; ?>">
                                            <?php echo $regular_price ? wc_price($regular_price) : 'Call for Price'; ?>
                                        </span>
                                    <?php endif; ?>
                                </p>
                            </h5>
                        </div>
                    </div>
                </a>
            </div>
        </div>
        <?php
    }
    wp_reset_postdata();
} else {
    echo '<p>No recent products found.</p>';
}
            ?>
        </div>
    </div>
    <?php
    return ob_get_clean();
}

add_shortcode('resent_productlist_for_this', 'recent_product_list_shortcode');