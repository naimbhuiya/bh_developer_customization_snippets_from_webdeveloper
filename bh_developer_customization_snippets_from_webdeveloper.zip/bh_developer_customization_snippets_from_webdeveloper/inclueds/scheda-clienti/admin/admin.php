<?php 

// Add a submenu item for custom category selection under a WooCommerce customization menu
function bhwd_add_scheda_clienti_form_admin_menu() {
    add_submenu_page(
        'bhdcsfw-bh-customaization',    // Parent menu slug (ensure this menu exists)
        'Scheda Clienti From',         // Page title
        'Scheda Clienti Form',         // Submenu title
        'manage_options',               // Capability required to access this menu
        'bhwd-scheda-clienti',             // Menu slug
        'bhwd_scheda_clienti_form_admin'  // Callback function to display the page content
    );
}
add_action('admin_menu', 'bhwd_add_scheda_clienti_form_admin_menu');

function bhwd_scheda_clienti_form_admin() {
    $bhwd_admin_page_fields = array(
        'bhwd-page-titte' => [
            'label' => 'Page Title',
            'placeholder' => 'Scheda Clienti',
            'type' => 'text',
        ],
        'bhwd-error-section-title' => [
            'label' => 'Error Section Title',
            'placeholder' => 'Il Tracciato Da è valido',
            'type' => 'text',
        ],
        'bhwd-message-section-header-field-error' => [
            'label' => 'Header Field Error Message',
            'placeholder' => 'Ci sono errori nel tuo nome, indirizzo email, numero di telefono e informazioni sulla città.',
            'type' => 'text',
        ],
         'bhwd-message-section-header-field-success' => [
            'label' => 'Header Field Error success',
            'placeholder' => 'Tutte le informazioni sono corrette.',
            'type' => 'text',
        ],
        'parent-tab-title' => [
            'label' => 'Parent Tab Title',
            'placeholder' => 'Prodotto Desiderato',
            'type' => 'text',
        ],
        'bhwd-form-title' => [
            'label' => 'Form Title',
            'placeholder' => 'Fill The information',
            'type' => 'text',
        ],
        'bhwd-form-submit-text' => [
            'label' => 'Form Submit Text',
            'placeholder' => 'Submit',
            'type' => 'text',
        ],
        'bhwd-scheda-form-subject' => [
            'label' => 'Scheda Form Subject',
            'placeholder' => 'New Submit scheda',
            'type' => 'text',
        ],
        "email_is_rqd" => [
            'label' => 'Email Requirde Message',
            'placeholder' => 'Email field is required.',
            'type' => 'text',
        ],
        "email_sent_successfully" => [
            'label' => 'Email sent Message',
            'placeholder' => 'Email sent successfully!',
            'type' => 'text',
        ],
        "email_sent_failed" => [
            'label' => 'Failed to send email.',
            'placeholder' => 'Failed to send email.',
            'type' => 'text',
        ],
        "not_fillup_form" => [
            'label' => 'If not fill up a single fiald in form .',
            'placeholder' => 'Are not fill up a single fiald in form',
            'type' => 'text',
        ],
        "requird_fillup_form" => [
            'label' => 'Required fill up meassage.',
            'placeholder' => 'Are not fill up a single fiald in form',
            'type' => 'text',
        ],
        "bhwd-name-label" => [
            'label' => 'Name Label',
            'placeholder' => 'Nome e cognome',
            'type' => 'text',
        ],
        "bhwd-email-label" => [
            'label' => 'Email Label',
            'placeholder' => 'E-mail',
            'type' => 'text',
        ],
        "bhwd-phone-label" => [
            'label' => 'Phone Label',
            'placeholder' => 'Telefono',
            'type' => 'text',
        ],
        "bhwd-city-label" => [
            'label' => 'City Label',
            'placeholder' => 'Città',
            'type' => 'text',
        ],
        
        "bhwd-if-not-fill-up-fields" => [
            'label' => 'If not fill up Field (message)',
            'placeholder' => 'Inserisci correttamente email, nome, numero di telefono',
            'type' => 'text',
        ]
        ,
        "bhwd-if-not-checked-city" => [
            'label' => 'If not selected city (message)',
            'placeholder' => 'Seleziona prima nazione, provincia, città!',
            'type' => 'text',
        ]
        ,
        "bhwd-if-not-checked-privacy" => [
            'label' => 'If notchecked privacy ( message)',
            'placeholder' => 'Per favore controlla prima la privacy!',
            'type' => 'text',
        ],
        "bhwd-contatti-form-subject" => [
            'label' => 'Contatti form subject',
            'placeholder' => 'Contattaci',
            'type' => 'text',
        ]
        
    );

    ?>
    <div class="container-fluid">
        <h1>Scheda Clienti Form</h1>
        <form method="post" action="options.php">
            <?php wp_nonce_field('update-options'); ?>
            <div class="row">
                <div class="col-md-6">
                    <?php foreach ($bhwd_admin_page_fields as $field => $field_args) : ?>
                        <div class="bhwd-form-header-controls">
                            <label for="<?php print $field; ?>"><?php print $field_args['label']; ?></label>
                            <input class="bhdcsfw-input-fields" type="<?php print $field_args['type']; ?>" name="<?php print $field; ?>" value="<?php print get_option($field, $field_args['placeholder']); ?>" id="<?php print $field; ?>">
                        </div>
                    <?php endforeach; ?>
                </div>
                <div class="col-md-6">
                    <label for="bhwd-scheda-form-list"></label>
                    <textarea class="w-100 h-100 bhdcsfw-input-fields" style="height: 400px;" name="bhwd-scheda-form-list" id="bhwd-scheda-form-list"><?php echo get_option('bhwd-scheda-form-list', 'paquet'); ?></textarea>
                </div>
            </div>
            <div class="row">
                <?php 
                $scheda_clainti_form_list = explode(' , ', get_option('bhwd-scheda-form-list', 'paquet'));
                foreach ($scheda_clainti_form_list as $field) { 
                    $field_name = preg_replace('/[\s-]+/', '-', strtolower(trim($field)));
                    ?>
                    <div class="col-md-4">
                        <div class="bhwd-form-header-controls">
                            <label for="<?php print $field_name; ?>"><?php print $field; ?></label>
                            <textarea class="w-100 h-100 bhdcsfw-input-fields" style="height: 400px;" name="<?php echo $field_name; ?>" id="<?php echo $field_name; ?>" value="<?php echo trim(get_option($field_name, '')); ?>" ><?php echo trim(get_option($field_name, '')); ?></textarea>
                        </div>
                    </div>
                <?php } ?>
            </div>
            <input type="submit" name="submit" value="<?php _e('Save Changes', 'bhwd-scheda-clienti'); ?>" class="button button-primary">
            <input type="hidden" name="action" value="update">
            <input type="hidden" 
            name="page_options" 
            value="<?php 
            print implode(' , ', 
            array_keys($bhwd_admin_page_fields)
            ); 
            ?> , bhwd-scheda-form-list , <?php 
            echo implode(' , ', 
            array_map(
                function($field) {
                     return preg_replace('/[\s-]+/', 
                     '-', 
                     strtolower(
                        trim($field)
                        )
                    ); 
                }, 
            $scheda_clainti_form_list)
            ); 
            ?>">
        </form>
    </div>
    <?php
}