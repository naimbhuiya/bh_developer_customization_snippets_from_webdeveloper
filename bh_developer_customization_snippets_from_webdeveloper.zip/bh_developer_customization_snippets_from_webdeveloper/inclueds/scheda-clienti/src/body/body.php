<?php

/**
 * Name: Scheda Clineti body,
 */
function bhwd_scheada_clinti_body_scripts() {

        wp_enqueue_script(
        'bhwd-jq-toast',
        plugins_url( __FILE__ ) . 'jquery.toast.js',
        array('jquery'),
        '1.0.0',
        true // Load in footer
    );

    wp_enqueue_style( 'bhwd-jq-toast-css', plugins_url( __FILE__ ) . "jquery.toast.css", array(), true);
    // Enqueue CSS
    wp_enqueue_style(
        'bhwd-scheda-clienti-body-css',
        plugins_url('style.css', __FILE__),
        [],
        '1.0.0',
        'all'
    );

    // Enqueue JS
    wp_enqueue_script(
        'bhwd-scheda-clienti-body-js',
        plugins_url('script.js', __FILE__),
        ['jquery'],
        '1.0.0',
        true
    );
        // Enqueue Popper.js


    // Localize script with dynamic tab data
    $tabs = get_option('bhwd-scheda-form-list', '');
    $parent_options_title = get_option( 'parent-tab-title', "Prodotto Desiderato" ) ;
    wp_localize_script('bhwd-scheda-clienti-body-js', 'schedaTab', [
        'ajxUrl' => admin_url( "admin-ajax.php" ),
        'nonce' => wp_create_nonce( 'bhwd_email_nonce' ),
        'tabs' => !empty($tabs) ? explode(',', $tabs) : [] ,
        "parentTabTitle" => $parent_options_title , 
        "field" => bhwd_get_scheda_form_list(),
        "fileLocation" => plugin_dir_url( __FILE__ ),
        "formTitle" => get_option( "bhwd-form-title", "Fill The information"),
        "submitButtonText" => get_option( "bhwd-form-submit-text", "submit" ),
        "not_fillup_form" => get_option( "not_fillup_form", "Please Fill Up Name , E-mail , Telephone , City.."),
        "nameLabel" => get_option( "bhwd-name-label", "Nome e cognome" ),
        "emailLabel" => get_option( "bhwd-email-label", "E-mail" ),
        "phoneLabel" => get_option( "bhwd-phone-label", "Telefono" ),
        "cityLabel" => get_option( "bhwd-city-label", "Città" ),
        "subject" => get_option('bhwd-scheda-form-subject', 'Scheda From: New Form Submission')

    ]);
}

add_action('wp_enqueue_scripts', 'bhwd_scheada_clinti_body_scripts' , 10);

function bhwd_get_scheda_form_data() {
    // Get the option from the database
    $get_option = isset($_GET['get_op']) ? sanitize_text_field($_GET['get_op']) : '';
    
    // Retrieve the option value from the database (it should be an array)
    $data = get_option($get_option, []);
    // Send JSON response
    wp_send_json($data);
}

add_action('wp_ajax_bhwd_get_scheda_form_data', 'bhwd_get_scheda_form_data');
add_action('wp_ajax_nopriv_bhwd_get_scheda_form_data', 'bhwd_get_scheda_form_data');



function bhwd_get_scheda_form_list(){
    $scheda = [];
    $scheda_clainti_form_list = explode(' , ', get_option('bhwd-scheda-form-list', 'paquet'));
    foreach ($scheda_clainti_form_list as $field) { 
         $field_name = preg_replace('/[\s-]+/', '-', strtolower(trim($field)));
        $scheda[$field_name]["data"] = get_option( $field , "paquet");
        return $scheda ;
    }
    return $scheda ;
}

/**
 * BHWD create database table 
 */




function bhwd_send_email_via_ajax() {
    // Debug: Log the request
    error_log('AJAX Request Received');

    // Verify nonce for security
    if (!isset($_POST['nonce'])) {
        error_log('Nonce not set');
        wp_send_json_error(array(
            "is" => "err",
            "msg" => 'un authority'
        ));
    }

    if (!wp_verify_nonce($_POST['nonce'], 'bhwd_email_nonce')) {
        error_log('Invalid nonce');
        wp_send_json_error('Invalid nonce.');
    }

    // Get data from the AJAX request
    $isData = $_POST['formData'];
    $subject = $_POST['subject'];

    $response = [];

    if ($isData && is_array($isData) && !empty($isData)) {
        $email = '';
        $schedaName = '';
        $html = '<div>';

        $data = array();
        // Loop through the form data to extract values
        foreach ($isData as $item) {
            switch ($item['label']) {
                case 'scheda-email' :
                    case 'email':
                    $email = sanitize_email($item['value']);
                    $data['email'] = $email;
                     $html .= '<p><strong>' . bhwd_convert_slug_to_text(esc_html($item['label']) ). ':</strong> ' . esc_html($item['value']) . '</p>';
                    break;
                case 'scheda-name' : 
                    case "name":
                    $schedaName = sanitize_text_field($item['value']);
                    $data['name'] = $schedaName;
                     $html .= '<p><strong>' . bhwd_convert_slug_to_text(esc_html($item['label']) ). ':</strong> ' . esc_html($item['value']) . '</p>';
                    break;
                case 'scheda-telephone' :
                    case "phone":
                    $data['telephone'] = sanitize_text_field($item['value']);
                     $html .= '<p><strong>' . bhwd_convert_slug_to_text(esc_html($item['label']) ). ':</strong> ' . esc_html($item['value']) . '</p>';
                    break;
                case 'scheda-city':
                    $data['city'] = sanitize_text_field($item['value']);
                     $html .= '<p><strong>' . bhwd_convert_slug_to_text(esc_html($item['label']) ). ':</strong> ' . esc_html($item['value']) . '</p>';
                    break;
                default:
                    // Add all fields to the email body
                    $html .= '<p><strong>' . bhwd_convert_slug_to_text(esc_html($item['label']) ). ':</strong> ' . esc_html($item['value']) . '</p>';
                    break;
            }
        }

        $html .= '</div>';
        $data['message'] = $html;

        // Validate input
        if (empty($email)) {
            error_log('Email field is empty');
            $response["is"] = 'warn' ;
            $response["msg"] = get_option( "email_is_rqd", 'Email field is required.') ;
            
            wp_send_json_error($response);
        }

        // Save data to the database
        // Construct the email subject
        // $subject = get_option('bhwd-scheda-form-subject', 'Scheda From: New Form Submission');
        if (!empty($schedaName)) {
            $subject .= ' from ' . $schedaName;
        }

        // Send the email
        $headers = array('Content-Type: text/html; charset=UTF-8');
        $sent = wp_mail(get_option('admin_email'), $subject, $html, $headers);

        // Return a response
        if ($sent) {
            error_log('Email sent successfully');
             $response["is"] = 'success' ;
            $response["msg"] = get_option( "email_sent_successfully", 'Email sent successfully! ') ;
            wp_send_json_success(  $response );
        } else {
            error_log('Failed to send email');
            $response["is"] = 'err' ;
            $response["msg"] = get_option( "email_sent_failed", 'Failed to send email.') ;
            wp_send_json_error( $response);
        }
    } else {
        error_log('Form data is empty or invalid');
        $response["is"] = 'warn' ;
        $response["msg"] = get_option( "not_fillup_form", 'Your Data is False') ;
        wp_send_json_error( $response);
    }
}

// Hook the function to WordPress AJAX actions
add_action('wp_ajax_bhwd_send_email', 'bhwd_send_email_via_ajax'); // For logged-in users
add_action('wp_ajax_nopriv_bhwd_send_email', 'bhwd_send_email_via_ajax'); // For non-logged-in users
/**
 * Convert a PHP-style array string into a valid JSON object.
 */
function bhwd_convert_slug_to_text($slug) {
    // Replace hyphens with spaces
    $text = str_replace('-', ' ', $slug);

    // Capitalize first letter of each word
    $text = ucwords($text);

    return $text;
}
function bhwd_scheda_clinti_main() {
    ?>
    <div class="bhwd_scheada_clinti_main"> 
        <?php
        bhwd_scheada_clinti_main_header_section();
        bhwd_scheada_clinti_main_body_section();
        ?>
    </div>
    <?php
}

function bhwd_scheada_clinti_main_header_section() {
    ?>
    <div class="bhwd-scheda-clienti-body-head d-flex justify-content-end">
        
    </div>
    <?php
}

function bhwd_scheada_clinti_main_body_section() {
    ?>
    <div id="" class="container-fluid bhwd-bg-gray bhwd-scheda-clienti-form-conatiner p-0 bhwd-rounded-30 overflow-hidden ">
        <div class="row bhwd-scheda-clienti-form-body p-0" id="bhwd-scheda-clienti-form-body" >

        </div>
    </div>
    <?php
}
