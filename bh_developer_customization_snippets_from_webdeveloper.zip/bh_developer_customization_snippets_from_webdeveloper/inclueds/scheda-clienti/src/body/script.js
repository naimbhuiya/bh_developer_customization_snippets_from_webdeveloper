let bhwdFunctions = {};
jQuery(function ($) {
  /**
   * Select DOM Elements
   */
  const $bhwdMainContainer = $("#bhwd-scheda-clienti-form-body");

  /**
   * Scheda Form Data
   */

  /**
   * Generate slug from title
   */
  function generateSlug(text) {
    return text
      .toLowerCase()
      .trim()
      .replace(/[\s-]+/g, "-");
  }

  /**
   * Get Tabs Info
   */
  function getTabsInfo() {
    return schedaTab.tabs.map((title) => ({
      title: title.trim(),
      name: generateSlug(title),
    }));
  }
  bhwdBodyHeaderRender();
  function bhwdBodyHeaderRender() {
    let $html = `<div class="bhwd-scheda-clienti-main-title">
            <h2 class="bhwd-scheda-main-head-title">Parquet</h2>
        </div>`;
    $(".bhwd-scheda-clienti-body-head").html($html);
  }

  /**
   * Append Tabs to Container
   */
  function appendTabs() {
    // Create tab column
    const $tabCol = $("<div>")
      .addClass("col-md-2 bhwdCollamn")
      .append($("<h2>").addClass("px-2 pt-3").text(schedaTab.parentTabTitle));

    // Create tab container
    const $tabContainer = $("<div>").addClass(
      "col-md-10 row bhwd-tab-container__ me-0 p-0"
    );

    // Append columns to the main container
    $bhwdMainContainer.append($tabCol, $tabContainer);

    // Fetch initial tab data
    fetchTabData(false);
    let $carouselDiv = $("<div>");
    $carouselDiv.addClass("bhwdCustomClassForMainDiv");
    // Append the button to the container
    $tabCol.append($carouselDiv);

    // Create and append tab buttons
    getTabsInfo().forEach((tab, index) => {
      const $button = $(
        `<button data-name="${tab.name}">${tab.title}</button>`
      ).addClass(`bhwd-scheda-tab main-tabs bhwd-scheda-tab-${tab.name}`);

      // Add 'bhwd-active-tab' class to the first button
      if (index === 0) {
        $button.addClass("bhwd-active-tab");
      }
      $carouselDiv.append($button);
    });
    let $bhwdBodyHeadTitle = $(".bhwd-scheda-main-head-title");

    // Add a single event listener for all buttons using event delegation
    $tabCol.on("click", ".bhwd-scheda-tab", function () {
      // Remove the active class from all buttons
      $tabCol.find(".bhwd-scheda-tab").removeClass("bhwd-active-tab");

      // Add the active class to the clicked button
      $(this).addClass("bhwd-active-tab");
      $bhwdBodyHeadTitle.text($(this).text());
      // Update form data

      // Fetch tab data
      fetchTabData($(this).data("name"));
    });
  }

  /**
   * Fetch JSON Data
   */
  function fetchTabData(tabId) {
    const jsonUrl = `${schedaTab.fileLocation}scheda.json`;

    $.getJSON(jsonUrl, function (data) {
      const tabData = tabId ? data.find((item) => item.id === tabId) : data[0];
      if (tabData) {
        processTabData(tabData);
      }
    }).fail((err) => console.error("Error fetching JSON:", err));
  }

  /**
   * Process JSON Data
   */
  function processTabData(tabData) {
    if (tabData.isSub) {
      renderSubTabs(tabData);
    } else {
      $(".bhwd-tab-container__").empty();
      renderForm(tabData.form, tabData.class.formMainClass);
    }
  }

  /**
   * Render Sub Tabs
   */
  function renderSubTabs(item) {
    const $bhwdTabContainer = $(".bhwd-tab-container__");
    $bhwdTabContainer.empty();

    // Create sub-tab container
    const $subTabContainer = $("<div>")
      .addClass(`col-md-2 ${item.class.container}`)
      .append($("<h2>").text(item.title));
    let $carouselDiv = $("<div>");
    $carouselDiv.addClass("bhwdCustomClassForMainDiv");
    $subTabContainer.append($carouselDiv);
    // Append sub-tab buttons
    item.subItems.forEach((subTab, index) => {
      if (!subTab.isSub) {
        const $subButton = $(
          `<button data-name="${generateSlug(subTab.title)}">${
            subTab.title
          }</button>`
        ).addClass(
          `bhwd-scheda-tab ${
            index == 0 ? "bhwd-active-sub-tab" : ""
          } bhwd-scheda-subTabs bhwd-scheda-tab-${generateSlug(subTab.title)}`
        );

        // Append the button to the container
        $carouselDiv.append($subButton);
      }
    });

    // Add a single event listener for all buttons using event delegation
    $subTabContainer.on("click", ".bhwd-scheda-subTabs", function () {
      // Remove the active class from all buttons
      $subTabContainer
        .find(".bhwd-scheda-subTabs")
        .removeClass("bhwd-active-sub-tab");

      // Add the active class to the clicked button
      $(this).addClass("bhwd-active-sub-tab");

      // Fetch tab data
      fetchTabData($(this).data("name"));
    });

    // Append the sub-tab container to the main container
    $bhwdTabContainer.append($subTabContainer);

    // Render the form
    renderForm(item.form, item.class.formMainClass);
  }

  /**
   * Render Contact Form
   */
  function renderForm(fields, formClass) {
    const $bhwdTabContainer = $(".bhwd-tab-container__");
    const $formContainer = $("<div>").addClass(
      `bhwd-scheda-contact-form col-md m-0 p-0 ${formClass}`
    );

    const $header = $("<div>")
      .addClass("scheda-contact-form-header bhwd-bg-black pt-2 pb-2 ps-3 pe-3")
      .append(
        $("<h2>")
          .addClass("scheda-contact-form-title mb-0 pb-0 text-light")
          .text(schedaTab.formTitle)
      );

    const $formBody = $("<div>").addClass(
      "scheda-contact-form-body pt-2 pb-2 ps-3 pe-3"
    );

    // Append form fields
    fields.forEach((field) => {
      const $field = createFormField(field);
      $formBody.append($field);
    });

    $formContainer.append($header, $formBody);
    bhwdSubmitButton($formBody);
    $bhwdTabContainer.append($formContainer);

    // Cache the jQuery objects
    const $radios = $(".change-field-condition-using-radios");
    const $textFields = $(".change-field-condition-in-text-field");

    // Add event delegation for radio buttons
    $radios.on("change", function () {
      // Get the index of the current radio button
      const index = parseInt($radios.index(this));
      let selector = this;
      // Find the corresponding text field
      const $textField = $textFields.eq(index);
      $(".bhwd-scheda-form-field[type='radio']").each(function (i, e) {
        $(e).on("change", function () {
          if ($(selector).is(":checked")) {
            $textField.removeAttr("disabled");
          } else {
            $textField.attr("disabled", true);
          }
        });
      });
      // console.log(`checked`);

      // // Enable or disable the text field based on the radio button value
      if ($(this).is(":checked")) {
        $textField.removeAttr("disabled");
      } else {
        $textField.attr("disabled", true);
      }
    });
  }

  /**
   * Create Form Field
   */
  function createFormField(field) {
    const $fieldGroup = $("<div>").addClass("form-group mb-3");

    switch (field.type) {
      case "textarea":
        let $label = $("<label>")
          .attr("for", field.name)
          .addClass("form-check-label")
          .text(field.label);
        let $textarea = $("<textarea>")
          .addClass(
            `${field.class} rounded bhwd-scheda-form-field textarea-${field.name}`
          )
          .attr("name", field.name);

        $fieldGroup.append($label, $textarea);
        break;
      case "select":
        const $select = $("<select>")
          .attr("name", field.name)
          .attr("id", field.name)
          .addClass("form-control bhwd-scheda-form-field");

        field.options.forEach((option) => {
          $select.append($("<option>").val(option.value).text(option.label));
        });

        $fieldGroup.append(
          $("<label>")
            .attr("for", field.name)
            .addClass("form-check-label")
            .text(field.label),
          $select
        );
        break;

      case "radio":
      case "checkbox":
        const $inputContainer = $("<div>").addClass(
          "ms-3 d-flex flex-wrap radios"
        );

        field.options.forEach((option) => {
          let $bhwdRadiosContainer = $("<div>").addClass(
            "me-3 d-flex align-items-center"
          );
          const $input = $("<input>")
            .attr("type", field.type)
            .attr("name", `${field.name}`)
            .attr("id", `${field.name}-${option.value}`)
            .attr("value", option.value)
            .addClass(
              `bhwd-scheda-form-field rounded-pill mt-0 ${field.class} ${
                option.openField ? "change-field-condition-using-radios" : ""
              }`
            );

          if (option.checked) {
            $input.attr("checked", option.checked);
          }

          const $label = $("<label>")
            .attr("for", `${field.name}-${option.value}`)
            .text(option.label)
            .addClass("form-check-label ms-1");

          $bhwdRadiosContainer.append($input, $label);

          $inputContainer.append($bhwdRadiosContainer);
        });
        $fieldGroup.removeClass("form-group");
        $fieldGroup.addClass("d-flex align-items-center");
        $fieldGroup.append(
          $("<label>").addClass("form-check-label").text(field.label),
          $inputContainer
        );
        break;

      case "santraOrDastra":
        conditionalSchedaRadiosValue($fieldGroup, field.radiosButton);
        break;
      case "moleAndMemory":
        conditionalSchedaRadiosValue($fieldGroup, field.radiosButton);
        break;

      default:
        const $input = $("<input>")
          .attr("type", field.type)
          .attr("data-title", field.name)
          .attr("name", generateSlug(field.name))
          .attr("id", generateSlug(field.name))
          .attr("placholder", field.placholder ? field.placholder : "")
          .addClass(
            "form-control bhwd-scheda-form-field rounded-pill " + field.class
          );

        if (field.disabled) {
          $input.attr("disabled", true);
        }
        $fieldGroup.append(
          $("<label>")
            .attr("for", field.name)
            .addClass("form-check-label")
            .text(field.label),
          $input
        );
        break;
    }

    return $fieldGroup;
  }

  /**
   * Function for submit button
   */
  function bhwdSubmitButton(append) {
    let $bhwdsubmitContainer = $("<div>").addClass(
      "d-flex justify-content-between"
    );
    let $bhwdLoader = $("<div>").addClass("bhwd-loader");
    let $loader = `
      <div class="spinner-border text-danger" role="status">
        <span class="visually-hidden">Loading...</span>
      </div>
      `;
    // $bhwdLoader.html($loader);
    let $bhwdSubmit = $("<div>").addClass("bhwd-submit");
    let $bhwdSubmitButton = $("<input>")
      .attr("type", "submit")
      .attr("value", schedaTab.submitButtonText)
      .addClass("bhwdSchedaSubmitButton bg-dark text-white rounded-pill");
    $bhwdSubmit.append($bhwdSubmitButton);
    $bhwdsubmitContainer.append($bhwdLoader, $bhwdSubmit);
    append.append($bhwdsubmitContainer);

    // Handle form submission
    $bhwdSubmitButton.on("click", function () {
      if (bhwdFunctions.validateAllInputFields().isValid) {
        bhwdSendEmail(bhwdSchedaFromData(), $bhwdLoader, $loader);
      } else {
        bhwdPopUpFun(
          "Warning",
          null,
          bhwdFunctions.validateAllInputFields().content
        );
      }
    });
  }

  function conditionalSchedaRadiosValue(mainContainer, element) {
    // Create the buttons container
    const $buttonsContainer = $("<div>").addClass("d-flex flex-wrap");

    let $label = $("<p>");
    $label.text("Sensi di apertura");
    $label.addClass("formTitle w-100");
    $buttonsContainer.append($label);
    // Create the Santra button
    $(element).each(function (i, el) {
      const $conditionalSchedaRadiosValueButtons = $("<button>")
        .addClass(
          `conditionalSchedaRadiosValue rounded-pill me-2 text-white ${
            i === 0 ? "conditionalSchedaRadiosValue-was-selected" : ""
          }`
        )
        .text(el.label);

      // Append buttons to the container
      $buttonsContainer.append($conditionalSchedaRadiosValueButtons);
    });

    // Append the container to the main container
    $(mainContainer).append($buttonsContainer);

    // Add event delegation for button clicks
    $buttonsContainer.on("click", ".conditionalSchedaRadiosValue", function () {
      // Remove the selected class from all buttons
      $buttonsContainer
        .find(".conditionalSchedaRadiosValue")
        .removeClass("conditionalSchedaRadiosValue-was-selected");

      // Add the selected class to the clicked button
      $(this).addClass("conditionalSchedaRadiosValue-was-selected ");
    });
  }

  /**
   * Collect Form Data
   */

  function bhwdSchedaFromData($bhwdLoder, $loder) {
    let formData = [];
    let subtabData = $(".bhwd-active-sub-tab");

    $(".bhwd-active-tab").each(function (i, el) {
      formData.push({
        label: $(el).text(),
        value: $(el).text(),
      });
    });

    $(subtabData).each(function (i, el) {
      formData.push({
        label: $(el).text(),
        value: $(el).text(),
      });
    });
    if ($(".conditionalSchedaRadiosValue-was-selected")) {
      $(".conditionalSchedaRadiosValue-was-selected").each(function () {
        formData.push({
          label: $(this).text(),
          value: $(this).text(),
        });
      });
    }

    $(".bhwd-scheda-form-field").each(function () {
      let fieldType = $(this).attr("type");
      let fieldName = $(this).attr("name");
      let fieldValue = $(this).val();

      // Handle radio buttons correctly
      if (fieldType === "radio") {
        if ($(this).is(":checked")) {
          formData.push({ label: fieldName, value: fieldValue });
        }
      } else {
        // For all other input types
        if (!$(this).attr("disabled")) {
          formData.push({ label: fieldName, value: fieldValue });
        }
        // if ($(this).val().trim() !== "") {

        // }
      }
    });

    console.log(formData);
    if (bhwdFunctions.validateAllInputFields().isValid) {
      return formData;
    } else {
      // alert("Please before fill up header form");
      bhwdPopUpFun(
        "Warning",
        null,
        bhwdFunctions.validateAllInputFields().content
      );
    }
    return false;
  }

  bhwdFunctions.validateAllInputFields = function (bhwdClass) {
    isValidateInputFields = true;
    let contents = [];
    $(
      bhwdClass && typeof bhwdClass === "string" && bhwdClass.trim() !== ""
        ? `${bhwdClass.trim()}`
        : ".bhwd-head-input-field"
    ).each(function (index, element) {
      let getElementType = $(element).attr("type");
      let value = $(element).val() || $(element).attr("value");

      switch (getElementType) {
        case "text":
          let textIsValid = bhwdFunctions.checkNameInputField(value);
          contents.push({
            label:
              getElementType && $(element).attr("name") == "scheda-name"
                ? schedaTab.nameLabel
                : getElementType && $(element).attr("name") == "scheda-city"
                ? schedaTab.emailLabel
                : getElementType,
            value: value,
          });

          if (!textIsValid) isValidateInputFields = false;
          break;
        case "email":
          let emailIsValid = bhwdFunctions.checkEmailInputField(value);
          contents.push({
            label:
              getElementType && $(element).attr("name") == "scheda-email"
                ? schedaTab.emailLabel
                : getElementType,
            value: value,
          });

          if (!emailIsValid) isValidateInputFields = false;
          break;
        case "tel":
          let phoneIsValid = bhwdFunctions.checkPhoneInputField(value);
          contents.push({
            label:
              getElementType && $(element).attr("name") == "scheda-telephone"
                ? schedaTab.phoneLabel
                : getElementType,
            value: value,
          });

          if (!phoneIsValid) isValidateInputFields = false;
          break;
        default:
          contents.push({
            label:
              getElementType && $(element).attr("name") == "scheda-city"
                ? schedaTab.cityLabel
                : getElementType,
            value: value,
          });
          isValidateInputFields = false;
          break;
      }
    });
    let returndElement = {
      isValid: isValidateInputFields,
      content: contents,
    };
    // console.log(returndElement);

    return returndElement;
  };

  /**
   * Check name input field value and show/hide error message.
   */
  bhwdFunctions.checkNameInputField = function (value) {
    const nameRegex = /^[A-Za-z\s-]{2,}$/;
    return nameRegex.test(value);
  };

  /**
   * Check email input field value and show/hide error message.
   */
  bhwdFunctions.checkEmailInputField = function (value) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(value);
  };

  /**
   * Check phone input field value and show/hide error message.
   */
  bhwdFunctions.checkPhoneInputField = function (value) {
    const phoneRegex = /^[0-9]{10,}$/;
    value = value.replace(/\D/g, ""); // Remove all non-numeric characters
    return phoneRegex.test(value);
  };

  function bhwdPopUpFun(title, condition, content) {
    let condtionClass = "";
    let errColor = "";

    // Determine the condition class and error color
    switch (condition) {
      case true:
        condtionClass = `border border-success`;
        errColor = "#009432";
        break;
      case false:
        condtionClass = `border border-danger`;
        errColor = "#ff0000";
        break;
      case null:
        condtionClass = `border border-warning`;
        errColor = "#EAB543";
        break;
      default:
        condtionClass = `border border-primary`;
        errColor = "#00a8ff";
    }

    // Generate the list of content items
    function contentList() {
      let listItems = "";
      content.forEach((item) => {
        listItems += `<li class="list-group-item">${item.label} : ${item.value}</li>`;
        console.log(item.value);
      });
      return listItems;
    }

    // Create the modal structure
    const $modal = $(`
        <div class="modal fade" id="bhwdPopUpModal" tabindex="-1" aria-labelledby="bhwdPopUpModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content popupWidth ${condtionClass}">
                    <div class="modal-header">
                        <h1 class="modal-title fs-5" style="color: ${errColor};" id="bhwdPopUpModalLabel">
                            ${title ? title : "Info"}
                        </h1>
                        <button type="button" class="bhwdPopUpModalClose btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <p class="bhwdHeaderFieldMessage" >${
                          schedaTab.not_fillup_form
                        }</p>
                        <ul class="list-group ms-0 ">
                            ${contentList()}
                        </ul>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="bhwdPopUpModalClose btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    </div>
                </div>
            </div>
        </div>
    `);

    // Append the modal to the body
    $("body").append($modal);

    // Example: Trigger the modal to show
    $("#bhwdPopUpModal").addClass("show d-flex align-items-center");
    $(".bhwdPopUpModalClose").each(function () {
      $(this).on("click", function () {
        $("#bhwdPopUpModal").removeClass("show d-flex align-items-center");
        $("#bhwdPopUpModal").remove();
      });
    });
  }

  function bhwdSendEmail(formData, $load, $loader) {
    $.ajax({
      url: schedaTab.ajxUrl, // WordPress AJAX URL
      type: "POST",
      data: {
        action: "bhwd_send_email", // PHP function hook
        formData: formData || {}, // Ensure formData is always an object
        nonce: schedaTab.nonce,
        subject: schedaTab.subject,
      },
      beforeSend: function () {
        if ($load && $loader) {
          $load.html($loader);
        }
      },
      success: function (response) {
        if ($load) {
          $load.empty();
        }
        bhwdFunctions.bhwdToastMessage(response.data.is, response.data.msg);
        // console.log("Email sent successfully:", response);
      },
      error: function (xhr, status, error) {
        if ($load) {
          $load.empty();
        }
        console.error("AJAX Error:", status, error);
        alert("An error occurred while sending the email. Please try again.");
      },
    });
  }

  bhwdFunctions.bhwdToastMessage = function (is, msg) {
    switch (is) {
      case "warn":
        bhwdToast("Warning", msg, "#fa983a");
        break;
      case "err":
        bhwdToast("Error", msg, "#e74c3c");
        break;
      case "success":
        bhwdToast("Success", msg, "#2ecc71");
        break;
      default:
        bhwdToast("Info", msg, "#3498db");
        break;
    }
  };

  function bhwdToast(is, msg, color) {
    // Check if a toast container already exists; if not, create one
    let $toastContainer = $(".toast-container");
    if ($toastContainer.length === 0) {
      $toastContainer = $("<div>")
        .addClass("toast-container position-fixed bottom-0 end-0 p-3")
        .attr("id", "bhwdToastContainer");
      $("body").append($toastContainer);
    }

    // Create toast element
    let $toast = $("<div>")
      .addClass("toast show align-items-center text-white border-0")
      .attr({
        role: "alert",
        "aria-live": "assertive",
        "aria-atomic": "true",
        style: `background: ${color};`,
      });

    // Create toast header
    let $toastHeader = $("<div>").addClass("toast-header text-dark text-light");
    let $strong = $("<strong>").addClass("me-auto").text(is);
    let $closeBtn = $("<button>").addClass("btn-close bhwdCloseToastMsg").attr({
      type: "button",
      "data-bs-dismiss": "toast",
      "aria-label": "Close",
    });

    // Append elements to header
    $toastHeader.append($strong, $closeBtn);

    // Create toast body
    let $toastBody = $("<div>").addClass("toast-body").text(msg);

    // Append header and body to toast
    $toast.append($toastHeader, $toastBody);

    // Append toast to container
    $toastContainer.append($toast);

    // Close toast on button click
    $closeBtn.on("click", function () {
      $toast.fadeOut(300, function () {
        $(this).remove();
      });
    });

    // Auto-remove after 5 seconds
    setTimeout(function () {
      $toast.fadeOut(300, function () {
        $(this).remove();
      });
    }, 5000);
  }

  // Initialize
  appendTabs();
});
