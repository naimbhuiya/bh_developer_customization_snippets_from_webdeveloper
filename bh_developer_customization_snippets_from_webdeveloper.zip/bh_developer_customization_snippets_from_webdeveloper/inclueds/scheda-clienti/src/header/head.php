<?php 
/**
 * SRC: Scheada clienti
 * Section Name : Header 
 * 
 */

/**
 * Enqueue script and style
 */
function scheada_clinti_header_scripts() {
    wp_enqueue_style(
        'bhwd-scheda-clienti-css',
        plugins_url('style.css', __FILE__),
        array(),
        '1.0.0',
        'all'
    );
    wp_enqueue_script(
        'bhwd-scheda-clienti-js',
        plugins_url('script.js', __FILE__),
        array('jquery'),
        '1.0.0',
        true
    );

    wp_localize_script( 'bhwd-scheda-clienti-js', 'dataMsg', array(
        'ajaxurl' => admin_url( 'admin-ajax.php' ),
        'security' => wp_create_nonce( 'bhwd-scheda-clienti-nonce' ),
        'messages' => [ 
            'formHeader'=> [
                'success' => __( get_option( 'bhwd-message-section-header-field-success', 'Tutte le informazioni sono corrette.' ), 'bhdcsfw' ),
                'error' => __( get_option( 'bhwd-message-section-header-field-error', 'Ci sono errori nel tuo nome, indirizzo email, numero di telefono e informazioni sulla città.'), 'bhdcsfw' ),
            ],
        ],
    ) );
}

add_action('wp_enqueue_scripts', 'scheada_clinti_header_scripts');

/// sheda-clineti header section
function scheada_clinti_header_section(){
    ?>
    <div class="bhwd-rounded-30 overflow-hidden">
        <div class="bhwd-scheda-clienti-header-main bhwd-bg-black bhwd-p-x-m-0 container-fluid">
        <div class="bhwd-scheda-clienti-header-head bhwd-bg-gray row">
            <div class="bhwd-scheda-clienti-header-head-title col-md-5 bhwd-bg-black d-flex justify-content-center align-items-center bhwd-rounded-bottom-last-30">
                <?php scheada_clinti_header_title(); ?>
            </div>
            <div class="col-md-7 bhwd-bg-black bhwd-p-x-m-0" style="padding: 0;">
                <div class="bhwd-height-100 bhwd-width-100 bhwd-bg-gray bhwd-rounded-top-first-30"></div>
            </div>
        </div>
        <div class="bhwd-scheda-clienti-header-body pt-5 pb-5 pe-2 ps-2 bhwd-bg-gray bhwd-rounded-top-first-30 row" >
            <div class="col-md-6 bhwdResponsiveCollamn">
                <div class="bhwd-form-header-controls">
                    <?php scheada_clinti_header_body_left(); ?>
                </div>
            </div>
            <div class="col-md-6 bhwdResponsiveCollamn">
                <?php scheada_clinti_header_body_rigth(); ?>
            </div>
        </div>
    </div>
    </div>
    <?php
}

/// sheda-clineti header section
function scheada_clinti_header_title(){
    ?><h2 class="bhwd-scheda-head-title ">
        <?php echo _e( get_option( 'bhwd-page-titte', 'Scheda Clienti') , 'bhdcsfw'); ?>
    </h2>
    <?php
}

/// sheda-clineti header section
function scheada_clinti_header_body_left(){
    $bhwd_scheada_clinti_header = array(
        'name' => [
            'label' => 'Name',
            'placeholder' => 'Name',
            'type' => 'text',
            'required' => true,
        ],
        'email' => [
            'label' => 'Email',
            'placeholder' => 'Email',
            'type' => 'email',
        ],
        'telephone' => [
            'label' => 'Telephone',
            'placeholder' => 'Telephone',
            'type' => 'tel',
        ],
        'city' => [
            'label' => 'City',
            'placeholder' => 'City',
            'type' => 'text',
        ]
    );
    foreach ($bhwd_scheada_clinti_header as $key => $value) {
        ?>
        <div>
            <label for="scheda-<?php echo $key; ?>"><?php echo $value['label']; ?></label>
            <div class="bhwd-input-fields">
                <input type="<?php echo $value['type']; ?>" name="scheda-<?php echo $key; ?>" class="bhwd-head-input-field bhwd-scheda-form-field" placeholder="<?php echo $value['placeholder']; ?>" >
                <span class="bhwd-true-or-false"><i class="fa fa-times" aria-hidden="true"></i></span> 
            </div>  
        </div>  
        <?php
    }
}

/// sheda-clineti header section
function scheada_clinti_header_body_rigth(){
    ?>
    <h2 class="bhwd-header-title" ><?php echo _e( get_option( 'bhwd-error-section-title', 'Il Tracciato Da è valido') , 'bhdcsfw'); ?></h2>
    <ul class="list-group m-0 p-0 bg-none" style="background: none; border: none;">
        <li class="list-group-item" style="background: none; border: none;">
            <span>
                <span class="bhwd-header-information-is-valid">
                    <i class="far fa-times-circle" style="color:rgb(255, 0, 0);" aria-hidden="true"></i>
                </span> 
                <span class="bhwd-header-information-is-valid-text">
                    <?php echo _e( get_option( 'bhwd-message-section-header-field-error', 'Ci sono errori nel tuo nome, indirizzo email, numero di telefono e informazioni sulla città.' ), 'bhdcsfw' ) ?>
                </span>
            </span>
        </li>
        <li class="list-group-item" style="background: none; border: none;"><?php echo _e(get_option( 'requird_fillup_form', "Are not fill up a single fiald in form" )) ?></li>
    </ul>
    <?php
}