jQuery(function ($) {
  let message = dataMsg.messages;
  let isValidateInputFields = false;
  let bhwdHeadInputFields = $(".bhwd-head-input-field");
  let bhwdSeeFieldIsValid = $(".bhwd-true-or-false");

  /**
   * Add event listener to input fields
   */
  $(bhwdHeadInputFields).each(function (index, element) {
    $(element).on("input", function () {
      headerInformationIsValid(validateAllInputFields());
    });
  });

  /**
   * Validate all input fields
   */
  function validateAllInputFields() {
    isValidateInputFields = true;
    $(bhwdHeadInputFields).each(function (index, element) {
      let getElementType = $(element).attr("type");
      let value = $(element).val();
      switch (getElementType) {
        case "text":
          let textIsValid = checkNameInputField(value);
          updateFieldStatus(element, textIsValid, index);
          if (!textIsValid) isValidateInputFields = false;
          break;
        case "email":
          let emailIsValid = checkEmailInputField(value);
          updateFieldStatus(element, emailIsValid, index);
          if (!emailIsValid) isValidateInputFields = false;
          break;
        case "tel":
          let phoneIsValid = checkPhoneInputField(value);
          updateFieldStatus(element, phoneIsValid, index);
          if (!phoneIsValid) isValidateInputFields = false;
          break;
        default:
          isValidateInputFields = false;
          break;
      }
    });
    return isValidateInputFields;
  }

  /**
   * Check name input field value and show/hide error message.
   */
  function checkNameInputField(value) {
    const nameRegex = /^[A-Za-z\s-]{2,}$/;
    return nameRegex.test(value);
  }

  /**
   * Check email input field value and show/hide error message.
   */
  function checkEmailInputField(value) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(value);
  }

  /**
   * Check phone input field value and show/hide error message.
   */
  function checkPhoneInputField(value) {
    const phoneRegex = /^[0-9]{10,}$/;
    value = value.replace(/\D/g, ""); // Remove all non-numeric characters
    return phoneRegex.test(value);
  }

  /**
   * Update field status based on validation result.
   */
  function updateFieldStatus(element, isValid, index) {
    if (isValid) {
      $(bhwdSeeFieldIsValid[index]).html(
        '<i style="color: #2ecc71;" class="fas fa-check"></i>'
      );
      $(element).removeClass("error").addClass("success");
    } else {
      $(bhwdSeeFieldIsValid[index]).html(
        '<i class="fa fa-times" aria-hidden="true"></i>'
      );
      $(element).removeClass("success").addClass("error");
    }
  }

  /**
   * Header information is valid or not
   */
  function headerInformationIsValid(isValid) {
    if (!isValid) {
      $(".bhwd-header-information-is-valid").html(
        '<i class="far fa-times-circle" style="color:rgb(255, 0, 0);" aria-hidden="true"></i>'
      );
      $(".bhwd-header-information-is-valid-text").text(
        message.formHeader.error
      );
    } else {
      $(".bhwd-header-information-is-valid").html(
        '<i style="color: #2ecc71;" class="fa-regular fa-circle-check"></i>'
      );
      $(".bhwd-header-information-is-valid-text").text(
        message.formHeader.success
      );
    }
  }
});
