let inmp = {};

jQuery(function ($) {
  let contactVar = cnVar;
  let $bhwdNazione = $(".bhwd-dropdown-button");
  let $bhwdDropDownContainer = $(".bhwd-dropdown-container");

  $bhwdNazione.text("Select Nazione");

  $bhwdNazione.each(function (i, e) {
    let $bhwdCnt = $bhwdDropDownContainer.eq(i);
    let $dropdown = $("<ul>").addClass(
      "bhwd-dropdown-menu p-0 shadow-sm rounded"
    );

    $bhwdCnt.append($dropdown);

    bhwdGetJsonData(`${contactVar.pUrl}countries.json`, function (data) {
      if (data && Array.isArray(data)) {
        data.forEach(function (country) {
          bhwdListItem($dropdown, {
            value: country.country_name,
            code: country.country_code,
          });
        });
      } else {
        console.error("Invalid or empty data received.");
      }
    });

    $(this).on("click", function () {
      // Toggle the dropdown menu on click
      $dropdown.toggleClass("bhwd-active");
    });
  });

  /**
   * Create and append list item to the dropdown menu
   * @param {*} parent
   * @param {*} item
   */
  function bhwdListItem(parent, item) {
    let $bhwdDropDownItem = $("<li>")
      .addClass("py-1 px-2 bhwdListItem")
      .attr("data-name", item.value)
      .attr("data-code", item.code);
    $bhwdDropDownItem.html(
      `<a class="dropdown-item" href="#">${item.value}</a>`
    );
    $(parent).append($bhwdDropDownItem);

    // Add click event to update the button text
    $bhwdDropDownItem.on("click", function (e) {
      e.preventDefault();
      $(parent).siblings(".bhwd-dropdown-button").text(item.value);
      $(parent).removeClass("bhwd-active");

      let url = `${contactVar.pUrl}Countries/${$(this).attr("data-code")}/${$(
        this
      ).attr("data-name")}.json`;
      bhwdGetJsonData(url, function (data) {
        console.log(data);

        if (data.provinces && Array.isArray(data.provinces)) {
          $("#bhwd-select-provincia").empty(); // Clear previous options
          data.provinces.forEach(function (province) {
            let $bhwdProvince = $("<option>")
              .attr("value", province.province_name)
              .text(province.province_name);
            $("#bhwd-select-provincia").append($bhwdProvince);
          });

          $("#bhwd-select-provincia")
            .off("change")
            .on("change", function () {
              let selectedProvince = $(this).val();
              let provinceData = data.provinces.find(
                (province) => province.province_name === selectedProvince
              );

              if (provinceData && provinceData.cities) {
                $("#bhwd-select-citta").empty();
                provinceData.cities.forEach(function (city) {
                  let $bhwdCity = $("<option>")
                    .attr("value", city.city_name)
                    .text(city.city_name);
                  $("#bhwd-select-citta").append($bhwdCity);
                });

                console.log(provinceData.cities);
                // Handle cities data as needed
              }
            });
        }
      });
    });
  }

  /**
   * Fetch JSON data from the given URL
   * @param {*} url
   * @param {*} callback
   */
  function bhwdGetJsonData(url, callback) {
    $.getJSON(url)
      .done(function (data) {
        callback(data);
      })
      .fail(function (jqXHR, textStatus, errorThrown) {
        console.error("Error fetching data:", textStatus, errorThrown);
        callback([]); // Return an empty array on failure
      });
  }
});
