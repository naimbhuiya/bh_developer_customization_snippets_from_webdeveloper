let inmp = {};

jQuery(function ($) {
  let contactVar = cnVar;

  $(".bhwd-form-buttons").each(function () {
    let $bhwdFormButtons = $(this);
    $bhwdFormButtons.on("click", function (e) {
      e.preventDefault();
      $(".bhwd-form-buttons").each(function () {
        $(this).removeClass("active");
      });
      $(this).addClass("active");
      bhwditalyOrNot(this, $(this).attr("country-name"));
      bhwdProvinceAppend(
        `${contactVar.pUrl}Countries/${$(this).attr("data-country")}/${$(
          this
        ).attr("country-name")}.json`
      );
    });

    /**
     * @description: Check if aboard.
     */
    if ($(this).attr("data-country") === "IT") {
      bhwdProvinceAppend(`${contactVar.pUrl}Countries/IT/Italy.json`);
    }
  });

  function bhwdListItem(parent, item) {
    let $bhwdDropDownItem = $("<li>")
      .addClass("py-1 px-2 bhwdListItem")
      .attr("data-name", item.value)
      .attr("data-code", item.code);

    $bhwdDropDownItem.html(
      `<a class="dropdown-item" href="#"><img class="me-1" src="https://flagcdn.com/20x15/${item.code.toLowerCase()}.png" />${
        item.value
      }</a>`
    );
    $(parent).append($bhwdDropDownItem);

    $bhwdDropDownItem.on("click", function (e) {
      e.preventDefault();
      $(parent).siblings(".bhwd-dropdown-button").text(item.value);
      $(parent).removeClass("bhwd-active");

      $(".bhwd-form-field-for-data#nazione").attr("value", item.value);

      let url = `${contactVar.pUrl}Countries/${$(this).attr("data-code")}/${$(
        this
      ).attr("data-name")}.json`;
      bhwdProvinceAppend(url);

      $(".bhwd-dropdown-button").text(item.value);
    });
  }

  function bhwdProvinceAppend(url) {
    bhwdGetJsonData(url, function (data) {
      if (data.provinces && Array.isArray(data.provinces)) {
        $("#bhwd-select-provincia").empty();
        let iCount = 0;
        data.provinces.forEach(function (province) {
          iCount++;
          let $bhwdProvince = $("<option>")
            .attr("value", province.province_name)
            .text(province.province_name);
          if (iCount === 1) {
            bhwdChangeCities(data, province.province_name);
          }
          $("#bhwd-select-provincia").append($bhwdProvince);
        });

        if (data.provinces.length > 0) {
          $("#bhwd-select-provincia").attr(
            "value",
            data.provinces[0].province_name
          );
        }

        $("#bhwd-select-provincia")
          .off("change")
          .on("change", function () {
            $(this).attr("value", $(this).val());
            bhwdChangeCities(data, $(this).val());
          });
      }
    });
  }
  function bhwditalyOrNot(el, cnt) {
    if ($(el).attr("data-country") !== "IT") {
      console.log($(el).val());
      if ($(".bhwd-nazione-radios-select-collamn").length === 0) {
        let $bhwdNazione = $("<div>").addClass(
          "col-md-4 bhwd-nazione-radios-select-collamn"
        );
        let $bhwdNazioneLabel = $("<label>");
        $bhwdNazioneLabel
          .attr("for", "bhwd-select-nazione")
          .addClass("form-label");

        $bhwdNazioneLabel.html(
          "Nazione " + '<span class="text-danger">*</span>'
        );
        let $bhwdNazioneContainer = $("<div>");
        let $bhwdSelect = $("<bhwd-select>")
          .addClass(
            "form-control form-select bhwd-dropdown-button w-100 d-flex justify-content-between align-items-center bhwd-form-field-for-data"
          )
          .attr("type", "bs-select")
          .attr("data-value", null)
          .attr("data-type", "nazione")
          .attr("id", "bhwd-select-nazione");
        let $bhwdNazioneUnOrderList = $("<ul>").addClass(
          "bhwd-dropdown-menu shadow-sm rounded overflow-hidden"
        );

        $bhwdNazione.append($bhwdNazioneContainer);
        $bhwdNazioneContainer.append($bhwdNazioneLabel);
        $bhwdNazioneContainer.append($bhwdSelect);
        $bhwdNazione.append($bhwdNazioneUnOrderList);
        $bhwdSelect.text("Select Country");
        if ($(this).attr("data-country") !== "IT") {
          $bhwdSelect.text(cnt);
        }
        $bhwdSelect.on("click", function () {
          $bhwdNazioneUnOrderList.toggleClass("bhwd-active");
        });
        bhwdGetJsonData(`${contactVar.pUrl}countries.json`, function (data) {
          if (data && Array.isArray(data)) {
            data.forEach(function (country) {
              bhwdListItem($bhwdNazioneUnOrderList, {
                value: country.country_name,
                code: country.country_code,
              });
            });
          } else {
            console.error("Invalid or empty data received.");
          }
        });

        $(".bhwd-nazione-provincia-citta-container").prepend($bhwdNazione);
        $(document).on("click", function (event) {
          if ($(".bhwd-dropdown-menu.bhwd-active").length) {
            if (
              !$(event.target).closest(".bhwd-dropdown-menu").length &&
              !$(event.target).closest(".bhwd-dropdown-button").length
            ) {
              $(".bhwd-dropdown-menu").removeClass("bhwd-active");
            }
          }
        });
      }
    } else {
      $(".bhwd-nazione-provincia-citta-container")
        .find(".col-md-4.bhwd-nazione-radios-select-collamn")
        .remove();
    }
  }

  function bhwdGetJsonData(url, callback) {
    $.getJSON(url)
      .done(function (data) {
        callback(data);
      })
      .fail(function (jqXHR, textStatus, errorThrown) {
        console.error("Error fetching data:", textStatus, errorThrown);
        callback([]);
      });
  }

  function bhwdChangeCities(data, value) {
    let selectedProvince = value;
    let provinceData = data.provinces.find(
      (province) => province.province_name === selectedProvince
    );

    if (provinceData && provinceData.cities) {
      $("#bhwd-select-citta").empty();
      provinceData.cities.forEach(function (city) {
        let $bhwdCity = $("<option>")
          .attr("value", city.city_name)
          .text(city.city_name);
        $("#bhwd-select-citta").append($bhwdCity);
      });

      if (provinceData.cities.length > 0) {
        $("#bhwd-select-citta").attr("value", provinceData.cities[0].city_name);
      }
    }
    $("#bhwd-select-citta")
      .off("change")
      .on("change", function () {
        $(this).attr("value", $(this).val());
      });
  }

  $(".bhwd-class-submit-button-contatti").each(function () {
    $(this).on("click", function (event) {
      event.preventDefault();
      let $privacy = $(".bhwd-form-field-for-data#privacy").is(":checked");
      let $bhwdFormFieldForData = $(
        ".bhwd-form-field-for-data#bhwd-select-citta"
      );
      let formData = bhwdGetAllDataToForm();
      if (
        !formData.isValidData ||
        $(".bhwd-form-field-for-data#messaggio").val().trim() === ""
      ) {
        bhwdFunctions.bhwdToastMessage("warn", cnVar.bhwdIfNotFillUpFields);
        return;
      }
      if ($bhwdFormFieldForData.attr("value") === "null") {
        bhwdFunctions.bhwdToastMessage("warn", cnVar.bhwdIfNotCheckedCity);
        return;
      }
      if (!$privacy) {
        bhwdFunctions.bhwdToastMessage("warn", cnVar.bhwdIfNotCheckedPrivacy);
        return;
      }

      $.ajax({
        type: "post",
        url: cnVar.ajxUrl,
        data: {
          action: "bhwd_send_email",
          formData: formData.data,
          nonce: cnVar.nonce,
          subject: cnVar.subject,
        },
        beforeSend: function () {
          let $bhwdLoder = $("<div>")
            .attr("role", "status")
            .addClass(
              "spinner-border text-primary bhwd-custom-spinner position-absolute top-50 start-50"
            );
          $bhwdLoder.html('<span class="visually-hidden">Loading...</span>');
          $(".bhwd-contatti-form-main").append($bhwdLoder);
        },
        success: function (response) {
          $(".bhwd-custom-spinner").remove();
          bhwdFunctions.bhwdToastMessage(response.data.is, response.data.msg);
          console.log(response);
        },
      });
    });
  });

  function bhwdGetAllDataToForm() {
    let isValidData = true;
    let data = [];

    $(".bhwd-form-field-for-data").each(function () {
      let getType = $(this).attr("data-type");
      let value = $(this).val();
      let isValidField = false;

      switch (getType) {
        case "email":
          isValidField = bhwdFunctions.checkEmailInputField(value);
          break;
        case "phone":
          isValidField = bhwdFunctions.checkPhoneInputField(value);
          break;
        case "name":
          isValidField = bhwdFunctions.checkNameInputField(value);
          break;
        default:
          isValidField = true;
          break;
      }

      data.push({ label: getType, value: value || $(this).attr("value") });

      if (
        !isValidField &&
        (getType === "email" || getType === "phone" || getType === "name")
      ) {
        isValidData = false;
      }
    });

    return { isValidData, data };
  }
});
