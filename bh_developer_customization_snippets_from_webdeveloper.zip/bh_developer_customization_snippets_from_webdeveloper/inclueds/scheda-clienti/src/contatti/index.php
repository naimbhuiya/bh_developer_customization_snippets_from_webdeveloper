<?php 


// if (function_exists("bhwd_custom_contact_form")) {
//   # code...
//   error_log("Plugin Name: BH developer customization snippets from webdeveloper conplicked function: bhwd_custom_contact_form");
//   return;
// }

function bhwd_contatti_enqueue_script() {
    wp_enqueue_style("bhwd_contatti_style", plugins_url('assets/style.css', __FILE__), array(), '1.0.0', 'all');
    
    wp_enqueue_script("bhwd_contatti_script", plugins_url('assets/script.js', __FILE__), array('jquery'), '1.0.0', true);

    wp_localize_script("bhwd_contatti_script", "cnVar", array(
        "ajxUrl" => admin_url( "admin-ajax.php" ),
        'nonce' => wp_create_nonce( 'bhwd_email_nonce' ),
        "pUrl" => plugin_dir_url(__FILE__),
        "bhwdIfNotFillUpFields" => get_option( "bhwd-if-not-fill-up-fields", "Inserisci correttamente email, nome, numero di telefono" ),
        "bhwdIfNotCheckedCity" => get_option( "bhwd-if-not-checked-city", "Seleziona prima nazione, provincia, città!" ),
        "bhwdIfNotCheckedPrivacy" => get_option( "bhwd-if-not-checked-privacy", "Inserisci correttamente email, nome, numero di telefono" ),
        "subject" => get_option('bhwd-contatti-form-subject', 'Contatti From: New Form Submission')
    ));
}
add_action('wp_enqueue_scripts', 'bhwd_contatti_enqueue_script' , 100);



function bhwd_custom_contact_form(){
    ob_start(); // Start output buffering
  ?>
    <div class="container bhwd-contatti-form-main mt-4">
      <form method="post" action="#" >
        
        <div class="row mb-3">
          <div class="col-md-6">
            <label for="nome" class="form-label"
              >Nome <span class="text-danger">*</span></label
            >
            <input
              type="text"
              class="form-control bhwd-form-field-for-data"
              id="nome"
              data-type="name"
              placeholder="Nome"
            />
          </div>
          <div class="col-md-6">
            <label for="cognome" class="form-label"
              >Cognome <span class="text-danger">*</span></label
            >
            <input
              type="text"
              class="form-control bhwd-form-field-for-data"
              id="cognome"
              placeholder="Cognome"
              data-type="last name"
            />
          </div>
        </div>

        <div class="row mb-3">
          <div class="col-md-6">
            <label for="email" class="form-label"
              >Email <span class="text-danger">*</span></label
            >
            <input
              type="email"
              class="form-control bhwd-form-field-for-data"
              id="email"
              data-type="email"
              placeholder="Email"
            />
          </div>
          <div class="col-md-6">
            <label for="telefono" class="form-label"
              >Telefono <span class="text-danger">*</span></label
            >
            <input
              type="tel"
              class="form-control bhwd-form-field-for-data"
              id="telefono"
              data-type="phone"
              placeholder="Telefono"
            />
          </div>
        </div>

        <div class="d-flex mt-3 mb-3">
          <input class="bhwd-form-buttons active me-2" data-country="IT" country-name="Italy" type="button" value="Italy">
          <input class="bhwd-form-buttons" type="button" data-country="AD" country-name="Andorra"  value="Abroad">
        </div>

        <div class="row mb-3 bhwd-nazione-provincia-citta-container">
         
          <div class="col-md">
            <label for="provincia" class="form-label"
              >Provincia <span class="text-danger">*</span></label
            >
            <select type="select" value="null" data-type="provincia" class="form-select bhwd-form-field-for-data" id="bhwd-select-provincia">
              <option selected>Select State</option>
            </select>
          </div>
          <div class="col-md">
            <label for="citta" class="form-label"
              >Città <span class="text-danger">*</span></label
            >
            <select value="null" data-type="citta" class="form-select bhwd-form-field-for-data" id="bhwd-select-citta">
              <option selected>Select City</option>
            </select>
          </div>
        </div>

        <div class="mb-3">
          <label for="address" class="form-label"
            >Adress </label
          >
          <input
            type="address"
            data-type="address"
            class="form-control bhwd-form-field-for-data"
            id="address"
            placeholder="address"
          />
        </div>

        <div class="mb-3">
          <label for="messaggio" class="form-label"
            >Inserire un Messaggio <span class="text-danger">*</span></label
          >
          <textarea 
            type="textarea"
            data-type="message"
            class="form-control bhwd-form-field-for-data"
            id="messaggio"
            rows="4"
            placeholder="Inserire un Messaggio"
          ></textarea>
        </div>

        <div class="d-flex justify-content-between align-items-center">
          <div class="form-check d-flex align-items-center">
            <input type="checkbox" class="form-check-input bhwd-form-field-for-data" data-type="privacy" id="privacy" />
            <label class="form-check-label ms-3"  for="privacy">Privacy</label>
          </div>

          <button type="submit" class="btn btn-danger bhwd-class-submit-button-contatti">Invia Messaggio</button>
        </div>
      </form>
    </div>

    <?php
    return ob_get_clean(); // Return buffered content
}

add_shortcode( "bhwd_contatti", "bhwd_custom_contact_form" );