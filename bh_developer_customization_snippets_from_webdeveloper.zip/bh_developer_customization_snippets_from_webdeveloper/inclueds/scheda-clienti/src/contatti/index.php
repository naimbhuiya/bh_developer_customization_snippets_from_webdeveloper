<?php 


// if (function_exists("bhwd_custom_contact_form")) {
//   # code...
//   error_log("Plugin Name: BH developer customization snippets from webdeveloper conplicked function: bhwd_custom_contact_form");
//   return;
// }

function bhwd_contatti_enqueue_script() {
    wp_enqueue_style("bhwd_contatti_style", plugins_url('assets/style.css', __FILE__), array(), '1.0.0', 'all');
    
    wp_enqueue_script("bhwd_contatti_script", plugins_url('assets/script.js', __FILE__), array('jquery'), '1.0.0', true);

    wp_localize_script("bhwd_contatti_script", "cnVar", array(
        "pUrl" => plugin_dir_url(__FILE__)
    ));
}
add_action('wp_enqueue_scripts', 'bhwd_contatti_enqueue_script');



function bhwd_custom_contact_form(){

  ?>
    <div class="container mt-4">
      <form>
        <div class="row mb-3">
          <div class="col-md-6">
            <label for="nome" class="form-label"
              >Nome <span class="text-danger">*</span></label
            >
            <input
              type="text"
              class="form-control"
              id="nome"
              placeholder="Nome"
            />
          </div>
          <div class="col-md-6">
            <label for="cognome" class="form-label"
              >Cognome <span class="text-danger">*</span></label
            >
            <input
              type="text"
              class="form-control"
              id="cognome"
              placeholder="Cognome"
            />
          </div>
        </div>

        <div class="row mb-3">
          <div class="col-md-6">
            <label for="email" class="form-label"
              >Email <span class="text-danger">*</span></label
            >
            <input
              type="email"
              class="form-control"
              id="email"
              placeholder="Email"
            />
          </div>
          <div class="col-md-6">
            <label for="telefono" class="form-label"
              >Telefono <span class="text-danger">*</span></label
            >
            <input
              type="text"
              class="form-control"
              id="telefono"
              placeholder="Telefono"
            />
          </div>
        </div>

        <div class="row mb-3">
          <div class="col-md-4">
            <label for="nazione" class="form-label"
              >Nazione <span class="text-danger">*</span></label
            >
            <div class="dropdown bhwd-dropdown-container p-0">
            <bhwd-select
              class="form-control dropdown-toggle bhwd-dropdown-button w-100 d-flex justify-content-between align-items-center"
              id="nazione"
              style="height: 40px"
              data-bs-toggle="dropdown" 
              aria-expanded="false"
            ></bhwd-select>

            </div>
          </div>
          <div class="col-md-4">
            <label for="provincia" class="form-label"
              >Provincia <span class="text-danger">*</span></label
            >
            <select class="form-select" id="bhwd-select-provincia">
              <option selected>Select State</option>
            </select>
          </div>
          <div class="col-md-4">
            <label for="citta" class="form-label"
              >Città <span class="text-danger">*</span></label
            >
            <select class="form-select" id="bhwd-select-citta">
              <option selected>Select City</option>
            </select>
          </div>
        </div>

        <div class="mb-3">
          <label for="address" class="form-label"
            >Adress <span class="text-danger">*</span></label
          >
          <input
            type="text"
            class="form-control"
            id="address"
            placeholder="address"
          />
        </div>

        <div class="mb-3">
          <label for="messaggio" class="form-label"
            >Inserire un Messaggio <span class="text-danger">*</span></label
          >
          <textarea
            class="form-control"
            id="messaggio"
            rows="4"
            placeholder="Inserire un Messaggio"
          ></textarea>
        </div>

        <div class="d-flex justify-content-between">
          <div class="mb-3 form-check">
            <input type="checkbox" class="form-check-input" id="privacy" />
            <label class="form-check-label" for="privacy">Privacy</label>
          </div>

          <button type="submit" class="btn btn-danger">Invia Messaggio</button>
        </div>
      </form>
    </div>

    <?php

}

add_shortcode( "bhwd_contatti", "bhwd_custom_contact_form" );