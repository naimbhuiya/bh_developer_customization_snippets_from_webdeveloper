# GeoNames-JSON

JSON format of countries in the world including its administrative state such as Province, State and City taken from http://download.geonames.org/export/dump/.

world.json consist of the whole country and its administrative states

country.json consist only the list of country

Folder Countries consist of JSON data from each individual countries.

