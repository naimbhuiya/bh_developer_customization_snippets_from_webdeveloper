<?php 
/**
 * Name: Scheda Clineti, 
 * version: zommer-0
 * speed: zommer-0
 */

// The file Incluedes in form Header
require_once(plugin_dir_path(__FILE__) . 'src/header/head.php');
require_once(plugin_dir_path(__FILE__) . 'src/body/body.php');
require_once(plugin_dir_path(__FILE__) . 'admin/admin.php');
require_once(plugin_dir_path(__FILE__) . 'src/contatti/index.php');

function bhwd_dequeue_woocommerce_styles() {
    wp_dequeue_style('woocommerce-general');
}
add_action('wp_enqueue_scripts', 'bhwd_dequeue_woocommerce_styles', 20);

function bhwd_scheda_clienti_form() {
    ob_start(); // Start output buffering

    scheada_clinti_header_section();
    bhwd_scheda_clinti_main();

    return ob_get_clean(); // Return buffered content
}

add_shortcode('scheda-clienti', 'bhwd_scheda_clienti_form');