<?php 
// Enqueue styles and scripts for recent product list
function bhdcsfw_enqueue_styles_scripts_recent_product_list() {
    // Enqueue stylesheet
    wp_enqueue_style('bhdcsfw-style-recent-product-lists', plugin_dir_url(__FILE__) . 'asset/css/style.css', array(), '1.0.0' , 'all');

    // Enqueue script
    wp_enqueue_script('bhdcsfw-script-recent-product-list', plugin_dir_url(__FILE__) . 'asset/js/script.js', array(), '1.0.0', true);
}

// Hook the function to the wp_enqueue_scripts action
add_action('wp_enqueue_scripts', 'bhdcsfw_enqueue_styles_scripts_recent_product_list');


 $bhdwc_conter_count =0 ;
function recent_5_order_list_bhdcsfw() {
    // Check if the user is logged in
    if ( is_user_logged_in() ) {
        // Get the current user object
        $current_user = wp_get_current_user();
        
        // Get the current user's ID
        $user_id = $current_user->ID;
        
        // Get the 5 most recent orders for the current user
        $recent_orders = wc_get_orders( array(
            'limit'        => 5,
            'customer_id'  => $user_id,
            'orderby'      => 'date',
            'order'        => 'DESC',
        ) );
        
        // Check if there are any recent orders for the current user
        if ( $recent_orders ) {
            // Start output buffer
            ob_start();
            
            // Output header for recent orders
            // echo '<h2>Recent Orders</h2>';
            echo '<ul class="list-group ms-0 me-0" >';
            ?>
             <li class="list-group-item customBorderPreset1 mt-0  rounded d-flex align-items-center ">
                        <div class='container-fluid pe-2 ps-2' >
                            <div class="row" >
                            <div class=" col-2 d-flex align-items-center imageSideBHD">
                                <p class="mb-0 ">Image</p>
                            </div>
                                <div class="col-10 pe-0 ps-0 contentSideBHD" >
                                    <div class="container-fluid p-0 m-0">
                                        <div class="row">
                                            <div class="col-5 d-flex align-items-center ">
                                                <p class="mb-0">
                                                    Title
                                                </p>
                                            </div>
                                            <div class='col-3 d-flex align-items-center ' >
                                                <p class="mb-0">
                                                    Order Id
                                                </p>
                                            </div>
                                            <div class="col-2 d-flex align-items-center">
                                                <p class="mb-0">
                                                    Price
                                                </p>
                                            </div>
                                            <div class="col-2 d-flex align-items-center flex-wrap">
                                                <p class="mb-0">
                                                    Status
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
            </li>
            <?php
            // Loop through each recent order
            foreach ( $recent_orders as $order ) {
                global $bhdwc_conter_count;
                
                // Get the order status
                $order_status = $order->get_status();
                
                // Get items in the order
                $items = $order->get_items();
                
                // Check if there are any items in the order
                if ( ! empty( $items ) ) {
                    $bhdwc_conter_count++;
                    // Get billing address
                    $billing_address = $order->get_formatted_billing_address();
                    $shipping_address = $order->get_formatted_shipping_address();
                    

                    // Loop through each item in the order
                    foreach ( $items as $item ) {
                        // Get product ID
                    // Get product ID
                    $product_id = $item->get_product_id();

                    // Get product object
                    $product = wc_get_product($product_id);

                    // Get product details
                    $product_image = $product->get_image();
                    $product_title = $product->get_name();
                    $product_price = $product->get_price_html();

                    // Get the total quantity of items in the order
                    $total_quantity = 0;
                    foreach ($order->get_items() as $item_id => $order_item) {
                        $total_quantity += $order_item->get_quantity();
                    }



                        

                            
                 
                    if(!empty($product_title)){ 
                        $product_title ;
                    }else{ 
                        $product_title = 'This Product Has No Title';
                    } 

                    if (!empty($product_price)) {
                        $product_price ;
                    }else{
                        $product_price = 'Not set';
                    }
                   
                    
                        // Output product details
                        echo '<li  class="list-group-item mt-0  pe-0 ps-0  rounded border-0 bg-tranparent-bhdcsfw" >';
                        echo '<div class=" customBorderPreset1 pt-2 pb-2 d-flex align-items-center flex-wrap rounded">';
                        echo "<div class='container-fluid pe-2 ps-2' >";
                        echo '<div class="row" >';
                        echo '<div class=" col-2 d-flex align-items-center   imageSideBHD"><div class="rounded overflow-hidden">' . $product_image . '</div></div>';
                        echo '<div class="col-10 pe-0 ps-0 d-flex align-items-center contentSideBHD" >';
                        // Output order details
                        echo '<div class="container-fluid p-0 m-0">';
                        echo '<div class="row">';
                        echo '<div class="col-5 d-flex align-items-center ">';
                        echo '<p class="title">' .  $product_title . '</p>';
                        echo '</div>';
                        echo "<div class='col-3 d-flex align-items-center ' >" ;
                        echo '<p class="orderId mb-0 pb-0">#' . $order->get_id() . '</p>';
                        echo "</div>";
                        echo '<div class="col-2 d-flex align-items-center">';
                        echo '<p class="price mb-0 ">' . $product_price . '</p>';
                        echo '</div>';
                        echo '<div class="col-2 d-flex align-items-center flex-wrap"><div>';
                        order_status_check_bhd($order_status) ;
                        
                        echo '</div></div>';
                        echo '</div>';
                        echo '</div>';
                        echo '</div>';
                        echo '</div>';

                        echo '<div class="container-fluid mt-2 pe-1 ps-1">';
                        echo "<div class='row'>";
                        echo '<div class="col-12 pe-2 ps-2 d-flex justify-content-end align-items-center mb-0">';
                        ?>
                        <button class="customViewMoreButton collapsButtonsBHD btn  w-100" type="button" data-toggle="collapse" data-target="#collapseExample<?php echo $bhdwc_conter_count; ?>" aria-expanded="false" aria-controls="collapseExample"><i class="fa-regular fa-eye"></i> More</button>
                        <?php
                        echo '</div>';
                        echo '<div class="col-12 mt-1 pe-2 ps-2">';
                        ?>
                        
                         <div class="collapse collapsContinerBHD" id="collapseExample<?php echo $bhdwc_conter_count; ?>">
                            <div class="card card-body mt-2 mb-2 p-1 customViewMoreButton border-0 rounded">
                                <div class="container-fluid  p-0">
                                <?php
                                    // Check if the order status is pending
                                    if ( $order_status === 'pending' ) {
                                        // Output payment button
                                        echo '<a href="' . esc_url( $order->get_checkout_payment_url() ) . '" class="button btn text-bg-dark me-1">Pay</a>';
                                        // Output cancel order button
                                        echo '<a href="' . esc_url( $order->get_cancel_order_url() ) . '" class="button btn text-bg-dark me-1">Cancel</a>';
                                    }
                                ?>
                                </div>
                                <div class="container-fluid mt-3 pe-0 ps-0">
                                    <p class="mb-0"><?php echo '<span class="inline_title" >Total Quantity:</span> x' . $total_quantity; ?></p>
                                </div>
                                <div class="container-fluid mt-2  p-0">
                                    <h4 class="orderItemViewMoreTitle" >Billing Adress</h4>
                               <p class="mb-0 text-adress-styling" ><?php echo $billing_address ; ?></p> 
                            </div>
                            <div class="container-fluid mt-2  p-0">
                            <h4 class="orderItemViewMoreTitle" >Shipping Adress</h4>
                                <?php
                                    if(empty($shipping_address)){
                                        echo "<p class='text-adress-styling mb-0'>Shipping Adress is empty...</p>";
                                    }else{
                                        echo '<p class="text-adress-styling mb-0" >'. $shipping_address .'</p>'  ;
                                    }
                                ?>
                            </div>
                            </div>
                            
                         </div>
                        <?php
                        
                        echo '</div>';
                        
                        echo '</div>';
                        echo '</div>' ;
                        echo '</div>';
                        echo '</div>';
                        echo '</li>';
                    }
                
                } else {
                    echo 'No items found in this order.';
                }
            }
            echo '</ul>';
            // End output buffer and return content
            return ob_get_clean();
        } else {
            return 'No recent orders for the current user.';
        }
    } else {
        return 'Please log in to view recent orders.';
    }
}
// Order Status Checker 
function order_status_check_bhd($order_status_check) {
    // echo $order_status_check ;
    if ($order_status_check == "processing") {
        echo "Processing";
    }elseif($order_status_check == "pending"){
        echo "Pending";
    }elseif($order_status_check == "on-hold"){
        echo "On Hold";
    }elseif($order_status_check == "cancelled"){
        echo "Cancelled";
    }elseif($order_status_check == "refunded"){
        echo "Refunded";
    }elseif($order_status_check == "failed"){
        echo "Failed";
    }elseif($order_status_check == "completed"){
        echo "Completed";
    }elseif($order_status_check == "Draft"){
        echo  "Drafted";
    }

}



add_shortcode( 'recent_5_order_list', 'recent_5_order_list_bhdcsfw' );
