let bhorder_id_get = document.querySelectorAll(".orderId");

bhorder_id_get.forEach((element, index) => {
  element.addEventListener("click", () => {
    navigator.clipboard.writeText(element.innerText);

    const toastElement = document.createElement("div");
    toastElement.className = "toastMessage";
    toastElement.innerHTML = `<p>${element.innerText} Copied</p>`;
    document.body.appendChild(toastElement);

    // Remove the toast message after a certain time (e.g., 3 seconds)
    setTimeout(() => {
      document.body.removeChild(toastElement);
    }, 3000);
  });
});

const collapsButtonsBHD = document.querySelectorAll(".collapsButtonsBHD");
const collapsContinerBHD = document.querySelectorAll(".collapsContinerBHD");

collapsButtonsBHD.forEach((elements, i) => {
  elements.addEventListener("click", () => {
    collapsContinerBHD[i].classList.toggle("show");
  });
});
