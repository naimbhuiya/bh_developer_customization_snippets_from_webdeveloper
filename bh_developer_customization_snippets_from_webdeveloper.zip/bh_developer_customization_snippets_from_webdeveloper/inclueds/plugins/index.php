<?php 

function bhwd_enqueue_plugins_scripts_and_css() {
    // Enqueue Bootstrap CSS from a CDN
    wp_enqueue_style( 'bhwd_owl_theme_default_min', plugin_dir_url( __FILE__ ) . "owl/owl.carousel.min.css", array(), '1.0.0' );
    wp_enqueue_style( 'bhwd_owl_carousel_min', plugin_dir_url( __FILE__ ) . "owl/owl.theme.default.min.css", array(), '1.0.0' );

    /**
     * Slick slider css 
     */
    wp_enqueue_style( 'bhwd_slick_min', plugin_dir_url( __FILE__ ) . "slick/slick-css.min.css", array(), '1.0.0' );
    wp_enqueue_style( 'bhwd_slick_theme_min', plugin_dir_url( __FILE__ ) . "slick/slick-theme-css.min.css", array(), '1.0.0' );
    

    /**
     * Enqueue scripts 
     */
    wp_enqueue_script( "bhwd_owl_carousel_min", plugin_dir_url( __FILE__ ) . "owl/owl.carousel.min.js", 0, true );
    wp_enqueue_script( "bhwd_slick", plugin_dir_url( __FILE__ ) . "slick/slick.min.js", 0, true );
    wp_enqueue_script( "bhwd_notify", plugin_dir_url( __FILE__ ) . "notify.js", 0, true );
}
add_action( 'wp_enqueue_scripts', 'bhwd_enqueue_plugins_scripts_and_css' );