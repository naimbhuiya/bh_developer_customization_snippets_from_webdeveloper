<?php 
// Use global to access the $current_user variable
function bhdcsfw_enqueue_styles_scripts_ads() {
    // Styles
    wp_enqueue_style('bhdcsfw-style-ads', plugin_dir_url(__FILE__) . 'css/style.css', array(), '1.0.0', 'all');

    // Scripts
    wp_enqueue_script('bhdcsfw-script-ads', plugin_dir_url(__FILE__) . 'js/script.js', array('jquery'), '1.0.0', true);
}
add_action('wp_enqueue_scripts', 'bhdcsfw_enqueue_styles_scripts_ads');

function bhdcsfw_desktop_ads() {
    $current_archive = get_queried_object(); // Retrieve the current archive object

    // Loop through the number of elements specified in the option
    for ($i = 0; $i < intval(get_option('bhdcsfw-add-emlement-count')); $i++) {
        // Retrieve options for each element
        $desktop_img = get_option('bhdcsfw-desktop-image-url-' . $i);
        $mobile_img = get_option('bhdcsfw-mobile-image-url-' . $i);
        $ads_url = get_option('bhdcsfw-ads-url-' . $i);
        $categories = get_option('bhdcsfw-categories-' . $i);

        // Validate if desktop image is not empty
        if (!empty($desktop_img) || $desktop_img === "" || $desktop_img === " ") {
            // Check if the current page matches the provided category slug
            if (bhdcsfw_current_page_uri_check($current_archive, $categories)) {
                // Validate image extension
                if (bhdcsfw_is_valid_image($desktop_img)) {
                    // Output HTML with ads
                    ?>
                    <a class="p-0 m-0 remove-desktop-ads-on-mobile" href="<?php echo esc_url($ads_url); ?>" target="_blank" rel="noopener noreferrer">
                        <img class="img-fluid lazy w-100" src="<?php echo esc_url($desktop_img); ?>" alt="">
                    </a>
                    <?php
                }
            }
        }
    } 
}
add_shortcode("bhdcsfw_custom_ads", "bhdcsfw_desktop_ads");




function bhdcsfw_mobile_ads() {
    $current_archive = get_queried_object(); // Retrieve the current archive object

    // Loop through the number of elements specified in the option
    for ($i = 0; $i < intval(get_option('bhdcsfw-add-emlement-count')); $i++) {
        // Retrieve options for each element
        $mobile_img = get_option('bhdcsfw-mobile-image-url-' . $i);
        $ads_url = get_option('bhdcsfw-ads-url-' . $i);
        $categories = get_option('bhdcsfw-categories-' . $i);

        // Validate if desktop image is not empty
        if (!empty($mobile_img) || $mobile_img === "" || $mobile_img === " ") {
            // Check if the current page matches the provided category slug
         if (bhdcsfw_current_page_uri_check($current_archive, $categories)) {
                // Validate image extension
                if (bhdcsfw_is_valid_image($mobile_img)) {
                    // Output HTML with ads
                    ?>
                    <a class="p-0 m-0 remove-mobile-ads-on-desktop mobile-ads-on-desktop d-flex align-items-center" href="<?php echo esc_url($ads_url); ?>" target="_blank" rel="noopener noreferrer">
                        <img id="image_claent_width" class="img-fluid lazy w-100 " src="<?php  echo esc_url($mobile_img); ?>" alt="">
                    </a>
                    <?php
				}   
		 }
        }
    } 
}
add_shortcode("bhdcsfw_custom_mobile_ads", "bhdcsfw_mobile_ads");
// Random Mobile Ads Shortcode
function random_mobile_shortcode_bhdcsfw() {
    $max = intval(get_option('bhdcsfw-add-emlement-count'));
    $random_number = rand(0, $max);
    random_mobile_ads_bhdcsfw($random_number);
}
add_shortcode("random_ads_shortcode_mobile", "random_mobile_shortcode_bhdcsfw");

// Random Desktop Ads Shortcode
function random_desktop_shortcode_bhdcsfw() {
    $max = intval(get_option('bhdcsfw-add-emlement-count'));
    $random_number = rand(0, $max);
    random_desktop_ads_bhdcsfw($random_number);
}
add_shortcode("random_ads_shortcode_desktop", "random_desktop_shortcode_bhdcsfw");

// Function to display random mobile ad based on random number
function random_mobile_ads_bhdcsfw($random_number) {
    // Retrieve options for the specified element number
    $mobile_img = get_option('bhdcsfw-mobile-image-url-' . $random_number);
    $ads_url = get_option('bhdcsfw-ads-url-' . $random_number);
    $categories = get_option('bhdcsfw-categories-' . $random_number);

    // Validate if mobile image is not empty
    if (!empty($mobile_img) || $mobile_img === "" || $mobile_img === " ") {
        // Check if the current page matches the provided category slug
       
            // Validate image extension
            if (bhdcsfw_is_valid_image($mobile_img)) {
                // Output HTML with mobile ad
                echo '<a class="p-0 m-0 remove-mobile-ads-on-desktop mobile-ads-on-desktop d-flex align-items-center" href="' . esc_url($ads_url) . '" target="_blank" rel="noopener noreferrer">';
                echo '<img id="image_claent_width" class="img-fluid lazy w-100" src="' . esc_url($mobile_img) . '" alt="">';
                echo '</a>';
            }
        
    }
}

// Function to display random desktop ad based on random number
function random_desktop_ads_bhdcsfw($random_number) {
    // Retrieve options for the specified element number
    $desktop_img = get_option('bhdcsfw-desktop-image-url-' . $random_number);
    $ads_url = get_option('bhdcsfw-ads-url-' . $random_number);
    $categories = get_option('bhdcsfw-categories-' . $random_number);

    // Validate if desktop image is not empty
    if (!empty($desktop_img) || $desktop_img === "" || $desktop_img === " ") {
        // Check if the current page matches the provided category slug
       
            // Validate image extension
            if (bhdcsfw_is_valid_image($desktop_img)) {
                // Output HTML with desktop ad
                echo '<a class="p-0 m-0 remove-desktop-ads-on-mobile" href="' . esc_url($ads_url) . '" target="_blank" rel="noopener noreferrer">';
                echo '<img class="img-fluid lazy w-100" src="' . esc_url($desktop_img) . '" alt="">';
                echo '</a>';
            }
        
    }
}


// Function to check if the current page matches the provided category slug
function bhdcsfw_current_page_uri_check($current_archive, $conditional_uri) {
    if ($current_archive && isset($current_archive->slug)) {
        $current_slug = $current_archive->slug;
        return ($current_slug == $conditional_uri);
    }
    return false;
}

// Function to validate image extension
function bhdcsfw_is_valid_image($url) {
    $allowed_extensions = array('jpg', 'jpeg', 'png', 'gif', 'webp'); // Add more extensions if needed
    $extension = strtolower(pathinfo($url, PATHINFO_EXTENSION));
    return in_array($extension, $allowed_extensions);
}