<?php 
// Use global to access the $current_user variable
function bhdcsfw_enqueue_styles_scripts_ads() {
    // Styles
    wp_enqueue_style('bhdcsfw-style-ads', plugin_dir_url(__FILE__) . 'css/style.css', array(), '1.0.0', 'all');

    // Scripts
    wp_enqueue_script('bhdcsfw-script-ads', plugin_dir_url(__FILE__) . 'js/script.js', array('jquery'), '1.0.0', true);
}
add_action('wp_enqueue_scripts', 'bhdcsfw_enqueue_styles_scripts_ads');

function bhdcsfw_desktop_ads() {
    $current_archive = get_queried_object(); // Retrieve the current archive object

    // Loop through the number of elements specified in the option
    for ($i = 0; $i < intval(get_option('bhdcsfw-add-emlement-count')); $i++) {
        // Retrieve options for each element
        $desktop_img = get_option('bhdcsfw-desktop-image-url-' . $i);
        $mobile_img = get_option('bhdcsfw-mobile-image-url-' . $i);
        $ads_url = get_option('bhdcsfw-ads-url-' . $i);
        $categories = get_option('bhdcsfw-categories-' . $i);

        // Validate if desktop image is not empty
        if (!empty($desktop_img) || $desktop_img === "" || $desktop_img === " ") {
            // Check if the current page matches the provided category slug
            if (bhdcsfw_current_page_uri_check($current_archive, $categories)) {
                // Validate image extension
                if (bhdcsfw_is_valid_image($desktop_img)) {
                    // Output HTML with ads
                    ?>
                    <a class="p-0 m-0 remove-desktop-ads-on-mobile" href="<?php echo esc_url($ads_url); ?>" target="_blank" rel="noopener noreferrer">
                        <img class="img-fluid lazy w-100" src="<?php echo esc_url($desktop_img); ?>" alt="">
                    </a>
                    <?php
                } else {
                    echo "Invalid image extension";
                }
            }
        }
    } 
}
add_shortcode("bhdcsfw_custom_ads", "bhdcsfw_desktop_ads");




function bhdcsfw_mobile_ads() {
    $current_archive = get_queried_object(); // Retrieve the current archive object

    // Loop through the number of elements specified in the option
    for ($i = 0; $i < intval(get_option('bhdcsfw-add-emlement-count')); $i++) {
        // Retrieve options for each element
        $mobile_img = get_option('bhdcsfw-mobile-image-url-' . $i);
        $ads_url = get_option('bhdcsfw-ads-url-' . $i);
        $categories = get_option('bhdcsfw-categories-' . $i);

        // Validate if desktop image is not empty
        if (!empty($mobile_img) || $mobile_img === "" || $mobile_img === " ") {
            // Check if the current page matches the provided category slug
            if (bhdcsfw_current_page_uri_check($current_archive, $categories)) {
                // Validate image extension
                if (bhdcsfw_is_valid_image($mobile_img)) {
                    // Output HTML with ads
                    ?>
                    <a class="p-0 m-0 remove-mobile-ads-on-desktop mobile-ads-on-desktop d-flex align-items-center" style="background-image: url(<?php echo esc_url($mobile_img); ?>)" href="<?php echo esc_url($ads_url); ?>" target="_blank" rel="noopener noreferrer">
                        <!-- <img id="image_claent_width" class="img-fluid lazy w-100 " src="<?php // echo esc_url($mobile_img); ?>" alt=""> -->
                    </a>
                    <?php
                } else {
                    echo "Invalid image extension";
                }
            }
        }
    } 
}
add_shortcode("bhdcsfw_custom_mobile_ads", "bhdcsfw_mobile_ads");


// Function to check if the current page matches the provided category slug
function bhdcsfw_current_page_uri_check($current_archive, $conditional_uri) {
    if ($current_archive && isset($current_archive->slug)) {
        $current_slug = $current_archive->slug;
        return ($current_slug == $conditional_uri);
    }
    return false;
}

// Function to validate image extension
function bhdcsfw_is_valid_image($url) {
    $allowed_extensions = array('jpg', 'jpeg', 'png', 'gif', 'webp'); // Add more extensions if needed
    $extension = strtolower(pathinfo($url, PATHINFO_EXTENSION));
    return in_array($extension, $allowed_extensions);
} 