let image_claent_width = document.getElementById("image_claent_width")
// console.log("Width: " + image_claent_width.clientWidth)
// console.log("Heigth: " + image_claent_width.clientHeight)
