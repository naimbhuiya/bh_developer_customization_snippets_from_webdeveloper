<?php 

// Function to generate custom CSS dynamically
function bhwd_custom_css_sliding_nav() {
    $custom_bhwd_css = '
        .bhwd-menu-nav-wrap > ul > li {
            border-top: ' . ( !empty(get_option('bhwd_menu_item_border_top')) ? esc_attr(get_option('bhwd_menu_item_border_top')) . 'px solid ' . esc_attr(get_option('bhwd_menu_item_border_top_color')) : 'none' ) . ';
            border-bottom: ' . ( !empty(get_option('bhwd_menu_item_border_bottom')) ? esc_attr(get_option('bhwd_menu_item_border_bottom')) . 'px solid ' . esc_attr(get_option('bhwd_menu_item_border_bottom_color')) : '1px solid #dadada' ) . ';
            border-left: ' . ( !empty(get_option('bhwd_menu_item_border_left')) ? esc_attr(get_option('bhwd_menu_item_border_left')) . 'px solid ' . esc_attr(get_option('bhwd_menu_item_border_left_color')) : 'none' ) . ';
            border-right: ' . ( !empty(get_option('bhwd_menu_item_border_right')) ? esc_attr(get_option('bhwd_menu_item_border_right')) . 'px solid ' . esc_attr(get_option('bhwd_menu_item_border_right_color')) : 'none' ) . ';
            transition: 0.4s;
        }
        .bhwd-menu-nav-wrap > ul > li:hover {
            border-top: ' . ( !empty(get_option('bhwd_menu_item_hover_border_top')) ? esc_attr(get_option('bhwd_menu_item_hover_border_top')) . 'px solid ' . esc_attr(get_option('bhwd_menu_item_hover_border_top_color')) : 'none' ) . ';
            border-bottom: ' . ( !empty(get_option('bhwd_menu_item_hover_border_bottom')) ? esc_attr(get_option('bhwd_menu_item_hover_border_bottom')) . 'px solid ' . esc_attr(get_option('bhwd_menu_item_hover_border_bottom_color')) : '1px solid #dadada' ) . ';
            border-left: ' . ( !empty(get_option('bhwd_menu_item_hover_border_left')) ? esc_attr(get_option('bhwd_menu_item_hover_border_left')) . 'px solid ' . esc_attr(get_option('bhwd_menu_item_hover_border_left_color')) : 'none' ) . ';
            border-right: ' . ( !empty(get_option('bhwd_menu_item_hover_border_right')) ? esc_attr(get_option('bhwd_menu_item_hover_border_right')) . 'px solid ' . esc_attr(get_option('bhwd_menu_item_hover_border_right_color')) : 'none' ) . ';
        }
        .bhwd-menu-nav-wrap ul li:last-child {
            border: ' . esc_attr(get_option('bhwd_menu_item_border_style_child', '0px')) . ';
        }
        .bhwd-menu-nav-wrap > ul > li > p span a {
            color: ' . ( !empty(get_option('bhwd_menu_item_color')) ? esc_attr(get_option('bhwd_menu_item_color')) : '#000' ) . ';
            font-size: ' . ( !empty(get_option('bhwd_menu_item_font_size')) ? esc_attr(get_option('bhwd_menu_item_font_size')) : '16' ) . 'px;
        }
        .bhwd-menu-nav-wrap ul li p.bhwd-menu-item .bhwd-menu-item-angle i {
            color: ' . ( !empty(get_option('bhwd_menu_item_color')) ? esc_attr(get_option('bhwd_menu_item_color')) : '#000' ) . ';
        }
        .bhwd-submenu-panel {
            width: ' . ( !empty(get_option('bhwd_menu_container_width')) ? esc_attr(get_option('bhwd_menu_container_width')) : '300px' ) . ';
        }
    ';

    return $custom_bhwd_css;
}
function bhwd_enqueue_custom_scripts_and_css() {
    // Enqueue Bootstrap CSS from a CDN
    wp_enqueue_style( 'bhwd_plugin_styles', plugin_dir_url( __FILE__ ) . "style.css", array(), '1.0.0' );

    /**
     * Enqueue scripts 
     */
    wp_enqueue_script( "bhwd_footer_nav_slider", plugin_dir_url( __FILE__ ) . "scripts/footer_nav_slider.js", 0, true );
    wp_enqueue_script( "bhwd_mobile_nav", plugin_dir_url( __FILE__ ) . "scripts/mobile_nav.js", 1, true );
    wp_enqueue_script( "bhwd_resent_order", plugin_dir_url( __FILE__ ) . "scripts/resent_order.js", 10, true );
    wp_enqueue_script( "bhwd_secondary_nav", plugin_dir_url( __FILE__ ) . "scripts/secondary_nav.js", 3, true );
    wp_enqueue_script( "bhwd_showroom", plugin_dir_url( __FILE__ ) . "scripts/showroom.js", 4, true );
    wp_enqueue_script( "bhwd_woo_cat_slider", plugin_dir_url( __FILE__ ) . "scripts/woo_cat_slider.js", 5, true );

    wp_localize_script( 'bhwd_showroom', 'bhwdSmAjxScript', array(
        'bhwdSmAjxUrl' => admin_url( 'admin-ajax.php' ),
        // 'otherParam' => 'some value',
    ) );
    

    $custom_css = bhwd_custom_css_sliding_nav();
    wp_add_inline_style('bhwd_plugin_styles', $custom_css);
}
add_action( 'wp_enqueue_scripts', 'bhwd_enqueue_custom_scripts_and_css' );