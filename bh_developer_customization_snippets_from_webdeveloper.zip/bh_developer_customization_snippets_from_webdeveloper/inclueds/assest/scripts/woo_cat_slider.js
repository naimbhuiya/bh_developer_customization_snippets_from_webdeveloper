jQuery(document).ready(function ($) {
  // Cache DOM elements
  const $carousel = $(".bhwd-owl-carousel");
  const $nextBtn = $(".bhwd-woocat-next");
  const $prevBtn = $(".bhwd-woocat-prev");

  // Check if carousel element exists and plugin is available
  if (!$carousel.length) {
    console.warn("Carousel element not found");
    return;
  }

  if (!$.fn.owlCarousel) {
    console.error("OwlCarousel plugin is not loaded");
    return;
  }

  try {
    $carousel.addClass("owl-carousel").removeClass("bhwd-alt-native-class");
    // console.log("OwlCarousel initialized successfully");
    // Initialize carousel with optimized settings
    const owl = $carousel.owlCarousel({
      loop: true,
      margin: 20,
      nav: false, // Disable built-in nav since we have custom buttons
      dots: true,
      autoplay: true,
      autoplayTimeout: 5000,
      autoplayHoverPause: true,
      lazyLoad: true, // Enable lazy loading for images
      responsive: {
        0: {
          items: 3, // More reasonable for mobile
          margin: 5,
          nav: false, // Disable nav on smallest screens
        },
        480: {
          items: 4,
          margin: 10,
        },
        768: {
          items: 5,
          nav: true,
        },
        992: {
          items: 6,
        },
        1200: {
          items: 10,
        },
      },
    });

    // Custom navigation handlers with error prevention
    $nextBtn.on("click", function (e) {
      e.preventDefault();
      try {
        owl.trigger("next.owl.carousel");
      } catch (error) {
        console.error("Next navigation failed:", error);
      }
    });

    $prevBtn.on("click", function (e) {
      e.preventDefault();
      try {
        owl.trigger("prev.owl.carousel", [300]); // 300ms speed
      } catch (error) {
        console.error("Previous navigation failed:", error);
      }
    });

    // Handle window resize events
    let resizeTimer;
    $(window).on("resize", function () {
      clearTimeout(resizeTimer);
      resizeTimer = setTimeout(function () {
        owl.trigger("refresh.owl.carousel");
      }, 250);
    });
  } catch (error) {
    console.error("OwlCarousel initialization failed:", error);
  }
});
