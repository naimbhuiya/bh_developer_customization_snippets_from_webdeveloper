jQuery(document).ready(function ($) {
  // Cache DOM elements
  const $menuContainer = $(".menu-container");
  const $navItems = $(".bhwd_nav_item");
  const $parentItems = $(".bhwd_nav_item_has_children");
  const $subMenus = $(".bhwd_depth_1_submenu");
  const activeClass = "bhwd_submenu_active";
  let activeTimeout;

  // Handle hover effects for all nav items
  $navItems.each(function () {
    const $item = $(this);
    const color = $item.data("color");

    $item.on({
      mouseenter: function () {
        clearTimeout(activeTimeout);
        $item.css("background", color);

        // If it's a parent item, activate its first submenu
        if ($item.hasClass("bhwd_nav_item_has_children")) {
          const $firstSubmenu = $item.find(activeClass).length
            ? $item.find("." + activeClass)
            : $item.find($subMenus).first();

          $subMenus.removeClass(activeClass).css("background", "transparent");
          $firstSubmenu.addClass(activeClass).css("background", color);
        }
      },
      mouseleave: function () {
        // Only reset if not a parent with active submenu

        $item.css("background", "transparent");
      },
    });
  });

  // Handle submenu interactions
  $subMenus.each(function () {
    const $submenu = $(this);
    const color = $submenu.closest($parentItems).data("color");
    const $parentItem = $submenu.closest($parentItems);

    $submenu.on({
      mouseenter: function () {
        clearTimeout(activeTimeout);
        $subMenus.removeClass(activeClass).css("background", "transparent");
        $submenu.addClass(activeClass).css("background", color);
        $parentItem.css("background", color);
      },
      mouseleave: function () {
        activeTimeout = setTimeout(function () {
          if (!$submenu.is(":hover") && !$parentItem.is(":hover")) {
            $submenu.removeClass(activeClass).css("background", "transparent");
            $parentItem.css("background", "transparent");
          }
        }, 200);
      },
    });
  });

  // Reset all states when leaving menu container
  $menuContainer.on("mouseleave", function () {
    $navItems.css("background", "transparent");
    $subMenus.removeClass(activeClass).css("background", "transparent");
  });

  // Prevent flickering when moving between items
  $menuContainer.on("mouseenter", function () {
    clearTimeout(activeTimeout);
  });

  /**
   *
   *
   **/

  const menu = $(".bhwd_navbar_nav");
  const scrollLeftBtn = $("#bhwd_scroll_left");
  const scrollRightBtn = $("#bhwd_scroll_right");

  // Right scroll button
  scrollRightBtn.on("click", function () {
    menu.animate({ scrollLeft: "+=200" }, 300);
    scrollLeftBtn.show();
  });

  // Left scroll button
  scrollLeftBtn.on("click", function () {
    menu.animate({ scrollLeft: "-=200" }, 300);
  });

  // ✅ Dragging (click and drag to scroll)
  let isDragging = false;
  let startX, scrollStart;

  menu.on("mousedown", function (e) {
    isDragging = true;
    startX = e.pageX - menu.offset().left;
    scrollStart = menu.scrollLeft();
    menu.addClass("dragging");
  });

  $(document).on("mouseup", function () {
    isDragging = false;
    menu.removeClass("dragging");
  });

  $(document).on("mousemove", function (e) {
    if (!isDragging) return;
    const x = e.pageX - menu.offset().left;
    const walk = (x - startX) * 1.5; // scroll speed
    menu.scrollLeft(scrollStart - walk);
  });

  // ✅ Wheel scrolling (free scroll horizontally)
  menu.on("wheel", function (e) {
    if (e.originalEvent.deltaY !== 0) {
      e.preventDefault();
      menu.scrollLeft(menu.scrollLeft() + e.originalEvent.deltaY);
    }
  });

  // ✅ Infinity Scroll (looping)
  function checkInfiniteScroll() {
    const scrollWidth = menu[0].scrollWidth;
    const scrollLeft = menu.scrollLeft();
    const containerWidth = menu.outerWidth();

    if (scrollLeft + containerWidth >= scrollWidth - 5) {
      // Reached end → jump back to start
      menu.scrollLeft(0);
    } else if (scrollLeft <= 0) {
      // Reached start → jump to end
      menu.scrollLeft(scrollWidth);
    }
  }

  menu.on("scroll", function () {
    checkInfiniteScroll();
  });

  /**
   * Handle Side Nav Menu Position & Padding
   */
  const $sideNavMenuContainer = $(".bhwd_side_menu_container");
  const $navMainContainer = $("#bhwd_nav");

  const $navigationSideMenuSubContainer = $(".bhwd_side_sub_menu_container");
  const $sideNavItems = $(".bhwd_side_nav-item");

  function updateSideNavOffset() {
    if ($sideNavMenuContainer.length && $navMainContainer.length) {
      const offsetLeft = $navMainContainer.offset().left;

      // Apply dynamic position and padding
      $sideNavMenuContainer.css({
        left: `-${offsetLeft}px`,
        paddingLeft: `${offsetLeft}px`,
        paddingRight: `${offsetLeft}px`,
      });
    } else {
      console.warn("Missing side nav container or main nav container.");
    }

    let counter = 0;

    $sideNavItems.each(function (i, el) {
      const $item = $(this);
      const $navItem = $navItems.eq(i);
      const itemPostId = $item.data("post-id");
      const navItemPostId = $navItem.data("post-id");

      // Parse sub menu container from $navItem's HTML
      const $html = $("<div>" + $navItem.html() + "</div>");
      const $subMenuContainer = $html.find(".bhwd_sub_menu_container");

      if ($subMenuContainer.length) {
        counter++;
        // Insert first matching submenu once
        if (counter === 1) {
          $navigationSideMenuSubContainer.html(
            $subMenuContainer.prop("outerHTML")
          );
        }

        // Set per-item flag to prevent multiple insertions
        //         $item.data("submenuLoaded", false);
        $item.removeClass("bhwd_side_nav_active");
        $item.on("mouseenter", function () {
          if (itemPostId === navItemPostId) {
            const updatedHtml = $("<div>" + $navItem.html() + "</div>");
            const updatedSubMenu = updatedHtml.find(".bhwd_sub_menu_container");

            if (updatedSubMenu.length) {
              $item.addClass("bhwd_side_nav_active");
              $navigationSideMenuSubContainer.html(
                updatedSubMenu.prop("outerHTML")
              );
              console.log(updatedSubMenu.prop("outerHTML"));
              $item.data("submenuLoaded", true);
            }
          }
        });
      }
    });
  }

  // Initial update
  updateSideNavOffset();

  // Update on window resize
  $(window).on("resize", function () {
    updateSideNavOffset();
  });
});
