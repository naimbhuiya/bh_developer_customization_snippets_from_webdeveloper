jQuery(document).ready(function ($) {
  let data = [];
  $.ajax({
    type: "post",
    url: bhwdSmAjxScript.bhwdSmAjxUrl,
    data: {
      action: "bhwd_showroom_meta",
    },
    success: function (response) {
      if (response.err) {
        displayAlert(response.message || "An error occurred", "warning");
        return;
      }

      data = response.data;

      //       console.log(data);
    },
    error: function () {
      data["message"] = "Failed to load data.";
    },
  });
  function bhwd_create_popup() {
    // Selecting necessary elements
    const $contactButtons = $(".bhwd_pp_content_btn.contatti");
    const $infoButtons = $(".bhwd_pp_content_btn.info");
    // const $nestedCarousels = $(".bhwdNestedCarousel");
    const $pageContents = $(".bhwd-page-content");
    const $formShortCodes = $(".bhwd-form-short-code");
    const $nestedCarouselItems = $(".bhwd-carousel-nested-item");
    const $mainCarousel = $(".bhwd_MainCarousel");

    // Initialize popup logic by attaching event listeners to buttons
    function initPopupListeners() {
      // Attach click event listener to each info button
      $infoButtons.each(function (index) {
        $(this).on("click", function () {
          // closeExistingPopup();
          const postId = $(this).attr("post-id");
          //           console.log("Data", data);

          // alert(postId);
          closeExistingPopup();
          createPopup(postId);
          copyEmailOrNumber(".bhwd-if-email-or-number");
          // Example usage
          $(".bhwd_close").removeClass("d-none");

          // createPopup(true, index, postId); // 'true' indicates it's a form popup
        });
      });
    }

    // Create and display a popup
    function createPopup(id) {
      const $popupElement = $(`
      <div class="bhwd_popup_content">
        <div class="bhwd-popup-container overflow-auto">
          <div style="display: flex ;
                justify-content: center;
                align-items: center;" 
                class="bhwd_content px-3">
            <div class="" >
              <div class="spinner-border text-primary" role="status">
                <span class="visually-hidden">Loading...</span>
              </div>
            </div>
          </div>
          <div class="bhwd_close d-none">
            <button class="bhwd-close-button">
              <i class="fa fa-close"></i>
            </button>
          </div>
        </div>
        <div class="bhwd-overly"></div>
      </div>
    `);

      // Append the popup to the correct container
      //       if ($(window).width() > 768 || !$nestedCarouselItems.eq(index).length) {
      //         $("body").append($popupElement);
      //       } else {
      //         $mainCarousel.append($popupElement);
      //       }
      $("body").append($popupElement);
      // Setup close events
      setupPopupCloseEvents($popupElement);
      $popupElement.find(".bhwd_content").html(information(data[id]));

      // console.log(data[id]);
    }

    // Set up popup close events
    function setupPopupCloseEvents($popupElement) {
      $popupElement.find(".bhwd-close-button").on("click", function () {
        closePopup($popupElement);
      });
      $popupElement.find(".bhwd-overly").on("click", function () {
        closePopup($popupElement);
      });
    }

    // Close popup with animation
    function closePopup($popupElement) {
      $popupElement.addClass("bhwd-overly-puse");
      setTimeout(function () {
        $popupElement.remove();
      }, 400); // Delay to allow for closing animation
    }

    // Close any existing popups before opening a new one
    function closeExistingPopup() {
      const $existingPopup = $(".bhwd_popup_content");
      if ($existingPopup.length) closePopup($existingPopup);
    }

    // information(data);
    // Contact information function

    // Initialize popup listeners
    initPopupListeners();
    // console.log($(".bhwd-if-email-or-number").length);
  }

  function information(value) {
    let _current_post_data = value.data_content;
    let contactInfoHTML = `
          <div class="container-fluid h-100">
              <div class="row h-100">
                  <div class="col-md-6 h-xxl-100 h-xl-100 h-lg-100  px-2">
                  
                  <ul class="list-group list-group-flush ms-0 ps-0">
                    <li class="list-group-item list-group-item-action bg-transparent border-0">
                      <h4 class="text-white pt-0 pb-0 mb-0">${value.title}</h4>
                      <h2 class="text-white pt-0 pb-0 mb-0">Information</h2>
                    </li>
                  </ul>
                  <ul class="list-group h-xxl-85 h-xl-85 h-lg-85 bhwd-sroll-bar-hide overflow-auto list-group-flush ms-0 ps-0">`;

    // Build list items
    let check = _current_post_data === "" ? false : true;
    //console.log(check);
    if (check) {
      for (let key in _current_post_data) {
        // console.log(key);

        /**
         * Print list item with contact information
         */
        contactInfoHTML += `<li class="list-group-item list-group-item-action bg-transparent border-0">`;
        contactInfoHTML += `<div class="row" >`;
        contactInfoHTML += `<div class="col-2 d-flex justify-content-center ">`;

        if (_current_post_data?.[key]?.dise_icon) {
          contactInfoHTML += `<i class=" bhwd-icon-style text-white ${_current_post_data[key].dise_icon}" ></i>`;
        } else {
          contactInfoHTML += `<i class="text-white bhwd-icon-style fa-solid fa-arrow-right"></i>`;
        }
        // console.log(matchedItem?.content?.[key]?.["item-0"]?.dise_icon);

        // contactInfoHTML += `<i class="${info[0].content[key][0]}" ></i>`;
        contactInfoHTML += `</div>`;
        contactInfoHTML += `<div class="col-10 ">`;
        contactInfoHTML += `<h5 class="mb-0 text-white pb-0">${_current_post_data[key].dise_label}</h5>`;

        /**
         * Check if the contact type is an array
         */
        contactInfoHTML += `<p  class="bhwd-if-email-or-number text-white mb-0 pb-0" >`;
        contactInfoHTML += _current_post_data[key].dise_info;
        contactInfoHTML += `</p>`;
        contactInfoHTML += `</div>`;
        contactInfoHTML += `</div>`;
        contactInfoHTML += `</li>`;
      }
    } else {
      // console.log("No data found");
      contactInfoHTML += `<li class="list-group-item list-group-item-action bg-transparent border-0">`;
      contactInfoHTML += `<p class="mb-0 text-white pb-0">Contact us <a class="text-lowercase text-white" href="mailto:info@disegnarecasa.com" >info@disegnarecasa.com</a></p>`;
      contactInfoHTML += `<li>`;
    }

    // console.log(_current_post_data);

    contactInfoHTML += `
                      </ul>
                  </div>
                  <div class="col-md-6 h-xxl-100 h-xl-100 h-lg-100 px-2 rounded">
                     <iframe class="h-100 rounded" src="${value.map}" width="600" height="450" frameborder="0" style="border:0"></iframe>
                  </div>
              </div>
          </div>`;

    return contactInfoHTML;
  }

  /**
   * Onclick then check email or number then copy text
   * @param {*} keys
   * @param {*} className
   * @returns
   */
  function copyEmailOrNumber(selector) {
    // Improved regex patterns
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    const numberRegex = /^\+?[\d\s\-().]{7,}$/;

    $(selector).each(function () {
      const $element = $(this);
      const elementText = $element.text();
      const originalText = elementText.trim();
      const textParts = originalText.split(",");

      // Clear existing content and classes
      $element.empty().removeClass("bhwd-if-email-or-number");

      // Process each part of the text
      textParts.forEach((part, index) => {
        const trimmedPart = part.trim();
        const $span = $("<span>");
        // Check if part is email or phone
        if (emailRegex.test(trimmedPart) || numberRegex.test(trimmedPart)) {
          $span.text(trimmedPart.toLowerCase());

          $span
            .addClass("bhwd-copyable text-lowercase")
            .attr("title", "Click to copy")
            .css("cursor", "pointer");

          // Add click handler for this specific element
          $span.on("click", function (e) {
            e.stopPropagation();
            let textToCopy = trimmedPart;

            // Clean the text before copying
            if (emailRegex.test(textToCopy)) {
              textToCopy = textToCopy;
            } else if (numberRegex) {
              textToCopy = textToCopy;
            }

            copyToClipboard(textToCopy);
          });

          $element.addClass("bhwd-if-email-or-number");

          $element.append($span);
        } else {
          $element.text(elementText);
        }

        // Add comma separator if not the last item
        // if (index < textParts.length - 1) {
        //   $element.append(", ");
        // }
      });
    });
  }
  // Universal clipboard function for WordPress
  function copyToClipboard(text) {
    if (navigator.clipboard && window.isSecureContext) {
      // Modern browser with secure context
      navigator.clipboard
        .writeText(text)
        .then(() => {
          $.notify("Text coiped", "success");
        })
        .catch((err) => {
          console.error("Clipboard copy failed:", err);
          fallbackCopyText(text);
        });
    } else {
      // Fallback for older browsers
      fallbackCopyText(text);
    }
  }

  function fallbackCopyText(text) {
    const textArea = document.createElement("textarea");
    textArea.value = text;

    // Avoid scrolling to bottom
    textArea.style.position = "fixed";
    textArea.style.top = "10px";
    textArea.style.right = "10px";

    document.body.appendChild(textArea);
    textArea.focus();
    textArea.select();

    try {
      const successful = document.execCommand("copy");
      if (successful) {
        $.notify("Text Copied!", "success");
      } else {
        $.notify("Press Ctrl+C to copy manually: " + text, "warning");
        // alert("Press Ctrl+C to copy manually: " + text);
      }
    } catch (err) {
      // console.error("Fallback copy failed:", err);
      // alert("Press Ctrl+C to copy manually: " + text);
      $.notify("Press Ctrl+C to copy manually: " + text, "warning");
    }

    document.body.removeChild(textArea);
  }

  $.ajax({
    type: "GET", // Use POST if needed for security or large payloads
    url: bhwdSmAjxScript.bhwdSmAjxUrl, // The AJAX URL provided by WordPress
    data: {
      action: "bhwd_showroom_data_access", // Specify the action for the backend handler
    },
    beforeSend: function () {
      $(".bhwd_MainCarousel").append(
        `<div style="display: flex ; justify-content: center ;" >
            <div class="spinner-border text-primary" role="status">
              <span class="visually-hidden">Loading...</span>
            </div>
          </div>`
      );
    },
    success: function (data, status) {
      $(".bhwd_MainCarousel").empty(
        `<div class="spinner-border text-primary" role="status">
            <span class="visually-hidden">Loading...</span>
          </div>`
      );
      // console.log(status);
      // console.log(data);
      bhwd_create_showroom_section(data);
      bhwdSlickSlider(".bhwdNestedCarousel");

      // Initialize popup listeners
    },
    error: function (xhr, status, error) {
      $.notify("Error loading data", "error");
      // console.error("AJAX error: ", status, error); // Handle AJAX errors
    },
  });

  function bhwd_create_showroom_section(data) {
    // Validate input data
    if (!data || typeof data !== "object") {
      console.error("Invalid data provided");
      return;
    }

    // Display error message if exists
    if (data.err) {
      displayAlert(data.message || "An error occurred", "warning");
      return;
    }

    // Reference to the main carousel container
    const $carousel = $(".bhwd_MainCarousel");

    // Display informational message if exists
    if (data.message) {
      displayAlert(data.message, "warning");
    }

    // Process each region if it exists
    const regions = {
      north: data.northCites,
      center: data.centerCites,
      south: data.southCites,
      abroad: data.aborad,
    };

    // Get default city from north region if available
    const defaultCity = data.northCites?.[0]?.select_city || null;

    // Process each region
    Object.entries(regions).forEach(([regionName, cities]) => {
      if (cities && cities.length > 0) {
        try {
          bhwdAppendCity(cities, defaultCity);
          bhwd_create_popup(cities);
        } catch (error) {
          console.error(`Error processing ${regionName} region:`, error);
          displayAlert(`Failed to load ${regionName} cities`, "danger");
        }
      }
    });
  }

  // Helper function to display alerts
  function displayAlert(message, type = "warning") {
    const alertClass = `alert-${type}`;

    let alertHtml =
      $(`<div class="alert ${alertClass} alert-dismissible fade show" role="alert">
            ${message}
            
        </div>`);

    $(".bhwd_MainCarousel").prepend(alertHtml);
  }

  // Replace spaces with hyphens and convert text to lowercase (slug-like format)
  function bhwd_replace_text(text) {
    return text.replace(/\s+/g, "-").toLowerCase();
  }

  // Append a city section to the main carousel
  function bhwdAppendCity(data, title) {
    $(".bhwd_MainCarousel").append(bhwdMainElement(data, title));
  }

  // Create the main carousel element for a city
  function bhwdMainElement(data, title) {
    return `<div class="bhwd-carousel-item">
      <div>
      <h2 class="bhwd_sm_title" >${title}</h2>
      </div>${bhwdNestedElement(data)}</div>`;
  }

  // Create the nested carousel inside a city section
  function bhwdNestedElement(data) {
    return `
      <div class="slick-slider bhwdNestedCarousel">
      ${bhwdCarouselNestedItems(data)}
      </div>`;
  }

  // Generate all nested items inside the nested carousel
  function bhwdCarouselNestedItems(data) {
    let nestedItems = ""; // Initialize an empty string to hold all nested items
    $.each(data, function (key, value) {
      let content = value.content;

      // console.log(content.image);
      // console.log(value)

      nestedItems += `<div class="bhwd-carousel-nested-item slick-slide slick-initialized slick-dotted" data-dot="${content.title}" > `;
      nestedItems += `<div class="bhwd-mobile-overly"></div>`;
      nestedItems += `<div class="bhwd_information_button">`;
      nestedItems += `<div class="bhwd_button_container">`;
      nestedItems += `<h4 class="mb-0 pb-0 text-light bhwd-title" >${value.title}</h4>`;
      nestedItems += `</div>`;
      nestedItems += `<div class="bhwd_button_container">`;
      nestedItems += `<button class="bhwd_pp_content_btn info" post-id="${value.id}" >Info</button>`;
      nestedItems += `</div>`;
      nestedItems += `<div class="bhwd_button_container">`;
      nestedItems += `<a href="${
        value.scopri ? value.scopri : "#"
      }" class="bhwd_pp_content_btn scopri" >`;
      nestedItems += `<button>Scopri</button>`;
      nestedItems += ` </a>`;
      nestedItems += `</div>`;
      nestedItems += `</div>`;
      nestedItems += `<img src="${
        content.image
          ? content.image
          : "https://via.placeholder.com/800x300?text=Non+trovato"
      }" class="bhwd-d-block bhwd-w-100" alt="${
        value.title || "have no title"
      }"></img>`;
      // nestedItems += titleObjectForDotPagination(value);
      nestedItems += `</div> `;

      // nestedItems += `<p>${titleObjectForDotPagination(value)}</p>`;
    });
    return nestedItems; // Return the concatenated nested items
  }

  function bhwdSlickSlider(selector) {
    $(selector).slick({
      slidesToShow: 3,
      slidesToScroll: 1,
      dots: true,
      infinite: true,
      centerMode: true,
      focusOnSelect: true,
      arrows: true,
      arrows: false,
      customPaging: function (slider, i) {
        var dotText = $(slider.$slides[i]).attr("data-dot");
        return '<span class="custom-dot-text">' + dotText + "</span>";
      },
      responsive: [
        {
          breakpoint: 768,
          settings: {
            slidesToShow: 1,
            slidesToScroll: 1,
            centerPadding: "0px",
            arrows: false,
          },
        },
      ],
    });
  }
});
