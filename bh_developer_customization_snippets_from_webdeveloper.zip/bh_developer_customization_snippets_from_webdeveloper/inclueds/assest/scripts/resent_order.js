jQuery(document).ready(function($) {
  // 1. Collapsible functionality
 $(".collapsButtonsBHD").each(function(i, el) {
  var $button = $(this);
  var $container = $(".collapsContinerBHD").eq(i);

  $button.on("click", function() {
    $container.toggleClass("show");
  });
});
  // 2. Combined copy functionality for both classes
  $(".bhwd_order_id, .orderId").each(function() {
    var $el = $(this);
    var originalText = $el.text().trim(); // Added trim() to clean whitespace
    
    $el.css({
      'cursor': 'pointer',
      'transition': 'all 0.3s ease' // Smooth color transition
    }).attr('title', 'Click to copy');
    
    $el.on('click', function() {
      // Create temporary textarea for copy fallback
      var textarea = $('<textarea>').val(originalText).css({
        position: 'fixed',
        left: '-9999px'
      }).appendTo('body');
      
      try {
        textarea.select();
        document.execCommand('copy');
        
        // Modern clipboard API with fallback
        if (!navigator.clipboard) {
          $el.text('Copied!').css('color', '#4CAF50');
        } else {
          navigator.clipboard.writeText(originalText)
            .then(function() {
              $el.text('Copied!').css('color', '#4CAF50');
            })
            .catch(function(err) {
              console.error('Failed to copy: ', err);
              $el.text('Copy failed').css('color', '#f44336');
            });
        }
        
        // Revert after 1.5 seconds
        setTimeout(function() {
          $el.text(originalText).css('color', '');
        }, 1500);
        
      } finally {
        textarea.remove();
      }
    });
  });
});