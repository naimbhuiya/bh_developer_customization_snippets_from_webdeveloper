<?php

function recent_5_order_list_shortcode_bhdcsfw(){
    // Check if the user is logged in
    if (is_user_logged_in()) {
        // Get the current user object
        $current_user = wp_get_current_user();
        
        // Get the current user's ID
        $user_id = $current_user->ID;
        
        // Get the 5 most recent orders for the current user
        $recent_orders = wc_get_orders(array(
            'limit'        => 5,
            'customer_id'  => $user_id,
            'orderby'      => 'date',
            'order'        => 'DESC',
        ));
        
        // Check if there are any recent orders for the current user
        if ($recent_orders) {
            echo '<h2>Recent Orders</h2>';
            
            // Loop through each recent order
            foreach ($recent_orders as $order) {
                echo '<h3>Order #' . $order->get_id() . '</h3>';
                
                // Get items in the order
                $items = $order->get_items();
                
                // Check if there are any items in the order
                if (!empty($items)) {
                    echo '<ul>';
                    
                    // Loop through each item in the order
                    foreach ($items as $item) {
                        // Get product ID
                        $product_id = $item->get_product_id();
                        
                        // Get product object
                        $product = wc_get_product($product_id);
                        
                        // Get product details
                        $product_image = $product->get_image();
                        $product_title = $product->get_name();
                        $product_price = $product->get_price_html();
                        
                        // Display product details
                        echo '<li>';
                        echo '<div>' . $product_image . '</div>';
                        echo '<div>';
                        echo '<p>' . $product_title . '</p>';
                        echo '<p>' . $product_price . '</p>';
                        echo '</div>';
                        echo '</li>';
                    }
                    
                    echo '</ul>';
                } else {
                    echo 'No items found in this order.';
                }
            }
        } else {
            echo 'No recent orders for the current user.';
        }
    } else {
        echo 'Please log in to view recent orders.';
    }
}

add_shortcode('recent_5_order_bhdcsfw', 'recent_5_order_list_shortcode_bhdcsfw');


// footerPost Grid
require_once(plugin_dir_path(__FILE__) . 'archivepagefooterpost/arcivefooterpost.php');

// Archive page product slider
require_once(plugin_dir_path(__FILE__) . 'archivepagefooterpost/archive_prdct_carasoul/index.php');