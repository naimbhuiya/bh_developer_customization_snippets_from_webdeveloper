<?php
function enqueue_archive_page_script() {
    // Enqueue Bootstrap CSS from a CDN
    wp_enqueue_style('bhdcsfw-archive_page_script', plugin_dir_url(__FILE__) . 'style.css', array(), '1.0.0' , 'all');

}
add_action( 'wp_enqueue_scripts', 'enqueue_archive_page_script' );

class FooterPost {
    private $args;

    public function __construct($args = array()) {
        $this->args = wp_parse_args($args, array(
            'post_type'      => 'post',
            'posts_per_page' => 5,
            'post_status'    => 'publish',
            'orderby'        => 'date',
            'order'          => 'DESC',
        ));
    }

    public function render() {
        $query = new WP_Query($this->args);

        if ($query->have_posts()) {
            $this->renderPosts($query);
            wp_reset_postdata();
        } else {
            echo '<p>No posts found</p>';
        }
    }

    private function renderPosts($query) {
        echo "<div class='d-flex flex-wrap archivePagePostFooter justify-content-center'>";

        $counter = 0;
        while ($query->have_posts()) {
            $query->the_post();
            $this->renderPost($counter++);
        }

        echo "</div>";
    }

    private function renderPost($counter) {
        $post_id = get_the_ID();
        $thumbnail = get_the_post_thumbnail_url($post_id, 'full');
        $title = get_the_title();
        $excerpt = wp_trim_words(get_the_excerpt(), 30);

        echo "<div class='postGridArchivePage post" . esc_attr($counter) . "'>";

        if ($thumbnail) {
            echo "<div class='image-element'><img src='" . esc_url($thumbnail) . "' alt='" . esc_attr($title) . "'></div>";
        }

        echo "<h2 class='post-card-title-954'>
                <a href='" . esc_url(get_permalink()) . "'>" . esc_html($title) . "</a>
              </h2>";
        echo "<p>
                <a href='" . esc_url(get_permalink()) . "'>" . esc_html($excerpt) . "</a>
              </p>";

        $this->renderCategories($post_id);
        $this->renderRandomProductCategory($post_id);

        echo "</div>";
    }

    private function renderCategories($post_id) {
        $categories = wp_get_post_categories($post_id);

        if (!empty($categories)) {
            echo "<div class='post-categories'>";
            foreach ($categories as $category_id) {
                $category = get_category($category_id);
                if ($category) {
                    echo "<a href='" . esc_url(get_category_link($category)) . "'>" . esc_html($category->name) . "</a> ";
                }
            }
            echo "</div>";
        }
    }

    private function renderRandomProductCategory($post_id) {
        $product_categories = get_the_terms($post_id, 'product_cat');

        if ($product_categories && !is_wp_error($product_categories)) {
            $random_category = $product_categories[array_rand($product_categories)];
            if ($random_category) {
                echo "<div class='random-product-category'>
                        <a href='" . esc_url(get_term_link($random_category)) . "'>" . esc_html($random_category->name) . "</a>
                      </div>";
            }
        }
    }
}

// Shortcode to use the FooterPost class
function footer_post_shortcode() {
    $footerPost = new FooterPost();
    ob_start();
    $footerPost->render();
    return ob_get_clean();
}

add_shortcode('footerPostBHD', 'footer_post_shortcode');