<?php

function bhwd_owl_carasoul_assest_slider_assets() {
    wp_enqueue_style('bhwd-archive-carousel-Style', plugin_dir_url(__FILE__) . 'assests/style.css', array(), '1.0.0', 'all');

    wp_enqueue_style('Font-Awesome-5', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css', array(), '1.0.0', 'all');

    
}

add_action( 'wp_enqueue_scripts', 'bhwd_owl_carasoul_assest_slider_assets' );
// Fetch current category products or recent products if no category is selected
function bhwd_get_current_categories_product_sliders() {
    // Get the current category or a selected category from the admin panel
    $term = get_queried_object();
    $current_category_id = $term && isset($term->term_id) ? $term->term_id : null;
    $selected_category = get_option('bhwd_selected_category');
    $category_to_use = $selected_category ? $selected_category : $current_category_id;

    // Arguments for WP_Query
    $args = array(
        'post_type' => 'product',
        'posts_per_page' => 24,
    );

    if ($category_to_use) {
        $args['tax_query'] = array(
            array(
                'taxonomy' => 'product_cat',
                'field' => 'term_id',
                'terms' => $category_to_use,
            ),
        );
    }

    $query = new WP_Query($args);

    // Carousel container
    ob_start();
    ?>
    <div class="bhwd_carasoul_items ">

        <?php
        if ($query->have_posts()) {
            while ($query->have_posts()) {
                $query->the_post();
                $bhwd_product_title = get_the_title();
                $bhwd_product_description = get_the_excerpt();
                $bhwd_product_id = get_the_ID();
                $bhwd_product_price = get_post_meta($bhwd_product_id, "_price", true);
                $bhwd_product_content = get_the_content();
                $bhwd_trimmed_description = wp_trim_words($bhwd_product_description, 15, '...Read More');
                
                if (empty(trim($bhwd_product_description))) {
                    $bhwd_trimmed_description = wp_trim_words($bhwd_product_content, 15, '...Read More');
                }
                ?>
                <div class="bhwd_carasoul_item ">
                    <?php echo do_shortcode('[jet_wishlist_button product_id="' . esc_attr($bhwd_product_id) . '" ]'); ?>
                    <a class="bhdw_product_container" href="<?php echo get_permalink() ?>">
                    <img src="<?php echo esc_url(get_the_post_thumbnail_url()); ?>" alt="<?php echo esc_attr($bhwd_product_title); ?>">
                    <div class="product_content">
                        <h4 class="bhwd_product_title title"><?php echo esc_html($bhwd_product_title); ?></h4>
                        <h4 class="bhwd_product_price">€ <?php echo esc_html($bhwd_product_price); ?></h4>
                        <p class="product_excerpt"><?php echo esc_html($bhwd_trimmed_description); ?></p>
                        <?php if (empty($bhwd_product_price)) { ?>
                            <h4 class="bhwd_product_button"><?php echo esc_html(get_option('bhwd_custom_text_field', 'Richiedi informazioni')); ?></h4>
                        <?php } ?>
                    </div>
                    </a>
                </div>
                <?php
            }
            wp_reset_postdata();
        }
        ?>

    </div>
    <script>
       jQuery(document).ready(function($) {
    // Initialize the nested Slick Slider with custom arrows
    $('.bhwd_carasoul_items').slick({
        slidesToShow: 5,
        slidesToScroll: 1,
        dots: false,
        centerMode: false,
        focusOnSelect: true,
		infinite: true ,
        arrows: true,
        nextArrow: '<button type="button" class="slick-next"><i class="fa fa-chevron-right"></i></button>',
        prevArrow: '<button type="button" class="slick-prev"><i class="fa fa-chevron-left"></i></button>',
        responsive: [
            {
                breakpoint: 1080,
                settings: {
                    slidesToShow: 3,
                    slidesToScroll: 1,
                    centerPadding: '0px'
                }
            },
            {
                breakpoint: 768,
                settings: {
                    slidesToShow: 2,
                    slidesToScroll: 1,
                    centerPadding: '0px'
                }
            }
        ]
    });
});
        
    </script>
    <?php
    return ob_get_clean();
}


function bhwd_get_current_categories_product_sliders_on_sale() {
    // Get the current queried category or selected category from the admin panel
    $term = get_queried_object();
    $current_category_id = $term && isset($term->term_id) ? $term->term_id : null;
    $selected_category = get_option('bhwd_selected_category');
    $category_to_use = $selected_category ? $selected_category : $current_category_id;

    // Get on-sale products
    $args = array(
        'post_type' => 'product',
        'posts_per_page' => 24,
        'meta_query' => array(
            array(
                'key' => '_sale_price',
                'value' => 0,
                'compare' => '>',
                'type' => 'NUMERIC'
            )
        )
    );

    if ($category_to_use) {
        $args['tax_query'] = array(
            array(
                'taxonomy' => 'product_cat',
                'field' => 'term_id',
                'terms' => $category_to_use,
            ),
        );
    }

    $query = new WP_Query($args);

    // If no on-sale products found, get random 24 products from the current category
    if (!$query->have_posts()) {
        $args = array(
            'post_type' => 'product',
            'posts_per_page' => 24,
            'orderby' => 'rand'
        );

        if ($category_to_use) {
            $args['tax_query'] = array(
                array(
                    'taxonomy' => 'product_cat',
                    'field' => 'term_id',
                    'terms' => $category_to_use,
                ),
            );
        }

        $query = new WP_Query($args);
    }

    // Carousel container
    ob_start();
    ?>
    <div class="bhwd_carasoul_items bhwd_carasoul_items_on_sale ">
      
        <?php
        if ($query->have_posts()) {
            while ($query->have_posts()) {
                $query->the_post();
                $bhwd_product_title = get_the_title();
                $bhwd_product_description = get_the_excerpt();
                $bhwd_product_id = get_the_ID();
                $bhwd_product_price = get_post_meta($bhwd_product_id, "_price", true);
                $bhwd_product_content = get_the_content();
                $bhwd_trimmed_description = wp_trim_words($bhwd_product_description, 15, '...Read More');

                // If description is empty, use content
                if (empty(trim($bhwd_product_description))) {
                    $bhwd_trimmed_description = wp_trim_words($bhwd_product_content, 15, '...Read More');
                }

                // Fallback for missing product image
                $product_image = get_the_post_thumbnail_url() ? get_the_post_thumbnail_url() : wc_placeholder_img_src();
                ?>
                <div class="bhwd_carasoul_item">
                    <?php echo do_shortcode('[jet_wishlist_button product_id="' . esc_attr($bhwd_product_id) . '" ]'); ?>
                    <a class="bhdw_product_container" href="<?php echo get_permalink(); ?>">
                        <img src="<?php echo esc_url($product_image); ?>" alt="<?php echo esc_attr($bhwd_product_title); ?>">
                        <div class="product_content">
                            <h4 class="bhwd_product_title title"><?php echo esc_html($bhwd_product_title); ?></h4>
                            <h4 class="bhwd_product_price">€ <?php echo esc_html($bhwd_product_price ? $bhwd_product_price : 'N/A'); ?></h4>
                            <!-- <p class="product_excerpt"><?php //echo esc_html($bhwd_trimmed_description); ?></p> -->
                            <?php if (empty($bhwd_product_price)) { ?>
                                <h4 class="bhwd_product_button"><?php echo esc_html(get_option('bhwd_custom_text_field', 'Richiedi informazioni')); ?></h4>
                            <?php } ?>
                        </div>
                    </a>
                    <hr>
                    <div class="product_categories">
                        <?php
                            $term_list = wp_get_post_terms($bhwd_product_id, 'product_cat');
                            if (!empty($term_list) && !is_wp_error($term_list)) {
                                // Get only the first category from the list
                                $first_term = $term_list[0];
                                ?>
                                <a class="bhwd-Product-category" href="<?php echo get_term_link($first_term); ?>"><?php echo esc_html($first_term->name); ?></a>
                                <?php
                            }else{
                                ?>
                                    <a class="bhwd-Product-category" href="product-category/Shop"><?php echo esc_html('Shop'); ?></a>
                                <?php
                            }
                        ?>
                    </div>
                </div>
                <?php
            }
            wp_reset_postdata();
        }
        ?>
   
    </div>
    <script>
        jQuery(document).ready(function($) {
            // Initialize the nested Slick Slider
            $('.bhwd_carasoul_items_on_sale').slick({
                slidesToShow: 5,
                slidesToScroll: 1,
                dots: false,
                centerMode: false,
                focusOnSelect: true,
				infinite: true ,
                nextArrow:true ,
                prevAprevArrow:true , 
                arrows: true,
                nextArrow: '<button type="button" class="slick-next"><i class="fa fa-chevron-right"></i></button>',
        prevArrow: '<button type="button" class="slick-prev"><i class="fa fa-chevron-left"></i></button>',
                responsive: [
                    {
                        breakpoint: 1080,
                        settings: {
                            slidesToShow: 3,
                            slidesToScroll: 1,
							centerPadding: '0px'
                        }
                    },
                    {
                        breakpoint: 768,
                        settings: {
                            slidesToShow: 2,
                            slidesToScroll: 1,
							centerPadding: '0px'
                        }
                    }
                ]
            });

            // jQuery for controlling carousel dots
// 			jQuery('.bhwdNestedCarousel')
        });
       
    </script>
    <?php
    return ob_get_clean();
}


// Add shortcode for displaying on-sale product slider
add_shortcode('bhwd_woo_pr_slider_on_sale', 'bhwd_get_current_categories_product_sliders_on_sale');




add_shortcode('bhwd_woo_pr_slider', 'bhwd_get_current_categories_product_sliders');
?>