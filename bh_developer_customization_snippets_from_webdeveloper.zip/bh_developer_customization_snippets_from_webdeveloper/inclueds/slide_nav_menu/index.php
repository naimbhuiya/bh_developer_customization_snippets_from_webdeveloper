<?php
// Function to generate custom CSS dynamically
function bhwd_custom_css_sliding_nav() {
    $custom_bhwd_css = '
        .bhwd-menu-nav-wrap > ul > li {
            border-top: ' . ( !empty(get_option('bhwd_menu_item_border_top')) ? esc_attr(get_option('bhwd_menu_item_border_top')) . 'px solid ' . esc_attr(get_option('bhwd_menu_item_border_top_color')) : 'none' ) . ';
            border-bottom: ' . ( !empty(get_option('bhwd_menu_item_border_bottom')) ? esc_attr(get_option('bhwd_menu_item_border_bottom')) . 'px solid ' . esc_attr(get_option('bhwd_menu_item_border_bottom_color')) : '1px solid #dadada' ) . ';
            border-left: ' . ( !empty(get_option('bhwd_menu_item_border_left')) ? esc_attr(get_option('bhwd_menu_item_border_left')) . 'px solid ' . esc_attr(get_option('bhwd_menu_item_border_left_color')) : 'none' ) . ';
            border-right: ' . ( !empty(get_option('bhwd_menu_item_border_right')) ? esc_attr(get_option('bhwd_menu_item_border_right')) . 'px solid ' . esc_attr(get_option('bhwd_menu_item_border_right_color')) : 'none' ) . ';
            transition: 0.4s;
        }
        .bhwd-menu-nav-wrap > ul > li:hover {
            border-top: ' . ( !empty(get_option('bhwd_menu_item_hover_border_top')) ? esc_attr(get_option('bhwd_menu_item_hover_border_top')) . 'px solid ' . esc_attr(get_option('bhwd_menu_item_hover_border_top_color')) : 'none' ) . ';
            border-bottom: ' . ( !empty(get_option('bhwd_menu_item_hover_border_bottom')) ? esc_attr(get_option('bhwd_menu_item_hover_border_bottom')) . 'px solid ' . esc_attr(get_option('bhwd_menu_item_hover_border_bottom_color')) : '1px solid #dadada' ) . ';
            border-left: ' . ( !empty(get_option('bhwd_menu_item_hover_border_left')) ? esc_attr(get_option('bhwd_menu_item_hover_border_left')) . 'px solid ' . esc_attr(get_option('bhwd_menu_item_hover_border_left_color')) : 'none' ) . ';
            border-right: ' . ( !empty(get_option('bhwd_menu_item_hover_border_right')) ? esc_attr(get_option('bhwd_menu_item_hover_border_right')) . 'px solid ' . esc_attr(get_option('bhwd_menu_item_hover_border_right_color')) : 'none' ) . ';
        }
        .bhwd-menu-nav-wrap ul li:last-child {
            border: ' . esc_attr(get_option('bhwd_menu_item_border_style_child', '0px')) . ';
        }
        .bhwd-menu-nav-wrap > ul > li > p span a {
            color: ' . ( !empty(get_option('bhwd_menu_item_color')) ? esc_attr(get_option('bhwd_menu_item_color')) : '#000' ) . ';
            font-size: ' . ( !empty(get_option('bhwd_menu_item_font_size')) ? esc_attr(get_option('bhwd_menu_item_font_size')) : '16' ) . 'px;
        }
        .bhwd-menu-nav-wrap ul li p.bhwd-menu-item .bhwd-menu-item-angle i {
            color: ' . ( !empty(get_option('bhwd_menu_item_color')) ? esc_attr(get_option('bhwd_menu_item_color')) : '#000' ) . ';
        }
        .bhwd-submenu-panel {
            width: ' . ( !empty(get_option('bhwd_menu_container_width')) ? esc_attr(get_option('bhwd_menu_container_width')) : '300px' ) . ';
        }
    ';

    return $custom_bhwd_css;
}

// Enqueue styles and scripts
function bhwd_slider_nav_styles_and_script() {
    wp_enqueue_style(
        'bhdcsfw-style-slider-nav',
        plugin_dir_url(__FILE__) . 'assets/style.css',
        [],
        '1.0.0',
        'all'
    );

    wp_enqueue_script(
        'bhdcsfw-script-slider-nav',
        plugin_dir_url(__FILE__) . 'assets/script.js',
        [],
        '1.0.0',
        true
    );

    // Add inline CSS
    $custom_css = bhwd_custom_css_sliding_nav();
    wp_add_inline_style('bhdcsfw-style-slider-nav', $custom_css);
}
add_action('wp_enqueue_scripts', 'bhwd_slider_nav_styles_and_script');


class Custom_Structure_Walker extends Walker_Nav_Menu {
    // Start Level (sub-menu rendering)
    public function start_lvl(&$output, $depth = 0, $args = null) {
        $indent = str_repeat("\t", $depth);

        // Open the submenu container
        $output .= "\n$indent<ul class=\"bhwd-submenu-panel bhwd-open-and-close-sub-menu\">\n";
        $output .= "<li class=\"prev-controlar\"><i class=\"fa-solid fa-angle-left\"></i></li>";
        $output .= "<div class=\"list-wrap\">\n";
    }

    // End Level
    public function end_lvl(&$output, $depth = 0, $args = null) {
        $output .= "</div>\n</ul>\n"; // Close submenu panel and wrapper
    }

    // Start Element (menu item rendering)
    public function start_el(&$output, $item, $depth = 0, $args = null, $id = 0) {
        $indent = ($depth) ? str_repeat("\t", $depth) : '';
        $classes = empty($item->classes) ? [] : (array) $item->classes;

        // Check if the item is a parent
        $is_parent = in_array('menu-item-has-children', $classes);
        if ($is_parent) {
            $classes[] = 'parent-menu-item'; // Add custom class for parent items
        }

        $class_names = join(' ', apply_filters('nav_menu_css_class', array_filter($classes), $item, $args));
        $class_names = $class_names ? ' class="' . esc_attr($class_names) . '"' : '';
		$image_size = '';
        // Fetch the menu image (provided by WP Menu Image plugin)
        $item->thumbnail_id = get_post_thumbnail_id( $item->ID ); // Main image
        $menu_image_has_been_called = wp_get_attachment_image(
                $item->thumbnail_id,
                $image_size,
                false,
                "class=bhwd-menu-item-image"
            ) ;
        // Start list item
        $output .= $indent . '<li' . $class_names . '>';

        // Menu item structure
        $output .= '<p class="bhwd-menu-item">';

        // Include the menu image if available
        

		$output .= '<span class="bhwd-menu-item-text">';
		$output .= '<a href="' . esc_url($item->url) . '" class="main-item">';

		// Include the menu image if available
		if (!empty($menu_image_has_been_called)) {
			$output .= $menu_image_has_been_called;
		}

		// Append the menu title
		$output .= esc_html($item->title);
		$output .= '</a>';
		$output .= '</span>';

        // Submenu indicator for parent items
        if ($is_parent) {
            $output .= '<span class="bhwd-menu-item-angle bhwd-sub-menu-indicatior">';
            $output .= '<i class="fa-solid fa-angle-right"></i>';
            $output .= '</span>';
        }

        $output .= '</p>';
    }

    // End Element
    public function end_el(&$output, $item, $depth = 0, $args = null) {
        $output .= "</li>\n"; // Close list item
    }
}

// Create shortcode for sliding nav menu
function bhwd_wp_sliding_nav_menu() {
    ob_start();
    wp_nav_menu([
        'theme_location' => 'mobile-sliding-menu',
        'menu_id' => 'bhwd_nav_menu',
        'menu_class' => 'bhwd_nav_menu',
        'container_class' => 'bhwd-menu-nav-wrap',
        'walker' => new Custom_Structure_Walker()
    ]);
    return ob_get_clean();
}
add_shortcode('bhwd_sliding_nav_menu', 'bhwd_wp_sliding_nav_menu');
