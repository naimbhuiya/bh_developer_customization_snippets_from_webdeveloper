document.addEventListener("DOMContentLoaded", () => {
  const bhwdSubMenuIndicatior = document.querySelectorAll(
    ".bhwd-sub-menu-indicatior" // bhwd-sub-menu-indicator
  );
  const bhwdMenuNavWrap = document.querySelector(".bhwd-menu-nav-wrap");
  const prevControlar = document.querySelectorAll(".prev-controlar");
  const bhwdOpenAndCloseSubMenu = document.querySelectorAll(
    ".bhwd-open-and-close-sub-menu"
  );

  bhwdSubMenuIndicatior.forEach((item, i) => {
    item.addEventListener("click", (e) => {
      e.preventDefault();

      const currentSubMenu = bhwdOpenAndCloseSubMenu[i];
      const isOpen = currentSubMenu.classList.contains("bhwd-open-panel");

      // Close all open submenus
      document
        .querySelectorAll(".bhwd-submenu-panel.bhwd-open-panel")
        .forEach((openSubmenu) => {
          openSubmenu.classList.remove("bhwd-open-panel");
        });

      // Toggle current submenu
      if (isOpen) {
        currentSubMenu.classList.remove("bhwd-open-panel");
        bhwdMenuNavWrap.classList.remove(
          "is-Open-Sub-Menu-Check-For-Paren-Wrapper"
        );
      } else {
        currentSubMenu.classList.add("bhwd-open-panel");
        bhwdMenuNavWrap.classList.add(
          "is-Open-Sub-Menu-Check-For-Paren-Wrapper"
        );
      }
    });
  });

  // Submenu closer function
  prevControlar.forEach((elements, i) => {
    elements.addEventListener("click", () => {
      const currentSubMenu = bhwdOpenAndCloseSubMenu[i];
      currentSubMenu.classList.remove("bhwd-open-panel");

      // Check if any submenu is still open
      const anySubMenuOpen = Array.from(bhwdOpenAndCloseSubMenu).some(
        (submenu) => submenu.classList.contains("bhwd-open-panel")
      );

      if (!anySubMenuOpen) {
        bhwdMenuNavWrap.classList.remove(
          "is-Open-Sub-Menu-Check-For-Paren-Wrapper"
        );
      }
    });
  });
});
