<?php
function bhwd_enqueue_bootstrap_css() {
    // Enqueue Bootstrap CSS from a CDN
    wp_enqueue_style( 'bootstrap-css', 'https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css', array(), '5.2.3' );
    wp_enqueue_style( 'font-awesome-css', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css', array(), '6.5.1' );
}

function bhwd_bootstrap_enque_js() {
    // Enqueue Popper.js
    wp_enqueue_script(
        'popper-js',
        'https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js',
        array('jquery-slim'),
        '1.12.9',
        true // Load in footer
    );

    // Enqueue Bootstrap JS
    wp_enqueue_script(
        'bootstrap-js',
        'https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js',
        array('popper-js'),
        '4.0.0',
        true // Load in footer
    );


}

add_action('wp_enqueue_scripts', 'bhwd_bootstrap_enque_js');

add_action('wp_enqueue_scripts', 'bhwd_enqueue_bootstrap_css' );





/**
 * includes all short code or element
*/

// Slide Nav Admin Style... 
require_once(plugin_dir_path(__FILE__) . 'slide_nav_menu/index.php');

// 𝘱𝘳𝘰𝘧𝘪𝘭𝘦 𝘴𝘩𝘰𝘳𝘵 𝘤𝘰𝘥𝘦 
require_once(plugin_dir_path(__FILE__) . 'profile_short_code/profile_short_code.php');

// ADS 𝘴𝘩𝘰𝘳𝘵 𝘤𝘰𝘥𝘦 
require_once(plugin_dir_path(__FILE__) . 'ads/bhdcsfw-ads.php');

// Product Related Categories slider 𝘴𝘩𝘰𝘳𝘵 𝘤𝘰𝘥𝘦 
require_once(plugin_dir_path(__FILE__) . 'related_categories/bhdcsfw_related_categories.php');
// wc shortcode file inqluedes 
require_once(plugin_dir_path(__FILE__) . 'wc-shortcodes/wc_shortcodes.php');

// wc shortcode file inqluedes 
require_once(plugin_dir_path(__FILE__) . 'recent-5-orderlist/recent_5_order_list.php');


// wc recent 5 product shortcode file inqluedes 
require_once(plugin_dir_path(__FILE__) . 'recent_product/index.php');

// translator shortcode file inqluedes 
require_once(plugin_dir_path(__FILE__) . 'translator/index.php');

// Footer Categories Slider shortcode file inqluedes 
require_once(plugin_dir_path(__FILE__) . 'footer_nav_slider/index.php');

// Categories current product shortcode file inqluedes 
require_once(plugin_dir_path(__FILE__) . 'woo_products/index.php');

// Slider Nav For Mobile Header shortcode file inqluedes 
// require_once(plugin_dir_path(__FILE__) . 'slider_nav_for_mobile/index.php');

// The file Incluedes in form Custom Showroom Carousel
require_once(plugin_dir_path(__FILE__) . 'showroom/carousel.php');

// The file Incluedes in form Scheda Clienti
require_once(plugin_dir_path(__FILE__) . 'scheda-clienti/index.php');