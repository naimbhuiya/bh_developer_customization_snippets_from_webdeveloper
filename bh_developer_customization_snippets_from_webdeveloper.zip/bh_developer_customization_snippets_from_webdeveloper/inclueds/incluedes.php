<?php
function bhwd_enqueue_bootstrap_css() {
    // Enqueue Bootstrap CSS from a CDN
    wp_enqueue_style( 'bootstrap-css', 'https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css', array(), '5.2.3' );
    wp_enqueue_style( 'font-awesome-css', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css', array(), '6.5.1' );
}

function bhwd_bootstrap_enque_js() {
    // Enqueue Bootstrap JS
    wp_enqueue_script(
        'bootstrap-js',
        'https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js',
        array('popper-js'),
        '4.0.0',
        true // Load in footer
    );

    // wp_enqueue_script('bhwd_notify-plug-js', plugin_dir_url(__FILE__) . 'assest/notify.js', array(), '1.0.1', true);

}

add_action('wp_enqueue_scripts', 'bhwd_bootstrap_enque_js');

add_action('wp_enqueue_scripts', 'bhwd_enqueue_bootstrap_css' );





/**
 * includes all short code or element
*/
// translator shortcode file inqluedes 
require_once(plugin_dir_path(__FILE__) . 'plugins/index.php');

// translator shortcode file inqluedes 
require_once(plugin_dir_path(__FILE__) . 'assest/index.php');


// translator shortcode file inqluedes 
require_once(plugin_dir_path(__FILE__) . 'lib/index.php');

// translator shortcode file inqluedes 
require_once(plugin_dir_path(__FILE__) . 'translator/index.php');

// The file Incluedes in form Scheda Clienti
require_once(plugin_dir_path(__FILE__) . 'scheda-clienti/index.php');

// The file Incluedes in form sing in , sing up
require_once(plugin_dir_path(__FILE__) . 'sing/index.php');

