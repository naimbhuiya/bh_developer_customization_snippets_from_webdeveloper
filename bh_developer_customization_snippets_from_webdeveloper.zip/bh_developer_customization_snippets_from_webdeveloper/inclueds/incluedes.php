<?php
/**
 * includes all short code or element
*/
// 𝘱𝘳𝘰𝘧𝘪𝘭𝘦 𝘴𝘩𝘰𝘳𝘵 𝘤𝘰𝘥𝘦 
require_once(plugin_dir_path(__FILE__) . 'profile_short_code/profile_short_code.php');

// ADS 𝘴𝘩𝘰𝘳𝘵 𝘤𝘰𝘥𝘦 
require_once(plugin_dir_path(__FILE__) . 'ads/bhdcsfw-ads.php');