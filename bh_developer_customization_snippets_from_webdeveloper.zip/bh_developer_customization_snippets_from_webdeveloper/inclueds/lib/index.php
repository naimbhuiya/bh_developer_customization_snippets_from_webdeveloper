<?php 

/**
 * Reqiure from woo folder all files
 */
require_once(plugin_dir_path(__FILE__) . 'woo/archive_footer_post.php');
require_once(plugin_dir_path(__FILE__) . 'woo/cat_meta.php');
require_once(plugin_dir_path(__FILE__) . 'woo/cat_slider.php');
require_once(plugin_dir_path(__FILE__) . 'woo/customer_resent_order.php');
require_once(plugin_dir_path(__FILE__) . 'woo/foooter_cat_slider.php');
require_once(plugin_dir_path(__FILE__) . 'woo/products.php');
require_once(plugin_dir_path(__FILE__) . 'woo/related_cat.php');
require_once(plugin_dir_path(__FILE__) . 'woo/resent_product.php');
require_once(plugin_dir_path(__FILE__) . 'woo/shortcode.php');
/**
 * Reqiure from root folder all files
 */
require_once(plugin_dir_path(__FILE__) . 'ads.php');
require_once(plugin_dir_path(__FILE__) . 'desktop_secondary_menu.php');
require_once(plugin_dir_path(__FILE__) . 'mobile_nav.php');
require_once(plugin_dir_path(__FILE__) . 'showroom.php');

