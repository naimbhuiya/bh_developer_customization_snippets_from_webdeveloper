<?php


add_action('rest_api_init', function () {
    register_rest_route('bhwd/v1', '/menu_init/(?P<location>[a-zA-Z0-9_-]+)', [
        'methods'  => 'GET',
        'callback' => 'get_menu_by_location',
        'permission_callback' => '__return_true',
    ]);
});
add_image_size('bhwd-menu-small', 100, 100, true);

function get_menu_by_location($data) {
    $location = $data['location'];
    $locations = get_nav_menu_locations();

    if (!isset($locations[$location])) {
        return new WP_Error('invalid_location', 'Invalid menu location', ['status' => 404]);
    }

    $menu_id = $locations[$location];
    $menu_items = wp_get_nav_menu_items($menu_id);

    // Build tree
    $tree = [];
    $refs = [];

    foreach ($menu_items as $item) {
        $refs[$item->ID] = [
            'id'    => $item->ID,
            'title' => $item->title,
            'url'   => $item->url,
            'parent' => $item->menu_item_parent,
            'children' => [],
            'meta' => [
                'image'       => get_post_meta($item->ID, 'bhwd_menu_image', true),
                'description' => get_post_meta($item->ID, 'bhwd_custom_description', true),
            ]
        ];
    }

    foreach ($refs as $id => &$node) {
        if ($node['parent'] && isset($refs[$node['parent']])) {
            $refs[$node['parent']]['children'][] = &$node;
        } else {
            $tree[] = &$node;
        }
    }

    return rest_ensure_response($tree);
}


function nav_menu() {

    $locations = get_nav_menu_locations();

    if (!isset($locations['bhwd_desktop_menu'])) {
        echo '<ul class="bhwd_navbar_nav"><li class="nav-item">Menu not assigned</li></ul>';
        return;
    }

    $menu_id = $locations['bhwd_desktop_menu'];
    $menu_items = wp_get_nav_menu_items($menu_id);

    if (!$menu_items) {
        echo '<ul class="bhwd_navbar_nav"><li class="nav-item">No menu items found</li></ul>';
        return;
    }

    // Organize items into tree
    $menu_tree = [];
   
    foreach ($menu_items as $item) {
        $menu_tree[$item->menu_item_parent][] = $item;
    }

    // Recursive renderer
    $render_menu = function ($parent_id = 0, $depth = 0, $parent_item = null) use (&$render_menu, $menu_tree) {
        if (!isset($menu_tree[$parent_id])) return;
        global $primary_color , $checkPrimaryColor, $secondary_color, $checkSecondaryColor;
        // Get the primary color for the parent item
        $primary_color = get_post_meta($parent_item->ID ?? 0, 'bhwd_primary_color', true);
        $checkPrimaryColor = !empty($primary_color) ? 'style=" background: ' . $primary_color . ';"': '';

        // Get the secondary color for the parent item
        $secondary_color = get_post_meta($parent_item->ID ?? 0, 'bhwd_secondary_color', true);
        $checkSecondaryColor = !empty($secondary_color) ? 'style=" background: ' . $secondary_color .' ; "': '';
       
        if ($depth === 0) {
            echo '<ul class="bhwd_navbar_nav  bhwd_overflow_x_scroll m-0 p-0" >';
        } elseif ($depth === 1) {
            echo '<div style="padding-top: 8px !important;" class="bhwd_sub_menu_container border-radius-last-nav-container container-fluid p-0 m-0" ><div class="bhwd_sub_container container-fluid h-100" ' .  $checkPrimaryColor  . ' ><div class="row">';
            echo '<div class="col-9 d-flex p-0"><ul class="bhwd_submenu m-0 " ' . $checkSecondaryColor . '  >';
            echo '<li class="bhwd_submenu_item bhwd_submenu_title "><a class="text-nowrap bhwd_menu_title  py-2" >' . esc_html($parent_item->title) . '</a></li>';
        } else {
            $check_the_third_dept = $depth === 2 ? 'bhwd_third_sub_menu' : '';
            echo '<ul class="bhwd_sub_submenu m-0 '. $check_the_third_dept .'" >';
        }

        $actual_link = ( isset( $_SERVER['HTTPS'] ) ? "https" : "http" ) . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
        // Check if the menu location is set


        $bhwd_counter = 0;
        foreach ($menu_tree[$parent_id] as $item) {
            $bhwd_active_class = $actual_link === $item->url ? "bhwd_active_link" : " " ;
            $bhwd_counter++;
            $has_children = isset($menu_tree[$item->ID]);
            $primary_color = get_post_meta($item->ID, 'bhwd_primary_color', true);
            $secondary_color = get_post_meta($item->ID, 'bhwd_secondary_color', true);

            // Data Attr Color
            $data_color_attr = !empty($primary_color) && $depth === 0 ? 'data-color="' . $primary_color . '"' : '';

             $li_classes = array();
            if ($depth === 0) {
                $li_classes[] = 'bhwd_nav_item rounded-pill';
                if ($has_children) {
                    $li_classes[] = 'bhwd_nav_item_has_children';
                }
            } else {
                $li_classes[] = 'bhwd_submenu_item';
            }
        
            if ($has_children && $depth === 1) {
                $li_classes[] = 'bhwd_submenu_has_children';
                $li_classes[] = 'bhwd_depth_' . $depth . '_submenu';
                if ($bhwd_counter === 1) {
                    $li_classes[] = 'bhwd_submenu_active';
                }

                
            }

        
            echo '<li class="' . esc_attr(implode(' ', $li_classes)) . ' ' . $bhwd_active_class . '" ' . $data_color_attr . 'post-id="' . $item->ID . '">';
            
            echo '<a class=" pe-1 ps-1 py-2 " href="' . esc_url($item->url) . '">' . esc_html($item->title) ;
            if ($has_children && $depth === 1) {
                echo '<span class="bhwd_submenu_arrow"><i class="fa-solid fa-angle-right"></i></span>';
            }
            echo '</a>';

            // Recurse into children
            if ($has_children) {
                $render_menu($item->ID, $depth + 1, $item);
            }
        
            echo '</li>';
        }


        if ($depth === 0) {
            echo '</ul>';
        } elseif ($depth === 1) {
            echo '</ul>'; // end col-9
         
            $getCusmText = get_post_meta($parent_item->ID ?? 0, 'bhwd_custom_text', true);
            $display_text = !empty($getCusmText) ? esc_html($getCusmText) : esc_html($parent_item->title);
            ?>
        
                <div class="d-flex flex-wrap align-items-between  " <?php echo $checkSecondaryColor; ?>>
                    <p class="text-nowrap w-100 bhwd_menu_title px-3 py-2"><?php echo $display_text; ?></p>

                    <div class="d-flex align-items-end">
                        <?php 
                        $getCusmButtonText = get_post_meta($parent_item->ID ?? 0, 'bhwd_custom_html_for_footer', true);

                        if (!empty($getCusmButtonText)) {
                            echo '<div class="bhwd_custom_html_for_footer px-3 py-2">' . wp_kses_post($getCusmButtonText) . '</div>';
                        } elseif (defined('WP_DEBUG') && WP_DEBUG && is_admin()) {
                            echo '<div class="bhwd_custom_html_for_footer px-3 py-2">No custom HTML available</div>';
                        }
                        ?>
                    </div>
                </div>
           
            <?php
            echo '</div>';

            // Get image/description from current parent item (not child loop)
            
            $image_size = 'medium_large';
            $image = wp_get_attachment_image( get_post_meta($parent_item->ID ?? 0, 'bhwd_menu_image', true) , 'bhwd-menu-small' , false , [
				'class' => 'bhwd_menu_image',
			] );
            $description = get_post_meta($parent_item->ID ?? 0, 'bhwd_custom_description', true);

            echo '<div class="col-3">';
            if ($image) {
                echo '<div class="bhwd_submenu_images">'.  $image .'</div>';
            }else {
                echo '<div class="bhwd_submenu_images"><img width="300" height="300" decoding="async" loading="lazy" src="' . esc_url(plugin_dir_url(__FILE__) . 'Image-not-found.png') . '" alt="Default Image" class="bhwd_menu_image"></div>';
            }
            if ($description) {
                echo '<div class="bhwd_submenu_descriptions"><p class="bhwd_menu_description">' . esc_html($description) . '</p></div>';
            }else {
				if (current_user_can('manage_options')){
					echo '<div class="bhwd_submenu_descriptions"><p class="bhwd_menu_description">No description available</p></div>';
				}
                
            }
            echo '</div>'; // end col-3

            echo '</div></div></div>'; // end row and container
        } else {
            echo '</ul>';
        }
    };

    $render_menu(0);
}

function bhwd_side_nav()  {
    $locations = get_nav_menu_locations();

    ?>
    <div class="bhwd_side_menu_container bg-white shadow-sm" style="padding-top: 8px ;">
        <div class="bhwd_side_menu_sub_container vh-height" >
            <div class="row vh-height ">
                <div class="col-4 h-100 ovf-auto">
                <?php
                    if (!isset($locations['bhwd_desktop_menu'])) {
                        echo '<ul class="bhwd_side_menu"><li class="nav-item">Menu not assigned</li></ul>';
                        return;
                    }

                    $menu_id = $locations['bhwd_desktop_menu'];
                    $menu_items = wp_get_nav_menu_items($menu_id);

                    if (!$menu_items) {
                        echo '<ul class="bhwd_side_menu"><li class="nav-item">No menu items found</li></ul>';
                        return;
                    }

                    // Render only depth 1 (top-level) menu items
                    echo '<ul class="bhwd_side_menu h-100">';
                    foreach ($menu_items as $item) {
                        if ((int) $item->menu_item_parent !== 0) {
                            continue; // Skip non-top-level items
                        }

                        $image = wp_get_attachment_url(get_post_thumbnail_id($item->ID));
                        $image_tag = $image ? '<img src="' . esc_url($image) . '" alt="' . esc_attr($item->title) . '" class="bhwd_menu_icon">' : '';

                        $actual_link = (isset($_SERVER['HTTPS']) ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
                        $bhwd_active_class = $actual_link === $item->url ? "bhwd_active_link" : "";

                        echo '<li class="bhwd_side_nav-item ' . esc_attr($bhwd_active_class) . ' bhwd_list d-block "  post-id="' . esc_attr($item->ID) . '">';
                        echo '<a href="' . esc_url($item->url) . '" class="nav-link">' . $image_tag . esc_html($item->title) . '</a>';
                        echo '</li>';
                    }
                    echo '</ul>';
                    ?>
                </div>
                <div class="col-8">
                    <div class="bhwd_side_sub_menu_container" >

                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php
}

 

add_action('after_setup_theme', function() {
    register_nav_menu('bhwd_desktop_menu', __('Desktop Menu', 'bhdcsfw'));
});
function bhwd_custom_desktop_nav() {
    ob_start();
    ?>
    <nav class="w-100 d-flex align-items-center justify-content-between" id="bhwd_nav" >
    <div class="bhwd_side_nav_menu">
            <button class="btn text-danger bhwd_menu_toggle d-flex align-items-center px-0 gap-2 btn-outline-light border-0" id="bhwd_menu_toggle">
                <i class="fa-solid fa-bars"></i> TUTTE
            </button>
            <div class="bhwd_logo_container">
                <?php bhwd_side_nav(); ?>
            </div>
        </div>
        <div class="bhwd_menu_container  m-0">
            <div class="bhwd_menu_items">
                <?php
                nav_menu();
                ?>
            </div>
            <div class="bhwd_scroll_button_container">
                <button class="btn text-danger bhwd_scroll_left" id="bhwd_scroll_left">
                    <i class="fa-solid fa-angle-left"></i>
                </button>
                <button class="btn text-danger bhwd_scroll_right" id="bhwd_scroll_right">
                    <i class="fa-solid fa-angle-right"></i>
                </button>
            </div>
        </div>
    </nav>
    <?php
    return ob_get_clean();
}
add_shortcode('bhwd_desktop_menu', 'bhwd_custom_desktop_nav');