<?php 

// 1. Add the column header
add_filter('manage_woocat_slider_posts_columns', 'bhwd_add_shortcode_column');
function bhwd_add_shortcode_column($columns) {
    $columns['shortcode'] = __('Shortcode', 'textdomain');
    return $columns;
}

// 2. Display content in the custom column
add_action('manage_woocat_slider_posts_custom_column', 'bhwd_show_shortcode_column', 10, 2);
function bhwd_show_shortcode_column($column, $post_id) {
    if ($column === 'shortcode') {
        echo '<code>[bhwd_woo_cat_slider id="' . esc_attr($post_id) . '"]</code>';
    }
}


// 1. Add the column header
add_filter('manage_woocat_slider_posts_columns', 'bhwd_add_post_id_column_column');
function bhwd_add_post_id_column_column($columns) {
    $columns['postid'] = __('Post Id', 'textdomain');
    return $columns;
}

// 2. Display content in the custom column
add_action('manage_woocat_slider_posts_custom_column', 'bhwd_show_post_id_column', 10, 2);
function bhwd_show_post_id_column($column, $post_id) {
    if ($column === 'postid') {
        echo '<code>' . esc_attr($post_id) . '</code>';
    }
}
// Shortcode: [bhwd_woo_cat_slider id="123"]
function bhwd_woo_cat_slider_shortcode($atts) {
    ?>
    <style>
        .bhwd-owl-carousel .item {
           <?php print get_option( 'bhdcsfw-woo-cat-carousel-card-css' , '
            text-decoration: none !important;
            display: flex;
            flex-wrap: wrap;
            text-align: center;
            justify-content: center;
           '); ?>
        }

        .bhwd-owl-carousel img {
            <?php print get_option( 'bhdcsfw-woo-cat-carousel-image-css' , '
            width: 80px  !important ;
            height: 80px ;
            border: 1px solid #fbf5f5;
            border-radius: 50%;
            object-fit: cover;
            '); ?>
        }
        .bhwd-owl-carousel h4 {
            <?php print get_option( 'bhdcsfw-woo-cat-carousel-title-css' , '
            text-decoration: none;
            text-align: center;
            font-size: 13px;
            font-weight: 400;
            font-family: poppins;
            margin-top: 10px ;
			width: 100% ;
            '); ?>
        }
		
		.bhwd-alt-native-class{
				display: flex;
				overflow-x: hidden;
				
			    gap: 15px;
			}
        	.bhwd-alt-native-class a{
				width:  calc(100% / 8)   ;
			}
		@media (max-width: 500px ){
			.bhwd-owl-carousel img {
				width: 65px !important;
				height: 65px !important;

			}
			.bhwd-alt-native-class{
				display: flex;
				overflow-x: auto;
/* 			    white-space: nowrap; */
			    gap: 15px;
			}
			.bhwd-alt-native-class a{
				width:  calc(100% / 3) ;
			}
			.bhwd-alt-native-class a h4 {
				width: 120px ;
				overflow: hidden ;
			}
		}

		@media (max-width: 300px ){
			.bhwd-owl-carousel img {
				width: 55px !important;
				height: 55px !important;

			}
		}
    </style>
    <?php
    $atts = shortcode_atts([
        'id' => get_the_ID()
    ], $atts);

    $post_id = intval($atts['id']);
    if (!$post_id || get_post_status($post_id) === false) {
		if(is_admin()){
			return esc_html__('Invalid Post ID', 'textdomain');
		}
        return ;
    }

    $selected_cats = get_post_meta($post_id, '_woo_selected_cats', true);
    $selected_cats = !empty($selected_cats) ? explode(':', $selected_cats) : [];

    ob_start();
    if (!empty($selected_cats)) {
		?>
		<div style="position: relative ;" >
			<?php
			echo '<div class="bhwd-owl-carousel bhwd-alt-native-class">';
			foreach ($selected_cats as $cat_id) {
				$category = get_term($cat_id, 'product_cat');
				if ($category && !is_wp_error($category)) {
					$thumbnail_id = get_term_meta($cat_id, 'thumbnail_id', true);
					$image = $thumbnail_id ? wp_get_attachment_image($thumbnail_id, 'medium' ) : '<img loading="lazy" width="300" height="300" decoding="async"  src="'. wc_placeholder_img_src() .'" />';
					$custom_meta = get_term_meta($cat_id, 'bhwd_cat_to_get_mini_title', true);
					$custom_title = !empty($custom_meta) ? $custom_meta : $category->name ;
					echo '<a href="' . esc_url(get_term_link($category)) . '" class="item">';
					if ($image) {
						echo $image;
					}
					echo '<h4>' . esc_html( $custom_title ) . '</h4>';
					echo '</a>';
				}
			}

			echo '</div>';
			?>
			<div class="bhwd-arrow-buttons">
				<button class="bhwd-woocat-prev"><i class="fa-solid fa-chevron-left"></i></button>
				<button class="bhwd-woocat-next"><i class="fa-solid fa-chevron-right"></i></button>
			</div>
		</div>
        <?php
    } else {
       echo  is_admin() ? esc_html_e('No categories selected.', 'textdomain') : esc_html_e('', 'textdomain');
    }

    return ob_get_clean();
}
add_shortcode('bhwd_woo_cat_slider', 'bhwd_woo_cat_slider_shortcode');
