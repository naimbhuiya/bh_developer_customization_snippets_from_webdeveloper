<?php
// Create Function for footer all categories slider
function bhdcsfw_footer_all_categories_slider() {
    ob_start(); // Start output buffering
    ?>
    <div class="d-flex align-items-center">
        <div class="bhwd-item bhwd-leftSlidingArrowButton"><i class="fa-solid fa-arrow-left"></i></div>
        <div class="bhwd-item bhwd-itemFristStyleForAll">
            <a href="/all-categories/">All Categories <span class="bhwd-rightArrowsFooter"><i class="fa fa-link" aria-hidden="true"></i></span></a>
        </div>
        <div class="mainSliderMenu">
            <div class="bhwd-items">
                <?php
                // Retrieve product categories, limiting to 25 and shuffling
                $all_categories = get_terms(array(
                    'taxonomy'   => 'product_cat',
                    'hide_empty' => true,
                    'orderby'    => 'name',
                    'number'     => 0, // Retrieve all categories initially
                ));

                if (!is_wp_error($all_categories) && !empty($all_categories)) {
                    // Shuffle categories and limit to 25
                    shuffle($all_categories);
                    $categories = array_slice($all_categories, 0, 25);

                    foreach ($categories as $category) {
                        echo '<div class="bhwd-item sliderListItemList"><a href="' . esc_url(get_term_link($category)) . '">' . esc_html($category->name) . '</a></div>';
                    }
                } else {
                    echo '<div class="bhwd-item">No product categories found.</div>';
                }
                ?>
            </div>
        </div>
        <div class="bhwd-item bhwd-rightSlidingArrowButton"><i class="fa-solid fa-arrow-right"></i></div>
    </div>
    <?php
    return ob_get_clean(); // Return the output buffer content as shortcode output
}

// Register the shortcode
add_shortcode('footer_slider_categories', 'bhdcsfw_footer_all_categories_slider');

?>