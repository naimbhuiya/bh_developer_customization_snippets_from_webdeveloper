<?php

function recent_5_order_list_shortcode_bhdcsfw(){
    // Check if the user is logged in
    if (is_user_logged_in()) {
        // Get the current user object
        $current_user = wp_get_current_user();
        
        // Get the current user's ID
        $user_id = $current_user->ID;
        
        // Get the 5 most recent orders for the current user
        $recent_orders = wc_get_orders(array(
            'limit'        => 5,
            'customer_id'  => $user_id,
            'orderby'      => 'date',
            'order'        => 'DESC',
        ));
        
        // Check if there are any recent orders for the current user
        if ($recent_orders) {
            echo '<h2>Recent Orders</h2>';
            
            // Loop through each recent order
            foreach ($recent_orders as $order) {
                echo '<h3>Order #' . $order->get_id() . '</h3>';
                
                // Get items in the order
                $items = $order->get_items();
                
                // Check if there are any items in the order
                if (!empty($items)) {
                    echo '<ul>';
                    
                    // Loop through each item in the order
                    foreach ($items as $item) {
                        // Get product ID
                        $product_id = $item->get_product_id();
                        
                        // Get product object
                        $product = wc_get_product($product_id);
                        
                        // Get product details
                        $product_image = $product->get_image();
                        $product_title = $product->get_name();
                        $product_price = $product->get_price_html();
                        
                        // Display product details
                        echo '<li>';
                        echo '<div>' . $product_image . '</div>';
                        echo '<div>';
                        echo '<p>' . $product_title . '</p>';
                        echo '<p>' . $product_price . '</p>';
                        echo '</div>';
                        echo '</li>';
                    }
                    
                    echo '</ul>';
                } else {
                    echo 'No items found in this order.';
                }
            }
        } else {
            echo 'No recent orders for the current user.';
        }
    } else {
        echo 'Please log in to view recent orders.';
    }
}

add_shortcode('recent_5_order_bhdcsfw', 'recent_5_order_list_shortcode_bhdcsfw');


function current_category_subcategories_grid() {
    ob_start();
    ?>
    <style>
	.bhwd_cat_collamn{
		
	}
	.bhwd_box_image{
		position: relative;
    display: flex
;
    justify-content: center;
    align-items: center;
	overflow: hidden ;
		border-radius: 10px ; 
}
	.bhwd_box_image img{
		transition: .3s ;
		border-radius: 10px ;
		    width: 100%;
		height: 410px;
    object-fit: cover;
	}
	.bhwd_box_image:hover img{
		transform: scale(1.1) ;
	}
	.bhwd_box_image h3{
		    position: absolute;
			font-size: 20px;
			
			width: 95%;
			padding: 5px 20px;
			
			text-align: center ;
			text-transform: capitalize;
			top: 50%;
  left: 50%;
  -ms-transform: translate(-50%, -50%);
  transform: translate(-50%, -50%);
		transition: .4s ;
		color: #fff ;
			opacity: 0 ;
			visibility: hidden ;
		z-index: 2;
	}
	.bhwd_cat_title{
		    font-size: 18px;
    margin: 10px 0;
    text-align: center;
	}
		.bhwd_gap_{
			gap: 1% ;
			margin-right: -0.5%;
		}
		.bhwd_cat_collamn{
			width: 32.5% ;
		}
		.bhwd_grid_overly{
			position: absolute ;
			width: 100% ; 
			height: 100% ;
			background: #000 ;
			opacity: 0 ;
			visibility: hidden ;
			transition: 0.4s ;
		}
		.bhwd_box_image:hover .bhwd_grid_overly{
			opacity: 0.4 ;
			visibility: visible ;
			    z-index: 1;
		}
		.bhwd_box_image:hover .bhwd_hover_effact{
			opacity: 1 ;
			visibility: visible ;
		}
		@media (max-width: 1080px){
			.bhwd_cat_collamn{
			width: 49.5% ;
		}
			.bhwd_gap_{
				gap: 1% ;
				margin-right: -0.5%;
			}
		}
	@media (max-width: 768px){
		.bhwd_box_image h3 {
width: 100%;
			border-radius: 0px;
    font-size: 14px;
			border: none !important ;

}
		.bhwd_cat_collamn{
			width: 100% ;
		}
		.bhwd_gap_{
				margin-right: 0%;
			}
			.bhwd_box_image img{
		height: 300px;

	}
	}
</style>
<?php
    global $html;
    $html = '';

    if (is_product_category()) {
        $term_id = get_queried_object_id();
        $taxonomy = 'product_cat';

        // Get subcategories of the current category
        $terms = get_terms([
            'taxonomy'   => $taxonomy,
            'hide_empty' => false,
            'parent'     => $term_id
        ]);

       if (!empty($terms) && !is_wp_error($terms)) {
    $html .= '<div class="container-fluid px-0">';
    $html .= '<div class="d-flex p-sm-x-2 flex-wrap bhwd_gap_">';
    
    foreach ($terms as $term) {
        $image_id = get_term_meta($term->term_id, 'categories_second_feature_image', true);
        $bhwd_if_need = get_term_meta($term->term_id, 'bhwd_categories_need', true);
        $term_url = get_term_link($term);
        
        // Validate term link
        if (is_wp_error($term_url)) {
            $term_url = '#';
        }
        
        $term_title = esc_html($term->name);
        
        if ($bhwd_if_need === "yes") {
            $html .= '<a href="' . esc_url($term_url) . '" class="bhwd_cat_collamn px-0">';
            
            if (!empty($image_id)) {
                // Get image with responsive attributes and proper alt text
                $image_html = wp_get_attachment_image(
                    $image_id,
                    'medium', // Use a registered image size
                    false,
                    [
                        'class' => 'img-fluid',
                        'alt' => $term_title,
                        'loading' => 'lazy'
                    ]
                );
                
                if ($image_html) {
                    $html .= '<div class="bhwd_box_image">';
                    $html .= '<div class="bhwd_grid_overly"></div>';
                    $html .= $image_html;
                    $html .= '<h3 class="bhwd_hover_effact">' . $term_title . '</h3>';
                    $html .= '</div>';
                }
            }
            
            $html .= '<h3 class="bhwd_cat_title">' . $term_title . '</h3>';
            $html .= '</a>';
        }
    }
    
    $html .= '</div></div>';
} else {
    $html .= '<div class="alert alert-info">' . esc_html__('No subcategories found.', 'text-domain') . '</div>';
}
    } else {
        $html .= '<div class="alert alert-warning" role="alert">';
        $html .= 'Questa non è una pagina di archivio prodotti';
        $html .= '</div>';
    }

    echo $html;

    return ob_get_clean();
}
add_shortcode('current_category_subcategories_grid', 'current_category_subcategories_grid');
