<?php 

/**
 * Categories meta
 */

// Add Enter Shortcode to product category add form

$miniTitleText = 'Enter your Mini Title.' ;
$eneterShortcodeText = 'Enter your Cat Id.' ;
function bhwd_add_product_category_custom_field() {
    global $miniTitleText , $eneterShortcodeText;
    ?>
    <div class="form-field">
        <label for="bhwd_cat_to_get_shortcode"><?php _e($eneterShortcodeText , 'bhdcsfw'); ?></label>
        <input type="text" placeholder="<?php _e($eneterShortcodeText , 'bhdcsfw'); ?>" name="bhwd_cat_to_get_shortcode" id="bhwd_cat_to_get_shortcode" value="">


        <!-- Mini Title -->
        <label for="bhwd_cat_to_get_mini_title"><?php _e($miniTitleText , 'bhdcsfw'); ?></label>
        <input type="text" placeholder="<?php _e($miniTitleText , 'bhdcsfw'); ?>" name="bhwd_cat_to_get_mini_title" id="bhwd_cat_to_get_mini_title" value="">
       
    </div>
    <?php
}
add_action('product_cat_add_form_fields', 'bhwd_add_product_category_custom_field');

// Edit category Enter Shortcode
function bhwd_edit_product_category_custom_field($term) {
    $custom_value = get_term_meta($term->term_id, 'bhwd_cat_to_get_shortcode', true);
    global $miniTitleText , $eneterShortcodeText;
    ?>
    <tr class="form-field">
        <th scope="row" valign="top"><label for="bhwd_cat_to_get_shortcode"><?php _e($eneterShortcodeText , 'bhdcsfw'); ?></label></th>
        <td>
            <input type="text" placeholder="<?php _e($eneterShortcodeText , 'bhdcsfw'); ?>" name="bhwd_cat_to_get_shortcode" id="bhwd_cat_to_get_shortcode" value="<?php echo esc_attr($custom_value); ?>">
           
        </td>
    </tr>
    <tr class="form-field">
        <th scope="row" valign="top"><label for="bhwd_cat_to_get_mini_title"><?php _e( $miniTitleText , 'bhdcsfw'); ?></label></th>
        <td>
            <input type="text" placeholder="<?php _e($miniTitleText , 'bhdcsfw'); ?>" name="bhwd_cat_to_get_mini_title" id="bhwd_cat_to_get_mini_title" value="<?php echo esc_attr(get_term_meta($term->term_id, 'bhwd_cat_to_get_mini_title', true)); ?>">
        </td>
    <!-- mini title  -->
    <?php
}
add_action('product_cat_edit_form_fields', 'bhwd_edit_product_category_custom_field');

// Save Enter Shortcode value
function bhwd_save_product_category_custom_field($term_id) {
    if (isset($_POST['bhwd_cat_to_get_shortcode'])) {
        update_term_meta($term_id, 'bhwd_cat_to_get_shortcode', sanitize_text_field($_POST['bhwd_cat_to_get_shortcode']));
        update_term_meta($term_id, 'bhwd_cat_to_get_mini_title', sanitize_text_field($_POST['bhwd_cat_to_get_mini_title']));

    }
}
add_action('edited_product_cat', 'bhwd_save_product_category_custom_field');
add_action('create_product_cat', 'bhwd_save_product_category_custom_field');

// // Display Enter Shortcode in category list (optional)
// function bhwd_product_category_columns($columns) {
//     $columns['bhwd_cat_to_get_shortcode'] = __('Enter Shortcode', 'bhdcsfw');
//     return $columns;
// }
// add_filter('manage_edit-product_cat_columns', 'bhwd_product_category_columns');

function bhwd_product_category_column_content($content, $column_name, $term_id) {
    if ($column_name === 'bhwd_cat_to_get_shortcode') {
        $custom_value = get_term_meta($term_id, 'bhwd_cat_to_get_shortcode', true);
        $content = esc_html($custom_value);
    }
    return $content;
}
add_filter('manage_product_cat_custom_column', 'bhwd_product_category_column_content', 10, 3);


function bhwd_get_category_meta($category_id, $meta_key = 'bhwd_cat_to_get_shortcode') {
    if (is_object($category_id)) {
        $category_id = $category_id->term_id; // Get term ID if an object is passed
    }

    if (!$category_id) {
        return ''; // Return empty if category ID is missing
    }

    // Get current category meta
    $meta_value = get_term_meta($category_id, $meta_key, true);

    if (!empty($meta_value)) {
        return $meta_value; // If meta exists, return it
    }

    // Get parent category
    $category = get_term($category_id, 'product_cat');

    if (!is_wp_error($category) && $category->parent != 0) {
        // Check parent category meta
        $parent_meta = get_term_meta($category->parent, $meta_key, true);
        if (!empty($parent_meta)) {
            return $parent_meta;
        }
    }

    // Get main parent category (highest level)
    $main_parent_id = $category_id;
    while ($category->parent != 0) {
        $main_parent_id = $category->parent;
        $category = get_term($main_parent_id, 'product_cat');
    }

    return get_term_meta($main_parent_id, $meta_key, true) ?: ''; // Return main parent meta or empty string
}


function bhwd_show_custom_short_code() {
    ob_start();

    $current_category = get_queried_object();

    if ( isset($current_category->term_id) && !empty($current_category->term_id) ) {
        $category_meta_value = bhwd_get_category_meta($current_category);

        if ( !empty($category_meta_value) ) {
            // Call the correct shortcode function directly
            echo bhwd_woo_cat_slider_shortcode(['id' => $category_meta_value]);
        }
    }

    return ob_get_clean();
}
add_shortcode("bhwd_short", "bhwd_show_custom_short_code");
