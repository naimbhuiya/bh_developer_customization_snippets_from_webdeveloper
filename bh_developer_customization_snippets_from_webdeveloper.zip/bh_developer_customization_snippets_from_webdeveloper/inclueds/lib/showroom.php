<?php
function get_pages_with_elementor_content_and_meta() {
    $args = array(
        'post_type'      => 'dise-showroom',
        'posts_per_page' => -1,
        'orderby'        => 'menu_order',
        'order'          => 'ASC',
        
    );

    $query = new WP_Query($args);
    
     $relationalMeta = [];

    $form_id = get_option('bhwd_showroom_add_short_code');
    $formContent = '';
	// Check if the form ID is valid and exists
	if ($form_id) {
		// Load the form by ID and display it using Contact Form 7 API
		$contact_form = wpcf7_contact_form( $form_id );
		if ($contact_form) {
			$formContent = $contact_form->form_html(); // Display the form HTML directly
		} else {
			$formContent = '<h4>Contact form not found. Please check your settings or contact us at <a href="mailto:' . esc_attr(get_option('bhwd_showroom_email', 'info@disegnarecasa.com')) . '"><strong>Email Us</strong></a></h4>';
		}
	} else {
		$formContent = '<h4>Contact form not selected. Please select a form in the settings.</h4>';
	}

if ($query->have_posts()) {
    $relationalMeta = array(  );

    while ($query->have_posts()) {
        $query->the_post();

        // Fetch the value of the `select_city` meta key
        $bhwd_city = get_post_meta(get_the_ID(), 'dise_city', true);

        
        $bhwd_content = bhwd_showroom_get_page_content(get_the_ID());
        // Handle Contact Form 7 integration
        $form_id = get_option('bhwd_showroom_add_short_code', 0); // Default to 0 if not set
        $page_contact_form = '';
        if (function_exists('wpcf7_contact_form')) {
            $contact_form = wpcf7_contact_form($form_id);
            if ($contact_form) {
                $page_contact_form = $contact_form->form_html(); // Get the form HTML
            } else {
                $page_contact_form = '<h4>Contact form not found. Please check your settings or contact us at <a href="mailto:' . esc_attr(get_option('bhwd_showroom_email', 'info@disegnarecasa.com')) . '"><strong>Email Us</strong></a></h4>';
            }
        } else {
            $page_contact_form = '<p>Contact Form 7 plugin is not active or installed.</p>';
        }

        // Handle post thumbnail
        $post_thumbnail_id = get_post_meta(get_the_ID(), 'page_custom_image', true);
        $post_thumbnail = '';
        if (!empty($post_thumbnail_id)) {
            $post_thumbnail = wp_get_attachment_image($post_thumbnail_id, 'full'); // Get custom image
        } else {
            $post_thumbnail = has_post_thumbnail() ? get_the_post_thumbnail_url(get_the_ID(), 'full') : false; // Fallback to default thumbnail
        }

        // Handle "scopri" global option
        $scopri = get_option('bhwd_get_selected_page_slug', false);

        // Replace and normalize text
        $replace_city_name = slug_to_capitalized($bhwd_city);

        // Add page data to the array
        
        $page_data = array(
            'id'            => get_the_ID(),
            'title'         => get_the_title(),
			'scopri' 		=> !empty( get_post_meta(get_the_ID(), 'bhwd_scopri_page', true) ) ? get_permalink(get_post_meta(get_the_ID(), 'bhwd_scopri_page', true))  : "#",
            'content'       => $bhwd_content,       // Rendered Elementor content or regular content
            'select_city'   => $replace_city_name,         // Include the specific meta value        // Include the "scopri" value
            'contactForm'   => $formContent
        );

        // Handle cases and add to the correct category
        switch ($bhwd_city) {
            case "north-cities":
                $relationalMeta["northCites"][] = $page_data; // Append to north cities
                break;
            case "center-cities":
                $relationalMeta["centerCites"][] = $page_data; // Append to center cities
                break;
            case "south-cities":
                $relationalMeta["southCites"][] = $page_data; // Append to south cities
                break;
            case "aborad":
                $relationalMeta["aborad"][] = $page_data; // Append to abroad
                break;
            default:
                $relationalMeta["message"] = "Some pages don't belong to any showroom category.";
                break;
        }
    }

    wp_reset_postdata(); // Reset the global post data
} else {
    // No posts found
    $relationalMeta = array(
        "err"     => true,
        "message" => "No pages found in showroom.",
    );
}

    wp_send_json($relationalMeta);
    // wp_die();
    // return $pages_with_meta;
}


// Register AJAX actions
add_action('wp_ajax_bhwd_showroom_data_access', 'get_pages_with_elementor_content_and_meta');
add_action('wp_ajax_nopriv_bhwd_showroom_data_access', 'get_pages_with_elementor_content_and_meta');




/**
 * return page content or data 
 */

function bhwd_showroom_get_page_content($page_id) {
     $form_id = get_option('bhwd_showroom_add_short_code');
    $formContent = '';
	// Check if the form ID is valid and exists
	if ($form_id) {
		// Load the form by ID and display it using Contact Form 7 API
		$contact_form = wpcf7_contact_form( $form_id );
		if ($contact_form) {
			$formContent = $contact_form->form_html(); // Display the form HTML directly
		} else {
			$formContent = '<h4>Contact form not found. Please check your settings or contact us at <a href="mailto:' . esc_attr(get_option('bhwd_showroom_email', 'info@disegnarecasa.com')) . '"><strong>Email Us</strong></a></h4>';
		}
	} else {
		$formContent = '<h4>Contact form not selected. Please select a form in the settings.</h4>';
	}
    $data = array(
        
        'title' => get_the_title($page_id),
        'city' => slug_to_capitalized(get_post_meta($page_id, 'dise_city', true)),
        'scopri' => get_option('bhwd_get_selected_page_slug', false),
        'image' => wp_get_attachment_image_url(get_post_meta($page_id, '_thumbnail_id', true), 'full') , // Get the featured image URL
        
    );
    
    return $data;
}

// Register the shortcode
// add_shortcode('bhwdElementorShortCode', 'display_elementor_pages_with_meta');
function slug_to_capitalized($slug) {
    // Replace hyphens with spaces and convert to lowercase
    $text = str_replace('-', ' ', $slug);
    
    // Capitalize the first letter of each word
    $text = ucwords($text);
    
    return $text;
}

// Register AJAX actions
add_action('wp_ajax_bhwd_showroom_meta', 'get_current_post_meta');
add_action('wp_ajax_nopriv_bhwd_showroom_meta', 'get_current_post_meta');

function get_current_post_meta() {
    
    $args = array(
        'post_type'      => 'dise-showroom',
        'posts_per_page' => -1,
        'orderby'        => 'menu_order',
        'order'          => 'ASC',
        
    );
    
    $query = new WP_Query($args);
    if (!$query->have_posts()) {
        wp_send_json_error('No posts found.');
        return;
    }

    // Initialize an array to hold the meta data
    $meta_data = array();

    while ($query->have_posts()) {
        $query->the_post();
        $post_id = get_the_ID();

        $meta_data[$post_id] = array(
            'id' => $post_id,
            'title' => get_the_title($post_id),
            'city' => slug_to_capitalized(get_post_meta($post_id, 'dise_city', true)),

            'map' => get_post_meta($post_id, 'dise_map_link', true),
            "data_content" => get_post_meta($post_id, 'dise_data_content', true),
        );
    }
  

    if (empty($meta_data)) {
        wp_send_json_error('No meta data found.');
        return;
    }
   
    wp_send_json_success($meta_data);
}


function bhwd_showroom_section(){
    ob_start();
    ?>
    <div class="bhwd_MainCarousel" >
        <div class="bhwd_lazy_lopading">
            <div class="bhwd_lazy_title_block" >
            <span class="bhwd_lazy_title" ></span>
            </div>
        
            <div class="bhwd_lazy_grid"></div>
            <div class="bhwd_lazy_grid middle"></div>
            <div class="bhwd_lazy_grid"></div>
        </div>
    </div>
    <?php
    return ob_get_clean();
}
add_shortcode('bhwd_car', 'bhwd_showroom_section')

?>
