<?php 

function bhwd_954_enqueue_archive_page_script() {
    // Enqueue Bootstrap CSS from a CDN
    wp_enqueue_style('bhdcsfw-archive_page_style', plugin_dir_url(__FILE__) . 'assest/style.css', array(), '1.0.0' , 'all');

}
add_action( 'wp_enqueue_scripts', 'bhwd_954_enqueue_archive_page_script' );

function bhwd_customization_954($wp_customize) {
    // Add Archive Page section
    $wp_customize->add_section("bhwd_archive_page", array(
        'title'       => __('BHWD Archive Settings', 'mytheme'),
        'description' => __('Change settings for the Archive Page here', 'mytheme'),
    ));

    // Products per page setting and control
    $wp_customize->add_setting('bhwd_archive_page_product_per_page', array(
        'default'           => 24,
        'sanitize_callback' => 'absint',
    ));
    $wp_customize->add_control('bhwd_archive_page_product_per_page_control', array(
        'label'    => __('Products per Page', 'mytheme'),
        'type'     => 'number',
        'section'  => 'bhwd_archive_page',
        'settings' => 'bhwd_archive_page_product_per_page',
        'input_attrs' => array(
            'min'   => 6,
            'max'   => 99,
            'step'  => 3,
        ),
    ));

    // Columns per row setting and control (Desktop)
    $wp_customize->add_setting('bhwd_archive_page_product_columns', array(
        'default'           => 3,
        'sanitize_callback' => 'absint',
    ));
    $wp_customize->add_control('bhwd_archive_page_product_columns_control', array(
        'label'    => __('Columns per Row (Desktop)', 'mytheme'),
        'type'     => 'number',
        'section'  => 'bhwd_archive_page',
        'settings' => 'bhwd_archive_page_product_columns',
        'input_attrs' => array(
            'min'   => 1,
            'max'   => 5,
            'step'  => 1,
        ),
    ));

    // Columns per row setting and control (Mobile)
    $wp_customize->add_setting('bhwd_archive_page_product_columns_mobile', array(
        'default'           => 2,
        'sanitize_callback' => 'absint',
    ));
    $wp_customize->add_control('bhwd_archive_page_product_columns_mobile_control', array(
        'label'    => __('Columns per Row (Mobile)', 'mytheme'),
        'type'     => 'number',
        'section'  => 'bhwd_archive_page',
        'settings' => 'bhwd_archive_page_product_columns_mobile',
        'input_attrs' => array(
            'min'   => 1,
            'max'   => 5,
            'step'  => 1,
        ),
    ));

    // Font size settings (Desktop, Tablet, Mobile)
    $font_sizes = array(
        'desktop_title' => 'Desktop Title',
        'tablet_title'  => 'Tablet Title',
        'mobile_title'  => 'Mobile Title',
        'desktop_price' => 'Desktop Price',
        'tablet_price'  => 'Tablet Price',
        'mobile_price'  => 'Mobile Price',
    );
    foreach ($font_sizes as $key => $label) {
        $wp_customize->add_setting("bhwd_archive_{$key}_font_size", array(
            'default' => '0.9375rem',
        ));
        $wp_customize->add_control("bhwd_archive_{$key}_font_size_control", array(
            'label'    => __("$label Font Size", 'mytheme'),
            'type'     => 'text',
            'section'  => 'bhwd_archive_page',
            'settings' => "bhwd_archive_{$key}_font_size",
        ));
    }

    // Border radius for product setting and control
    $wp_customize->add_setting('bhwd_archive_product_border_radius', array(
        'default'           => 0,
        'sanitize_callback' => 'absint',
    ));
    $wp_customize->add_control('bhwd_archive_product_border_radius_control', array(
        'label'    => __('Product Border Radius (px)', 'mytheme'),
        'type'     => 'number',
        'section'  => 'bhwd_archive_page',
        'settings' => 'bhwd_archive_product_border_radius',
        'input_attrs' => array(
            'min'   => 0,
            'max'   => 50,
            'step'  => 1,
        ),
    ));

    //Color settings for title and price
    $wp_customize->add_setting('bhwd_archive_product_title_color', array(
        'default'=>'#000000',
         'sanitize_callback' => 'sanitize_hex_color', // Ensures a valid hex color is stored
    ));
    $wp_customize->add_control('bhwd_archive_product_title_color_control', array(
        'label'    => __('Product Title Color', 'mytheme'),
        'section'  => 'bhwd_archive_page',
        'settings' => 'bhwd_archive_product_title_color',
       
    ));

    $wp_customize->add_setting('bhwd_archive_product_price_color', array(
        'default'=>'#ff6363',
         'sanitize_callback' => 'sanitize_hex_color', // Ensures a valid hex color is stored
    ));
    $wp_customize->add_control('bhwd_archive_product_price_color_control', array(
        'label'    => __('Product Price Color', 'mytheme'),
        'section'  => 'bhwd_archive_page',
        'settings' => 'bhwd_archive_product_price_color',
    ));


    // Product Navigation Margin Top setting and control
    $wp_customize->add_setting('bhwd_archive_product_navigation', array(
        'default'           => 10,
        'sanitize_callback' => 'absint',
    ));
    $wp_customize->add_control('bhwd_archive_product_navigation_control', array(
        'label'    => __('Product Border Radius (px)', 'mytheme'),
        'type'     => 'number',
        'section'  => 'bhwd_archive_page',
        'settings' => 'bhwd_archive_product_navigation',
        'input_attrs' => array(
            'min'   => 0,
            'max'   => 100,
            'step'  => 1,
        ),
    ));
}
add_action('customize_register', 'bhwd_customization_954');




function bhwd_archive_page_style_code_return() {
    $columns = get_theme_mod('bhwd_archive_page_product_columns', 3); // Default to 3 columns
    $columns_mobile = get_theme_mod('bhwd_archive_page_product_columns_mobile', 2); // Default to 2 columns
    ?>
    <style>
        p.bhwd-product-title {
                font-size: <?php echo get_theme_mod('bhwd_archive_desktop_title_font_size' , '0.9374rem'); ?> !important;
                color: <?php echo get_theme_mod('bhwd_archive_product_title_color' , '#000');  ?> ;
            }
        p.bhwd-price{
                font-size: <?php echo get_theme_mod('bhwd_archive_desktop_price_font_size' , '0.9374rem'); ?> !important;
                color: <?php echo get_theme_mod('bhwd_archive_product_price_color' , '#ff6363');  ?> ;
            }
        .bhwd_product{
            border-radius: <?php echo get_theme_mod('bhwd_archive_mobile_price_border_radius' , 0); ?>px !important;
        }

        .bhwd_product img{
            border-radius: <?php echo get_theme_mod('bhwd_archive_mobile_price_border_radius' , 0); ?>px 0px !important;
        }

        ul.bhwd_product_navigation{
            margin-top: <?php echo get_theme_mod('bhwd_archive_product_navigation', 7); ?>px !important;
        }
        @media (max-width: 1080px) {
            .bhwd-products-container .row > div.col-md-4.bhwd_product {
                <?php 
                switch($columns) {
                    case 1:
                        echo 'width: 100% !important;';
                        break;
                    case 2:
                        echo 'width: 50% !important;';
                        break;
                    case 3:
                        echo 'width: 33.33% !important;';
                        break;
                    case 4:
                        echo 'width: 25% !important;';
                        break;
                    case 5:
                        echo 'width: 20% !important;';
                        break;
                    default:
                        echo 'width: 33.33% !important;';
                }
                ?>

            }
            p.bhwd-product-title {
                font-size: <?php echo get_theme_mod('bhwd_archive_tablet_title_font_size' , '0.9374rem'); ?> !important;
            }
            p.bhwd-price{
                font-size: <?php echo get_theme_mod('bhwd_archive_tablet_price_font_size' , '0.9374rem'); ?> !important;
            }
        }

        @media (max-width: 768px) {
            .bhwd-products-container .row > div.col-md-4.bhwd_product {
                <?php 
                switch($columns_mobile) {
                    case 1:
                        echo 'width: 100% !important;';
                        break;
                    case 2:
                        echo 'width: 50% !important;';
                        break;
                    case 3:
                        echo 'width: 33.33% !important;';
                        break;
                    case 4:
                        echo 'width: 25% !important;';
                        break;
                    case 5:
                        echo 'width: 20% !important;';
                        break;
                    default:
                        echo 'width: 25% !important;';
                }
                ?>
            }

            p.bhwd-product-title {
                font-size: <?php echo get_theme_mod('bhwd_archive_mobile_title_font_size' , '0.875rem'); ?> !important;
            }

            p.bhwd-price{
                font-size: <?php echo get_theme_mod('bhwd_archive_mobile_price_font_size' , '0.875rem'); ?> !important;
            }

        }
    </style>
    <?php
}
add_action('wp_head', 'bhwd_archive_page_style_code_return');


function bhwd_custom_product_archive_price_filter_shortcode($atts) {
    $posts_per_page = get_theme_mod('bhwd_archive_page_product_per_page', 24);

    // Set default shortcode attributes
    $atts = shortcode_atts(
        array(
            'posts_per_page' => $posts_per_page,
            'orderby'        => 'date',
            'order'          => 'DESC',
        ),
        $atts
    );

    // Get min and max price from URL
    $min_price = isset($_GET['min_price']) ? floatval($_GET['min_price']) : 0;
    $max_price = isset($_GET['max_price']) ? floatval($_GET['max_price']) : 999999;

    // Set up pagination
    $paged = (get_query_var('paged')) ? get_query_var('paged') : 1;

    // Query arguments for products
    $args = array(
        'post_type'      => 'product',
        'posts_per_page' => $atts['posts_per_page'],
        'orderby'        => $atts['orderby'],
        'order'          => $atts['order'],
        'paged'          => $paged,
        'meta_query'     => array(
            array(
                'key'     => '_price',
                'value'   => array($min_price, $max_price),
                'compare' => 'BETWEEN',
                'type'    => 'NUMERIC',
            ),
        ),
    );

    // Filter by category if on a category page
    if (is_product_category()) {
        $current_category = get_queried_object();
        $args['tax_query'] = array(
            array(
                'taxonomy' => 'product_cat',
                'field'    => 'term_id',
                'terms'    => $current_category->term_id,
            ),
        );
    }

    // Query for products
    $query = new WP_Query($args);

    echo '<div class="container-fluid bhwd-products-container m-0 p-0"><div class="row">';

    if ($query->have_posts()) {
        // Display products if found
        while ($query->have_posts()) {
            $query->the_post();
            $product_id = get_the_ID();
            $product_image_url = wp_get_attachment_url(get_post_thumbnail_id($product_id)) ?: wc_placeholder_img_src();
            ?>
            <div class="col-md-4 bhwd_product my-2">
                <a class="text-decoration-none bhwd_product_container bhwd_hegth100" href="<?php the_permalink(); ?>">
                    <div class="card border-0">
                        <img class="bhwd_product_custom_image_size card-img-top" src="<?php echo esc_url($product_image_url); ?>" alt="<?php the_title(); ?>">
                        <div class="card-body">
                            <p class="card-title bhwd-product-title my-1"><?php the_title(); ?></p>
                            <p class="card-title bhwd-price my-1"><?php echo wc_price(get_post_meta($product_id, '_price', true)); ?></p>
                            <p class="card-text text-dark"><?php echo wp_trim_words(get_the_excerpt(), 15); ?></p>
                        </div>
                    </div>
                </a>
            </div>
            <?php
        }
    }

//     echo '</div></div>';

    // Reset product data
    wp_reset_postdata();

    // Display subcategories if available
    if ($current_category && isset($current_category->term_id)) {
        $subcategories = get_terms(array(
            'taxonomy'   => 'product_cat',
            'child_of'   => $current_category->term_id,
            'hide_empty' => false,
        ));

        if (!empty($subcategories)) {
//             echo '<div class="container-fluid bhwd-subcategories-container m-0 p-0"><div class="row">';

            foreach ($subcategories as $subcategory) {
                $thumbnail_id = get_term_meta($subcategory->term_id, 'thumbnail_id', true);
                $subcategory_image_url = wp_get_attachment_url($thumbnail_id) ?: wc_placeholder_img_src();
                ?>
                <div class="col-md-4 bhwd_product my-2">
                    <a class="text-decoration-none bhwd_product_container bhwd_hegth100" href="<?php echo get_term_link($subcategory->term_id, 'product_cat'); ?>">
                        <div class="card border-0">
                            <img class="bhwd_product_custom_image_size card-img-top" src="<?php echo esc_url($subcategory_image_url); ?>" alt="<?php echo esc_attr($subcategory->name); ?>">
                            <div class="card-body">
                                <p class="card-title bhwd-product-title my-1"><?php echo esc_html($subcategory->name); ?></p>
                                <p class="card-text text-dark"><?php echo wp_trim_words(esc_html($subcategory->description), 15); ?></p>
                            </div>
                        </div>
                    </a>
                </div>
                <?php
            }
            echo '</div></div>';
        }
    }

    // Pagination for products
    if ($query->max_num_pages > 1) {
        echo '<nav aria-label="Page navigation">';
        echo paginate_links(array(
            'total'   => $query->max_num_pages,
            'current' => $paged,
            'format'  => '?paged=%#%',
        ));
        echo '</nav>';
    }

    echo '</div>'; // Closing main container
}

add_shortcode('bhwd_price_filter', 'bhwd_custom_product_archive_price_filter_shortcode');