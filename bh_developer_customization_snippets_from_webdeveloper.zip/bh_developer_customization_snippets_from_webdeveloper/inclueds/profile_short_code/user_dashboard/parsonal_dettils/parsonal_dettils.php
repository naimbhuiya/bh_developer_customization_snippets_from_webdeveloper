<?php
// Use global to access the $current_user variable
function bhdcsfw_enqueue_styles_scripts_parsonal_dettils() {
    // Styles
    wp_enqueue_style('bhdcsfw-style-parsonal_dettils', plugin_dir_url(__FILE__) . 'asset/style.css', array(), '1.0.0', 'all');

    // Scripts
    wp_enqueue_script('bhdcsfw-script-parsonal_dettils', plugin_dir_url(__FILE__) . 'asset/script.js', array('jquery'), '1.0.0', true);
}
add_action('wp_enqueue_scripts', 'bhdcsfw_enqueue_styles_scripts_parsonal_dettils');

function isCheckWhatIsInformation($info_data, $current_user) {
    $bhdcsfw_userName = esc_attr($current_user->user_login);
    $bhdcsfw_userDisplayName = esc_attr($current_user->display_name);
    $bhdcsfw_userId = esc_attr($current_user->ID);
    $bhdcsfw_userEmail = esc_attr($current_user->user_email);
    $bhdcsfw_userUrl = esc_attr($current_user->user_url);

    if ($info_data ===  $bhdcsfw_userDisplayName) {
        echo "Name: ";
    } elseif ($info_data === $bhdcsfw_userName) {
        echo 'User Name: ';
    } elseif ($info_data === $bhdcsfw_userId) {
        echo 'User Id: ';
    } elseif ($info_data === $bhdcsfw_userEmail) {
        echo 'User Email: ';
    } elseif ($info_data === $bhdcsfw_userUrl) {
        echo 'User Url: ';
    }
}
function bhdcsfw_profile_shortcode() {
    // Retrieve the current user
    $current_user = wp_get_current_user();
    if ($current_user->ID !== 0) {
        ?>
        <div class="bhdcsfw_user_information_container container-fluid p-0" id="bhdcsfw_user_information_container_selection">
            <div class="row mb-3 p-0">
                <div class="col d-flex justify-content-start align-items-center p-0">
                    <span class="bhdcsfw_icon_style text-light bg-dark rounded mr-3 p-2">
                        <i class="fa fa-info" aria-hidden="true"></i>
                    </span>
                    <span>Personal Information</span>
                </div>
                <div class="col d-flex justify-content-end p-0">
                    <button type="button" class="btn btn-info">
                        <span class="bhdcsfw_icon_style p-2">
                            Edit <i class="fa-solid fa-ellipsis-vertical"></i>
                        </span>
                    </button>
                </div>
            </div>
        <?php // Access PHP data using bhdcsfw_user_data variable
        $bhdcsfw_user_information_array = array(
            esc_attr($current_user->display_name),
            esc_attr($current_user->user_login),
            esc_attr($current_user->ID),
            esc_attr($current_user->user_email),
            esc_attr($current_user->user_url)
        );
        $count = 0;
        foreach ($bhdcsfw_user_information_array as $data) {
            $count++;
            $isCheck_bhdcsfw_OddEven = ($count % 2 === 0) ? 'bg-light' : 'Odd'; ?>
            <div class="row rounded p-2 <?php echo $isCheck_bhdcsfw_OddEven; ?>">
                <div class="col"><?php isCheckWhatIsInformation($data, $current_user); ?></div>
                <div class="col"><?php echo $data; ?></div>
            </div>
            <?php } ?>
     </div>
     <?php
    } else {
        // User is not logged in
        echo 'User not logged in.';
    }
}
// Register the shortcode
add_shortcode('bhdcsfw_profile_page', 'bhdcsfw_profile_shortcode');