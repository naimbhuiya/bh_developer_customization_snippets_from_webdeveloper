// // Access PHP data using bhdcsfw_user_data variable
// let bhdcsfw_userName = bhdcsfw_user_data.userDisplayName;
// let bhdcsfw_userDisplayName = bhdcsfw_user_data.userName;
// let bhdcsfw_userId = bhdcsfw_user_data.userId;
// let bhdcsfw_userEmail = bhdcsfw_user_data.userEmail;
// let bhdcsfw_userUrl = bhdcsfw_user_data.userUrl; 
// console.log(bhdcsfw_userDisplayName);
// // Your script logic here

// let bhdcsfw_user_information_arry = [
//     bhdcsfw_userDisplayName,
//     bhdcsfw_userName,
//     bhdcsfw_userId,
//     bhdcsfw_userEmail,
//     bhdcsfw_userUrl
// ];

// let bhdcsfw_user_information_container_selection = document.getElementById("bhdcsfw_user_information_container_selection");

// // Odd Even 
// let isCheck_bhdcsfw_OddEven;
// let bhdcsfw_displayUserConditionTitle;
// function isCheckWhatIsInformation(info_data) {
//     if (info_data === bhdcsfw_userDisplayName) {
//         bhdcsfw_displayUserConditionTitle = "Nick Name: ";
//     } else if (info_data === bhdcsfw_userName) {
//         bhdcsfw_displayUserConditionTitle = "User Name: ";
//     } else if (info_data === bhdcsfw_userId) {
//         bhdcsfw_displayUserConditionTitle = "User Id: ";
//     } else if (info_data === bhdcsfw_userEmail) {
//         bhdcsfw_displayUserConditionTitle = "User Email: ";
//     } else if (info_data === bhdcsfw_userURL) {
//         bhdcsfw_displayUserConditionTitle = "User URL: ";
//     }
// }
// bhdcsfw_user_information_arry.forEach((data, index) => {
//     if (index % 2 === 0) {
//         isCheck_bhdcsfw_OddEven = "bg-light ";
//     } else {
//         isCheck_bhdcsfw_OddEven = "Odd ";
//     }
//     isCheckWhatIsInformation(data)
//     let bhdcsfw_information_list = document.createElement("div");
//     bhdcsfw_information_list.className = `row rounded p-2 ${isCheck_bhdcsfw_OddEven}`;
//     bhdcsfw_information_list.innerHTML = `<div class="col">${bhdcsfw_displayUserConditionTitle}</div><div class="col">${data}</div>`;
//     bhdcsfw_user_information_container_selection.appendChild(bhdcsfw_information_list)
//     console.log(`Your Variable id ${index} : information : ${data}`);
// });

