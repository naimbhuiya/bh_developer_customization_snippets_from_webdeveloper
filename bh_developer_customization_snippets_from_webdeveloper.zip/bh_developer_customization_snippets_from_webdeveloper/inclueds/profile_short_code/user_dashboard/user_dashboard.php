<?php
/**
 * inclueds user dashboard files
 */
 // inclueds parsonal Dettils file inclueds
 require_once(plugin_dir_path(__FILE__) . 'parsonal_dettils/parsonal_dettils.php');
 require_once(plugin_dir_path(__FILE__) . 'user_adress/user_adress.php');