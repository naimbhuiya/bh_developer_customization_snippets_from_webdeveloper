function bhwdValidElement(element) {
  let isValidElement = document.querySelector(element);
  if (isValidElement) {
    return isValidElement;
  }
  return false;
}
// switcher function
let bhwdSwitchCountry = bhwdValidElement("#bhwd_switch_country");
let bhwdSwitchLg = bhwdValidElement("#bhwd_switch_lg");
let bhwdSwitcher = bhwdValidElement("#bhwdSwitcher");
let bhwdSwitchCurrenchy = bhwdValidElement("#bhwd_switch_currenchy");
let bhwdActiveDeactiveTranslatePopup = document.querySelectorAll(
  ".bhwd-Active-deactive-translate-popup"
);
let bhwd_translator_conatiner_main = bhwdValidElement(
  ".bhwd_translator_conatiner_main"
);
let bhwdTranslateButton = bhwdValidElement(".bhwdTranslateButton");

// Get and check stored cookie values
let countryCode = getCookie("country_code") || false;
let countryName = getCookie("country_name") || false;
let languageCode = getCookie("language_code") || false;
let languageName = getCookie("language_name") || false;
let bhwd_currency_symbole = getCookie("bhwd_currency_symbole") || false;
/**
 * if switch language then i need change data from button
 */
function bhwdChangeDataFromButton() {
  bhwdTranslateButton.innerHTML = `<span><img src="https://flagcdn.com/16x12/${countryCode ? countryCode : 'it'}.png" alt=""></span><span>${countryName ? countryName : 'Italy'} / ${languageCode ? languageCode : 'it'}  ( ${
    bhwd_currency_symbole ? bhwd_currency_symbole : "€"
  } )</span>`;
}

// Load Google Translate script
let isBhwdCheckLanguage = null;
let scriptAddGoogleTranslateElement = document.createElement("script");
scriptAddGoogleTranslateElement.src =
  "https://translate.google.com/translate_a/element.js?cb=googleTranslateElementInit";
scriptAddGoogleTranslateElement.type = "text/javascript";
document.body.appendChild(scriptAddGoogleTranslateElement);

// console.log("Worked Code... 0");

/**
 * Defandancy Functions
 * ############################################################################
 * ############################################################################
 */

/**
 * Handle check stored data if action to saved data in cookies
 */

function bhwdCheckDataStoreOnCookies(element, cCode, cName) {
  if (cCode && cName) {
    // Check if the countryCode exists in the dropdown options
    let optionExists = Array.from(element.options).some(
      (option) => option.value === cCode
    );

    if (optionExists) {
      // If the option exists, set it as the selected value
      element.value = cCode;
      // console.log(`Selected stored country: ${cName} (${cCode})`);
    } else {
      // If the option doesn't exist, create and append a new option
      let newOption = document.createElement("option");
      newOption.value = cCode;
      newOption.innerText = cName;
      element.appendChild(newOption);

      // Set the newly added option as the selected value
      element.value = cCode;
      // console.log(`Appended and selected new country: ${cName} (${cCode})`);
    }
  } else {
    errorThrowForDeveloper([element, cCode, cName]);
  }
}

/** 
// Function to translate the page
*/
function translatePage(language, data) {
  // Google translate Element Catch
  let googleTranslateElement = document.querySelector(".goog-te-combo");
  if (googleTranslateElement) {
    googleTranslateElement.value = language;
    googleTranslateElement.dispatchEvent(new Event("change"));

    // Store selected country code and name in cookies
    setCookie("country_code", data["countryCodes"], 30);
    setCookie("country_name", data["countryName"], 30);
    // Store language code and language name in cookies
    setCookie("language_code", data["languageCode"], 30);
    setCookie("language_name", data["languageName"], 30);
  } else {
    console.error(googleTranslateElement);
  }
}

/**
 * Append options Depandancy
 */

function bhwdAppendOptions(parentElement, data, favItem) {
  let optionElemnt = document.createElement("option");
  optionElemnt.value = data["optionValue"];
  optionElemnt.innerText = data["optionTextContent"];
  if (data["optionAttributes"]) {
    for (const [attrName, attrValue] of Object.entries(
      data["optionAttributes"]
    )) {
      optionElemnt.setAttribute(attrName.toLowerCase(), attrValue);
    }
  }
  if (data["optionValue"] !== favItem) {
    parentElement.appendChild(optionElemnt);
  } else {
    // parentElement.pre
    parentElement.prepend(optionElemnt);
    parentElement.value = data["optionValue"];
  }
}

/**
 * Err Throw For Help Developer
 */
function errorThrowForDeveloper(err) {
  let errors = "";
  err.forEach((value, i) => {
    if (err) {
      errors =
        i !== err.length && i != 0
          ? `${value} ${i - 1 !== err.length ? "," : "or"}`
          : errors + ".";
    }
  });

  console.error(`We have error one ${errors}`);
}

// Function to get the attribute of the selected option
function getSelectedOptionAttribute(selectElement, attributeName) {
  if (selectElement.options[selectElement.selectedIndex]) {
    return selectElement.options[selectElement.selectedIndex].getAttribute(
      attributeName
    );
  }
  return null;
}

/**
 * Create a set cookie function
 */
function setCookie(cname, cvalue, exdays) {
  const d = new Date();
  d.setTime(d.getTime() + exdays * 24 * 60 * 60 * 1000);
  let expires = "expires=" + d.toUTCString();
  document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
}

/**
 * Create a get cookie function
 */
function getCookie(cname) {
  let name = cname + "=";
  let ca = document.cookie.split(";");
  for (let i = 0; i < ca.length; i++) {
    let c = ca[i];
    while (c.charAt(0) == " ") {
      c = c.substring(1);
    }
    if (c.indexOf(name) == 0) {
      return c.substring(name.length, c.length);
    }
  }
  return "";
}

//####################################  END DEFANDANCY  #######################################

// Initialize Google Translate
function googleTranslateElementInit() {
  new google.translate.TranslateElement(
    { pageLanguage: "it" },
    "google_translate_element"
  );
}
// console.log("Worked Code... 1");

let translatetorSection_954 = document.querySelector(
  ".translatetorSection_954"
);

async function bhwdFetcCountryAndLanguageJson() {
  try {
    const bhwdRequestURL = `${bhwdSwContact.pluginPathUri}assets/lg.json`;
    const bhwdRequest = new Request(bhwdRequestURL);
    // console.log(bhwdRequestURL);

    const bhwdResponse = await fetch(bhwdRequest);
    const bhwdLanguageJson = await bhwdResponse.json();

    // console.log(bhwdLanguageJson);

    // console.log("Languages fetched:", bhwdLanguageJson);
    bhwdCountrySwitcherFunc(bhwdLanguageJson);

    checkThenFinishedRequesting();
  } catch (error) {
    console.error("Error fetching language data:", error);
  }
}

/**
 *
 * @param {*} lg
 * Country Switcher Function For Desktop
 * Called function on in this function: bhwdForEachAllLG
 */
function bhwdCountrySwitcherFunc(lg) {
  // console.log(lg);
  if (document.getElementById("allCountries")) {
    let allCountries = document.getElementById("allCountries");
    let languageTranslate = document.getElementById("languageTranslate");

    // Initialize the language display with cookie data if available
    if (countryCode && languageName) {
      languageTranslate.innerHTML = `
        <span>
          <span class="country_images">
            <img src="https://flagcdn.com/16x12/${countryCode}.png" />
          </span>
          <span class="coutriesLanguage">${
            languageName ? languageName : "Italian"
          }</span>
        </span>`;
    }

    bhwdForEachAllLG(lg, allCountries, languageTranslate);
  } else {
    bhwdForEachAllLG(lg, false, false);
    console.log(
      "You do not have the required DOM structure for this functionality."
    );
  }
}

// Iterate through all languages and handle duplicates
/**
 *
 * @param {*} lg
 * bhwdForEachAllLG:
 * Description: this function work on check devide uniq language From our custom language and country json file
 * Called function on in this function: translatePage , switcherFunction [ 2 times ], errorThrowForDeveloper
 */
function bhwdForEachAllLG(all_Language, allCountries, languageTranslate) {
  const uniqueLanguages = new Set();
  if (all_Language) {
    all_Language.forEach((data) => {
      if (!uniqueLanguages.has(data.languageName)) {
        uniqueLanguages.add(data.languageName);

        if (allCountries) {
          let all_countries_list = document.createElement("li");
          all_countries_list.className = `countries_list_items`;

          // Create HTML for the country and language display
          let translateCountryVr = `
          <span>
            <span class="country_images">
              <img src="https://flagcdn.com/16x12/${data.code}.png" />
            </span>
            <span class="coutriesLanguage">${data.languageName}</span>
          </span>
          `;

          all_countries_list.addEventListener("click", () => {
            translatePage(data.languageCode, {
              countryCodes: data.code,
              countryName: data.languageName,
            });
            languageTranslate.innerHTML = translateCountryVr; // Update the language display
          });

          all_countries_list.innerHTML = translateCountryVr;

          allCountries.appendChild(all_countries_list);
        }

        isBhwdCheckLanguage = true;
        // console.log(data);

        switcherFunction(data, bhwdSwitchLg, isBhwdCheckLanguage);
      }

      // console.log(data);

      // Handle language for mobile switcher
      isBhwdCheckLanguage = false;
      switcherFunction(data, bhwdSwitchCountry, isBhwdCheckLanguage);
    });
  } else {
    errorThrowForDeveloper([all_Language, allCountries, languageTranslate]);
  }
}
window.addEventListener("load", () => {
  if (languageCode) {
    let bhwdGoogleTranslateElement = document.querySelector(".goog-te-combo");
    if (bhwdGoogleTranslateElement) {
      bhwdGoogleTranslateElement.value = languageCode;
      bhwdGoogleTranslateElement.dispatchEvent(new Event("change"));
    }
  }
});

/**
 *  If user set data in cookies, change the page on loading
 */

// Call the populate function

//  Switcher Country function
/**
 *
 * @param {*} lg
 * bhwdForEachAllLG:
 * Description: this function work on only add options in select field
 * Called function on in this function: errorThrowForDeveloper
 */
let bhwdData = {};
function switcherFunction(data, element, check) {
  if (element) {
    let bhwdOption = document.createElement("option");

    let bhwdCheckedData;
    if (check) {
      bhwdData = {
        name: data.languageName,
        code: data.languageCode,
      };
      bhwdCheckedData = bhwdData;
    } else {
      bhwdCheckedData = {
        name: data.countries,
        code: data.code,
      };
    }
    bhwdOption.setAttribute("opname", bhwdCheckedData.name);
    bhwdOption.value = bhwdCheckedData.code;
    bhwdOption.innerText = bhwdCheckedData.name;
    element.appendChild(bhwdOption);
  } else {
    errorThrowForDeveloper([element, data, check]);
  }
}

/**
 * Handle check then finished request called API
 */
function checkThenFinishedRequesting() {
  bhwdCheckDataStoreOnCookies(bhwdSwitchCountry, countryCode, countryName);
  bhwdCheckDataStoreOnCookies(bhwdSwitchLg, languageCode, languageName);
}

/**
 * Fetc Mony Api
 */
let bhwdRealeTimeMonyExchangeRateData = {};
const currencySymbols = {
  EUR: "€",
  USD: "$",
  GBP: "£",
  JPY: "¥",
  CNY: "¥",
  INR: "₹",
  BDT: "৳",
  CAD: "$",
  AUD: "$",
  CHF: "CHF",
  SEK: "kr",
  NOK: "kr",
  RUB: "₽",
  AED: "د.إ",
  SAR: "﷼",
  KWD: "د.ك",
  OMR: "ر.ع",
  QAR: "ر.ق",
  MXN: "MX$",
  BRL: "R$",
  ZAR: "R",
  ARS: "ARS$",
  PLN: "zł",
  DKK: "kr",
};
async function bhwdRealTimeMonyExchangeRates() {
  let bhwdRequestApi = `https://api.exchangerate-api.com/v4/latest/${bhwdSwContact.checkCurrency}`;
  let bhwdCheckTheFavCurrency = getCookie("bhwd_currency")
    ? getCookie("bhwd_currency")
    : "EUR";
  try {
    let response = await fetch(bhwdRequestApi);

    if (!response.ok) {
      throw new Error(response.status);
    }
    bhwdRealeTimeMonyExchangeRateData = await response.json();
    let bhwdCurrencyExchangeRate = bhwdRealeTimeMonyExchangeRateData.rates;

    for (const [currency, exchangeRate] of Object.entries(
      bhwdCurrencyExchangeRate
    )) {
      if (currencySymbols[currency]) {
        bhwdAppendOptions(
          bhwdSwitchCurrenchy,
          {
            optionValue: currency,
            optionTextContent: `${currency} ${
              currencySymbols[currency] !== currency
                ? `${currencySymbols[currency]} `
                : ""
            }`,
            optionAttributes: {
              currencySymbole: currencySymbols[currency],
              xchangeRate: exchangeRate,
            },
          },
          bhwdCheckTheFavCurrency
        );
      }
    }
    // console.log(bhwdRealeTimeMonyExchangeRateData.rates);
  } catch (error) {}
}

/**
 * Switch button function
 */
function bhwdSwitchButtonWorkFunction() {
  if (bhwdSwitcher) {
    bhwdSwitcher.addEventListener("click", () => {
      let countryName = getSelectedOptionAttribute(bhwdSwitchCountry, "opname");

      let currentOptionLanguageName = getSelectedOptionAttribute(
        bhwdSwitchLg,
        "opname"
      );
      let bhwdSwCurrencyValue = bhwdSwitchCurrenchy.value;
      console.log(
        bhwdSwitchCountry.value
          ? `Success: Switch Country Element Has Find ${bhwdSwitchCountry.value}`
          : `Err: Switch Country Element Has Not Find .....${bhwdSwitchCountry}`
      );
      translatePage(bhwdSwitchLg.value, {
        countryCodes: bhwdSwitchCountry.value,
        countryName: countryName,
        languageCode: bhwdSwitchLg.value,
        languageName: currentOptionLanguageName,
      });

      let currencySymbole = getSelectedOptionAttribute(
        bhwdSwitchCurrenchy,
        "currencysymbole"
      );
      let exchangeRate = getSelectedOptionAttribute(
        bhwdSwitchCurrenchy,
        "xchangerate"
      );

      setCookie("bhwd_currency", bhwdSwCurrencyValue, 30);
      setCookie("bhwd_currency_symbole", currencySymbole, 30);
      setCookie("bhwd_exchange_rate", exchangeRate, 30);
      bhwdChangeDataFromButton();
    });
  }
}

/**
 * Call main Function
 */

function bhwdOnladFunction() {
  bhwdSwitchButtonWorkFunction();
  bhwdFetcCountryAndLanguageJson();
  bhwdRealTimeMonyExchangeRates();
  bhwdChangeDataFromButton();
}
bhwdChangeDataFromButton();
bhwdActiveDeactiveTranslatePopup.forEach((element, i) => {
  element.addEventListener("click", () => {
    bhwdOnladFunction();
    bhwd_translator_conatiner_main.classList.toggle("active");
  });
});
