// switcher function
let bhwdSwitchCountry = document.getElementById("bhwd_switch_country");
let bhwdSwitchLg = document.getElementById("bhwd_switch_lg");
let bhwdSwitcher = document.getElementById("bhwdSwitcher");
let bhwdSwitchCurrenchy = document.getElementById("bhwd_switch_currenchy");

// get and Check Session Stored item value
let countryCode = sessionStorage.getItem("country_code")
  ? sessionStorage.getItem("country_code")
  : false;
let countryName = sessionStorage.getItem("country_name")
  ? sessionStorage.getItem("country_name")
  : false;
let languageCode = sessionStorage.getItem("language_code")
  ? sessionStorage.getItem("language_code")
  : false;
let languageName = sessionStorage.getItem("language_name")
  ? sessionStorage.getItem("language_name")
  : false;

// Load Google Translate script
let isBhwdCheckLanguage = null;
let scriptAddGoogleTranslateElement = document.createElement("script");
scriptAddGoogleTranslateElement.src =
  "https://translate.google.com/translate_a/element.js?cb=googleTranslateElementInit";
scriptAddGoogleTranslateElement.type = "text/javascript";
document.body.appendChild(scriptAddGoogleTranslateElement);

console.log("Worked Code... 0");

// Initialize Google Translate
function googleTranslateElementInit() {
  new google.translate.TranslateElement(
    { pageLanguage: "it" },
    "google_translate_element"
  );
}
console.log("Worked Code... 1");

let translatetorSection_954 = document.querySelector(
  ".translatetorSection_954"
);

async function populate() {
  try {
    const bhwdRequestURL = `${translatetorSection_954.getAttribute(
      "filepath"
    )}assets/lg.json`;
    const bhwdRequest = new Request(bhwdRequestURL);

    const bhwdResponse = await fetch(bhwdRequest);
    const bhwdLanguageJson = await bhwdResponse.json();

    console.log("Languages fetched:", bhwdLanguageJson);
    bhwdCountrySwitcherFunc(bhwdLanguageJson);

    checkThenFinisedRequesting();
  } catch (error) {
    console.error("Error fetching language data:", error);
  }
}

function bhwdCountrySwitcherFunc(lg) {
  if (document.getElementById("allCountries")) {
    let allCountries = document.getElementById("allCountries");
    let languageTranslate = document.getElementById("languageTranslate");

    // Initialize the language display with session storage data if available
    let storedCountryCode = sessionStorage.getItem("country_code");
    let storedCountryName = sessionStorage.getItem("country_name");

    if (storedCountryCode && languageName) {
      languageTranslate.innerHTML = `
        <span>
          <span class="country_images">
            <img src="https://flagcdn.com/16x12/${storedCountryCode}.png" />
          </span>
          <span class="coutriesLanguage">${
            languageName ? languageName : "Italian"
          }</span>
        </span>`;
    }

    bhwdForEachAllLG(lg, allCountries, languageTranslate);
  } else {
    console.log(
      "You do not have the required DOM structure for this functionality."
    );
  }
}

// Iterate through all languages and handle duplicates
function bhwdForEachAllLG(all_Language, allCountries, languageTranslate) {
  const uniqueLanguages = new Set();

  all_Language.forEach((data) => {
    if (!uniqueLanguages.has(data.languageName)) {
      uniqueLanguages.add(data.languageName);

      let all_countries_list = document.createElement("li");
      all_countries_list.className = `countries_list_items`;

      // Create HTML for the country and language display
      let translateCountryVr = `
        <span>
          <span class="country_images">
            <img src="https://flagcdn.com/16x12/${data.code}.png" />
          </span>
          <span class="coutriesLanguage">${data.languageName}</span>
        </span>
        `;

      all_countries_list.addEventListener("click", () => {
        translatePage(data.languageCode, {
          countryCodes: data.code,
          countryName: data.languageName,
        });
        languageTranslate.innerHTML = translateCountryVr; // Update the language display
      });

      all_countries_list.innerHTML = translateCountryVr;
      allCountries.appendChild(all_countries_list);
      isBhwdCheckLanguage = true;
      switcherFunction(data, bhwdSwitchLg, isBhwdCheckLanguage);
    }

    // all language for mobile switcher
    isBhwdCheckLanguage = false;
    switcherFunction(data, bhwdSwitchCountry, isBhwdCheckLanguage);

    //
  });
}

// Function to translate the page
function translatePage(language, data) {
  // Google translate Element Catch
  let googleTranslateElement = document.querySelector(".goog-te-combo");
  if (googleTranslateElement) {
    googleTranslateElement.value = language;
    googleTranslateElement.dispatchEvent(new Event("change"));

    // Store selected country code and name in session storage
    sessionStorage.setItem("country_code", data["countryCodes"]);
    sessionStorage.setItem("country_name", data["countryName"]);
    // Store Language Code And Language Name
    sessionStorage.setItem("language_code", data["languageCode"]);
    sessionStorage.setItem("language_name", data["languageName"]);
  }
}

/**
 *  If user set data on session Storage Loading Time Change Translate page
 */

// Call the populate function
populate();

//  Switcher Country function
let bhwdData = {};
function switcherFunction(data, element, check) {
  let bhwdOption = document.createElement("option");

  let bhwdCheckedData;
  if (check) {
    bhwdData = {
      name: data.languageName,
      code: data.languageCode,
    };
    bhwdCheckedData = bhwdData;
  } else {
    bhwdCheckedData = {
      name: data.countries,
      code: data.code,
    };
  }
  bhwdOption.setAttribute("opname", bhwdCheckedData.name);
  bhwdOption.value = bhwdCheckedData.code;
  bhwdOption.innerText = bhwdCheckedData.name;

  element.appendChild(bhwdOption);
}

/**
 * Handle Check Stored Data if action to saved data on seesion Storage
 */

function bhwdCheckDataStoreOnSessionStorage(element, cCode, cName) {
  if (cCode && cName) {
    // Check if the countryCode exists in the dropdown options
    let optionExists = Array.from(element.options).some(
      (option) => option.value === cCode
    );

    if (optionExists) {
      // If the option exists, set it as the selected value
      element.value = cCode;
      console.log(`Selected stored country: ${cName} (${cCode})`);
    } else {
      // If the option doesn't exist, create and append a new option
      let newOption = document.createElement("option");
      newOption.value = cCode;
      newOption.innerText = cName;
      element.appendChild(newOption);

      // Set the newly added option as the selected value
      element.value = cCode;
      console.log(`Appended and selected new country: ${cName} (${cCode})`);
    }
  } else {
    console.log("No country data found in session storage.");
  }
}

/**
 * Hndle Check Then Fhinised Request Called API
 */
function checkThenFinisedRequesting() {
  bhwdCheckDataStoreOnSessionStorage(
    bhwdSwitchCountry,
    countryCode,
    countryName
  );
  bhwdCheckDataStoreOnSessionStorage(bhwdSwitchLg, languageCode, languageName);
}

bhwdSwitcher.addEventListener("click", () => {
  let countryName = getSelectedOptionAttribute(bhwdSwitchCountry, "opname");

  let currentOptionLanguageName = getSelectedOptionAttribute(
    bhwdSwitchLg,
    "opname"
  );
  let bhwdSwCurrencyValue = bhwdSwitchCurrenchy.value;
  // console.log(bhwdSwitchLg.option[bhwdSwitchLg.selectedIndex].value);
  translatePage(bhwdSwitchLg.value, {
    countryCodes: bhwdSwitchCountry.value,
    countryName: countryName,
    languageCode: bhwdSwitchLg.value,
    languageName: currentOptionLanguageName,
  });
  setCookie("bhwd_currency", bhwdSwCurrencyValue, 30);
});

// Function to get the attribute of the selected option
function getSelectedOptionAttribute(selectElement, attributeName) {
  // Check if a selected option exists
  if (selectElement.options[selectElement.selectedIndex]) {
    // Get the attribute value from the selected option
    return selectElement.options[selectElement.selectedIndex].getAttribute(
      attributeName
    );
  }
  return null; // Return null if no option is selected
}

/**
 * Create a set cookie Function
 */

function setCookie(cname, cvalue, exdays) {
  const d = new Date();
  d.setTime(d.getTime() + exdays * 24 * 60 * 60 * 1000);
  let expires = "expires=" + d.toUTCString();
  document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
}

/**
 * Create Get Cookies Function
 */

function getCookie(cname) {
  let name = cname + "=";
  let ca = document.cookie.split(";");
  for (let i = 0; i < ca.length; i++) {
    let c = ca[i];
    while (c.charAt(0) == " ") {
      c = c.substring(1);
    }
    if (c.indexOf(name) == 0) {
      return c.substring(name.length, c.length);
    }
  }
  return "";
}
// if On bhwdSwitcher button then called action on ajax
