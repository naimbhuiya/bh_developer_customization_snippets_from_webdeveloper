<?php
// Enqueue styles and scripts
function translator_enqueue_assets() {
    wp_enqueue_style(
        'bhdcsfw-style-translator',
        plugin_dir_url(__FILE__) . 'assets/style.css',
        [],
        '1.0.0',
        'all'
    );

    wp_enqueue_script(
        'bhdcsfw-script-translator',
        plugin_dir_url(__FILE__) . 'assets/script.js',
        [],
        '1.0.0',
        true
    );
    wp_enqueue_script( 'jquery' );

  wp_localize_script( 'bhdcsfw-script-translator', 'bhwdSwContact', array(
    'checkCurrency' => get_option('woocommerce_currency'),
    'pluginPathUri' =>  plugin_dir_url(__FILE__) ,
    // 'otherParam' => 'some value',
) );
}
add_action('wp_enqueue_scripts', 'translator_enqueue_assets');


require_once(plugin_dir_path(__FILE__) . 'switchcurrenchy.php');

function prepend_element_to_footer() {
    echo '<div id="google_translate_element"></div>';
}
add_action('wp_footer', 'prepend_element_to_footer');
// Translator shortcode function
function translator_shortcode() {
    ob_start(); // Start output buffering
    ?>
    <!-- <script src="https://translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script> -->
    <!-- <div id="google_translate_element"></div> -->
    <div  filepath="<?php echo plugin_dir_url(__FILE__) ; ?>" class="translatetorSection_954">
        <div id="languageTranslate" translate="no">
            <span>
                <span class="country_images">
                    <img src="https://flagcdn.com/16x12/it.png" alt="Italian Flag" />
                </span>
                <span class="coutriesLanguage">Italian</span>
            </span>
        </div>
        <ul translate="no" id="allCountries" class="allCountries"></ul>
    </div>
    <?php
    return ob_get_clean(); // Return buffered content
}
add_shortcode('google_translator_for_wp', 'translator_shortcode');

// 

// Switcher Murkup


