<?php
/**
 * Convert WooCommerce product prices based on the selected currency.
 *
 * @param float $price The original product price.
 * @param object $product The WooCommerce product object.
 * @return float The converted price.
 */
 global  $woocommerce;
function currency_symbols_array_return() {
    return [
    "AED" => "د.إ", // UAE Dirham
    "AFN" => "؋", // Afghan Afghani
    "ALL" => "L", // Albanian Lek
    "AMD" => "֏", // Armenian Dram
    "ANG" => "ƒ", // Netherlands Antillean Guilder
    "AOA" => "Kz", // Angolan Kwanza
    "ARS" => "$", // Argentine Peso
    "AUD" => "A$", // Australian Dollar
    "AWG" => "ƒ", // Aruban Florin
    "AZN" => "₼", // Azerbaijani Manat
    "BAM" => "KM", // Bosnia-Herzegovina Convertible Mark
    "BBD" => "Bds$", // Barbadian Dollar
    "BDT" => "৳", // Bangladeshi Taka
    "BGN" => "лв", // Bulgarian Lev
    "BHD" => ".د.ب", // Bahraini Dinar
    "BIF" => "FBu", // Burundian Franc
    "BMD" => "$", // Bermudian Dollar
    "BND" => "B$", // Brunei Dollar
    "BOB" => "Bs.", // Bolivian Boliviano
    "BRL" => "R$", // Brazilian Real
    "BSD" => "B$", // Bahamian Dollar
    "BTN" => "Nu.", // Bhutanese Ngultrum
    "BWP" => "P", // Botswana Pula
    "BYN" => "Br", // Belarusian Ruble
    "BZD" => "BZ$", // Belize Dollar
    "CAD" => "C$", // Canadian Dollar
    "CDF" => "FC", // Congolese Franc
    "CHF" => "CHF", // Swiss Franc
    "CLP" => "$", // Chilean Peso
    "CNY" => "¥", // Chinese Yuan
    "COP" => "$", // Colombian Peso
    "CRC" => "₡", // Costa Rican Colón
    "CUP" => "$", // Cuban Peso
    "CVE" => "$", // Cape Verdean Escudo
    "CZK" => "Kč", // Czech Koruna
    "DJF" => "Fdj", // Djiboutian Franc
    "DKK" => "kr", // Danish Krone
    "DOP" => "RD$", // Dominican Peso
    "DZD" => "دج", // Algerian Dinar
    "EGP" => "£", // Egyptian Pound
    "ERN" => "Nfk", // Eritrean Nakfa
    "ETB" => "Br", // Ethiopian Birr
    "EUR" => "€", // Euro
    "FJD" => "$", // Fijian Dollar
    "FKP" => "£", // Falkland Islands Pound
    "FOK" => "kr", // Faroese Króna
    "GBP" => "£", // British Pound Sterling
    "GEL" => "₾", // Georgian Lari
    "GGP" => "£", // Guernsey Pound
    "GHS" => "₵", // Ghanaian Cedi
    "GIP" => "£", // Gibraltar Pound
    "GMD" => "D", // Gambian Dalasi
    "GNF" => "FG", // Guinean Franc
    "GTQ" => "Q", // Guatemalan Quetzal
    "GYD" => "$", // Guyanese Dollar
    "HKD" => "HK$", // Hong Kong Dollar
    "HNL" => "L", // Honduran Lempira
    "HRK" => "kn", // Croatian Kuna
    "HTG" => "G", // Haitian Gourde
    "HUF" => "Ft", // Hungarian Forint
    "IDR" => "Rp", // Indonesian Rupiah
    "ILS" => "₪", // Israeli New Shekel
    "IMP" => "£", // Isle of Man Pound
    "INR" => "₹", // Indian Rupee
    "IQD" => "ع.د", // Iraqi Dinar
    "IRR" => "﷼", // Iranian Rial
    "ISK" => "kr", // Icelandic Króna
    "JEP" => "£", // Jersey Pound
    "JMD" => "J$", // Jamaican Dollar
    "JOD" => "د.ا", // Jordanian Dinar
    "JPY" => "¥", // Japanese Yen
    "KES" => "KSh", // Kenyan Shilling
    "KGS" => "с", // Kyrgyzstani Som
    "KHR" => "៛", // Cambodian Riel
    "KID" => "$", // Kiribati Dollar
    "KMF" => "CF", // Comorian Franc
    "KRW" => "₩", // South Korean Won
    "KWD" => "د.ك", // Kuwaiti Dinar
    "KYD" => "CI$", // Cayman Islands Dollar
    "KZT" => "₸", // Kazakhstani Tenge
    "LAK" => "₭", // Lao Kip
    "LBP" => "ل.ل", // Lebanese Pound
    "LKR" => "Rs", // Sri Lankan Rupee
    "LRD" => "$", // Liberian Dollar
    "LSL" => "L", // Lesotho Loti
    "LYD" => "ل.د", // Libyan Dinar
    "MAD" => "د.م.", // Moroccan Dirham
    "MDL" => "L", // Moldovan Leu
    "MGA" => "Ar", // Malagasy Ariary
    "MKD" => "ден", // Macedonian Denar
    "MMK" => "Ks", // Myanmar Kyat
    "MNT" => "₮", // Mongolian Tögrög
    "MOP" => "MOP$", // Macanese Pataca
    "MRU" => "UM", // Mauritanian Ouguiya
    "MUR" => "₨", // Mauritian Rupee
    "MVR" => "Rf", // Maldivian Rufiyaa
    "MWK" => "MK", // Malawian Kwacha
    "MXN" => "$", // Mexican Peso
    "MYR" => "RM", // Malaysian Ringgit
    "MZN" => "MT", // Mozambican Metical
    "NAD" => "$", // Namibian Dollar
    "NGN" => "₦", // Nigerian Naira
    "NIO" => "C$", // Nicaraguan Córdoba
    "NOK" => "kr", // Norwegian Krone
    "NPR" => "Rs", // Nepalese Rupee
    "NZD" => "NZ$", // New Zealand Dollar
    "OMR" => "ر.ع.", // Omani Rial
    "PAB" => "B/.", // Panamanian Balboa
    "PEN" => "S/", // Peruvian Sol
    "PGK" => "K", // Papua New Guinean Kina
    "PHP" => "₱", // Philippine Peso
    "PKR" => "₨", // Pakistani Rupee
    "PLN" => "zł", // Polish Zloty
    "PYG" => "₲", // Paraguayan Guarani
    "QAR" => "ر.ق", // Qatari Rial
    "RON" => "lei", // Romanian Leu
    "RSD" => "дин", // Serbian Dinar
    "RUB" => "₽", // Russian Ruble
    "RWF" => "FRw", // Rwandan Franc
    "SAR" => "﷼", // Saudi Riyal
    "SBD" => "$", // Solomon Islands Dollar
    "SCR" => "₨", // Seychellois Rupee
    "SDG" => "ج.س.", // Sudanese Pound
    "SEK" => "kr", // Swedish Krona
    "SGD" => "$", // Singapore Dollar
    "SHP" => "£", // Saint Helena Pound
    "SLL" => "Le", // Sierra Leonean Leone
    "SOS" => "Sh", // Somali Shilling
    "SRD" => "$", // Surinamese Dollar
    "SSP" => "£", // South Sudanese Pound
    "STN" => "Db", // São Tomé and Príncipe Dobra
    "SYP" => "ل.س", // Syrian Pound
    "SZL" => "L", // Eswatini Lilangeni
    "THB" => "฿", // Thai Baht
    "TJS" => "ЅМ", // Tajikistani Somoni
    "TMT" => "m", // Turkmenistani Manat
    "TND" => "د.ت", // Tunisian Dinar
    "TOP" => "T$", // Tongan Paʻanga
    "TRY" => "₺", // Turkish Lira
    "TTD" => "TT$", // Trinidad and Tobago Dollar
    "TVD" => "$", // Tuvaluan Dollar
    "TWD" => "NT$", // New Taiwan Dollar
    "TZS" => "TSh", // Tanzanian Shilling
    "UAH" => "₴", // Ukrainian Hryvnia
    "UGX" => "USh", // Ugandan Shilling
    "USD" => "$", // United States Dollar
    "UYU" => "U$", // Uruguayan Peso
    "UZS" => "сум", // Uzbekistani Som
    "VES" => "Bs.", // Venezuelan Bolívar
    "VND" => "₫", // Vietnamese Dong
    "VUV" => "VT", // Vanuatu Vatu
    "WST" => "WS$", // Samoan Tala
    "XAF" => "FCFA", // Central African CFA Franc
    "XCD" => "EC$", // East Caribbean Dollar
    "XOF" => "CFA", // West African CFA Franc
    "XPF" => "₣", // CFP Franc
    "YER" => "﷼", // Yemeni Rial
    "ZAR" => "R", // South African Rand
    "ZMW" => "K", // Zambian Kwacha
    "ZWL" => "Z$" // Zimbabwean Dollar
];
}
function bhwd_convert_currency_price($price, $product) {
    // Get the default WooCommerce currency
    $default_currency = get_option('woocommerce_currency');

    // Get the selected currency from the cookie, or fallback to the default currency
    $selected_currency = isset($_COOKIE['bhwd_currency']) ? sanitize_text_field($_COOKIE['bhwd_currency']) : $default_currency;

    // Retrieve the exchange rate from the cookie and ensure it's numeric
    $exchange_rate = isset($_COOKIE['bhwd_exchange_rate']) ? floatval($_COOKIE['bhwd_exchange_rate']) : 1;

    // Debugging: Log the selected currency and exchange rate
    error_log("Selected Currency: $selected_currency");
    error_log("Exchange Rate: $exchange_rate");

    // Check if the price is numeric, and apply the exchange rate
    if (is_numeric($price) && $exchange_rate > 0) {
        error_log("Converting $price using rate $exchange_rate");
        $price *= $exchange_rate; // Apply the exchange rate to the price
    } else {
        error_log("Invalid price or exchange rate.");
    }

    return $price;
}

// Add WooCommerce filters to dynamically modify product prices
add_filter('woocommerce_product_get_price', 'bhwd_convert_currency_price', 10, 2);
add_filter('woocommerce_product_get_regular_price', 'bhwd_convert_currency_price', 10, 2);
add_filter('woocommerce_product_get_sale_price', 'bhwd_convert_currency_price', 10, 2);

/**
 * Change the WooCommerce currency symbol based on the selected currency.
 *
 * @param string $currency_symbol The original currency symbol.
 * @param string $currency The original currency code.
 * @return string The modified currency symbol.
 */
function bhwd_change_currency_symbol($currency_symbol, $currency) {

    $bhwd_currency = get_option('woocommerce_currency');

    // Get the selected currency symbol from the cookie, or fallback to the default symbol
    $selected_currency_symbol = '';
    if( isset($_COOKIE['bhwd_currency_symbole'])) { 
        $selected_currency_symbol = sanitize_text_field($_COOKIE['bhwd_currency_symbole']) ;
    } else {
        $symboles =currency_symbols_array_return();
       $selected_currency_symbol = $symboles[$bhwd_currency];
       
    }

    return $selected_currency_symbol ?? $currency_symbol;
}

// Add WooCommerce filter to dynamically modify the currency symbol
add_filter('woocommerce_currency_symbol', 'bhwd_change_currency_symbol', 10, 2);



function bhwd_switcher_markup(){
    $default_currency = get_option('woocommerce_currency');

    // Get the selected currency from the cookie, or fallback to the default currency
    $selected_currency = isset($_COOKIE['bhwd_currency']) ? sanitize_text_field($_COOKIE['bhwd_currency']) : $default_currency;
    $bhwd_country_name = isset($_COOKIE['country_name']) ? sanitize_text_field($_COOKIE['country_name']) : 'Italy';
    $bhwd_counntry_code = isset($_COOKIE['country_code']) ? sanitize_text_field($_COOKIE['country_code']) : 'it';

    // Get the selected currency symbol from the cookie, or fallback to the default symbol
    $selected_currency_symbol = '';
    if( isset($_COOKIE['bhwd_currency_symbole'])) { 
        $selected_currency_symbol = sanitize_text_field($_COOKIE['bhwd_currency_symbole']) ;
    } else {
        $symboles =currency_symbols_array_return();
       $selected_currency_symbol = $symboles[$selected_currency];
       
    }
  ?>
     <button translate="no" class="bhwdTranslateButton bhwd-Active-deactive-translate-popup" ><span><img src="https://flagcdn.com/16x12/<?php echo $bhwd_counntry_code  ; ?>.png" alt=""></span><span><?php echo $bhwd_country_name . ' / ' . $bhwd_counntry_code  . '   ( ' . $selected_currency_symbol . ' )';  ?> </span></button>
<div class="bhwd_translator_conatiner_main">
         <div class="bhwd-overly-translate bhwd-Active-deactive-translate-popup" >

         </div>
        <div  class="bhwd_mb_filter_conatiner" >
            <div class="bhwd_popup_close" >
                <button class="bhwd-Active-deactive-translate-popup" >
                    <i class="fa fa-close" aria-hidden="true"></i>
                </button>
            </div>
        <div>
            <select name="bhwd_switch_country" id="bhwd_switch_country" translate="no"  >
                
        </select>
        </div>
        <div>
            <select name="bhwd_switch_lg" id="bhwd_switch_lg" translate="no"  > </select>
        </div>
        <div>
            <select name="bhwd_switch_currenchy" id="bhwd_switch_currenchy" translate="no"  >
                
            </select>
        </div>

        <div class="bhwdButtonGrup">
            <button filepath="<?php echo plugin_dir_url(__FILE__) ; ?>" class="bhwdSwitcher" id="bhwdSwitcher" >
                Switch
            </button>

        </div>
    </div>
</div>
  <?php
}



// Switcher: change Currency , language , Country
function switcherCurrencyLanguageCountry(){
    ob_start();
    // Get the current WooCommerce currency
    bhwd_switcher_markup();
    return ob_get_clean();
}


add_shortcode('bhwd_switcher', 'switcherCurrencyLanguageCountry');