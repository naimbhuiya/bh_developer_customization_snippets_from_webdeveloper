<?php 

// The file Incluedes in form Scheda Clienti
require_once(plugin_dir_path(__FILE__) . 'sing-up/index.php');

// The file Incluedes in form sing in , sing up
require_once(plugin_dir_path(__FILE__) . 'sing-in/index.php');


function bhwd_add_user_meta_box($user) {
    ?>
    <h3>Additional Information</h3>
    <table class="form-table">
        <tr>
            <th><label for="phone_number">Phone Number</label></th>
            <td>
                <input type="text" name="phone_number" id="phone_number" 
                    value="<?php echo esc_attr(get_the_author_meta('phone_number', $user->ID)); ?>" 
                    class="regular-text" />
                <p class="description">Enter your phone number.</p>
            </td>
        </tr>
        <tr>
            <th><label for="birthday">User Birthday</label></th>
            <td>
                <input type="date" name="birthday" id="birthday" 
                    value="<?php echo esc_attr(get_the_author_meta('birthday', $user->ID)); ?>" 
                    class="regular-text" />
                <p class="description">Enter your birthday.</p>
            </td>
        </tr>
    </table>
    <?php
}
add_action('show_user_profile', 'bhwd_add_user_meta_box');  // For user's own profile
add_action('edit_user_profile', 'bhwd_add_user_meta_box');  // For admin editing other users