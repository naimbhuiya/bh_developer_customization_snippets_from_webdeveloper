<?php 

function bhwd_verifyusername_(){

    $username = $_POST["username"] ;

    if(username_exists( $username )){
        wp_send_json( [
            "isValid" => false ,
            "msg" => "Username is already taken."
        ] );
    }else{
          wp_send_json( [
            "isValid" => true ,
            "msg" => "Username is availavle"
        ] );
    }

}

add_action( "wp_ajax_bhwd_verifyusername", "bhwd_verifyusername_" );
add_action( "wp_ajax_nopriv_bhwd_verifyusername", "bhwd_verifyusername_" );

