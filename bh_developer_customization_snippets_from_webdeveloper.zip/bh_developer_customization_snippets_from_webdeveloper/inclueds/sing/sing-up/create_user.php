<?php 



function bhwd_create_user() {
    // Verify the nonce for security
    // if (!isset($_POST['security']) || !wp_verify_nonce($_POST['security'], 'bhwd_nonce_action')) {
    //     wp_send_json_error(array('message' => 'Nonce verification failed.'));
    //     return;
    // }

    // Retrieve POST data
    $form_data = $_POST['formData'];

    // Basic validation
    if (empty($form_data["firstName"]) || empty($form_data["lastName"]) || empty($form_data["username"]) || empty($form_data["date"]) || empty($form_data["email"]) || empty($form_data["phoneNumber"]) || empty($form_data["confirmPassword"])) {
        wp_send_json_error(array('message' => 'All fields are required.'));
        return;
    }

    if(is_user_logged_in()){
        wp_send_json_error(
            array(
                "isValid" => "warn",
                'msg' => 'User already logged in.'
            )
        );
        return;
    }

    // Check if the username or email already exists
    if (username_exists($form_data["username"])) {
        wp_send_json_error(
            array(
                "isValid" => "warn",
                'msg' => 'Username already exists.'
            )
        );
        return;
    }

    if (email_exists($form_data["email"])) {
        wp_send_json_error(
            array(
                "isValid" => "warn",
                'msg' => 'Email already exists.'
            )
        );
        return;
    }

    $bhwd_otp_code = get_transient( "bhwd_otp_" . sanitize_email($form_data["email"]));
    if(!$bhwd_otp_code){
        wp_send_json_error(
            array(
                "isValid" => "warn",
                'msg' => 'Otp code is expire.'
            )
        );
        return;
    }
    if($bhwd_otp_code != $form_data['otpCode'] ){
        wp_send_json_error(
            array(
                "isValid" => "err",
                'msg' => 'Otp code is invalid.'
            )
        );
        return;
    };

    // Create the user
    $user_id = wp_create_user($form_data["username"], $form_data["confirmPassword"], $form_data["email"]);

    // Check if user creation was successful
    if (is_wp_error($user_id)) {
        wp_send_json_error(
            array(
                "isValid" => "err",
                'msg' => 'Error creating user.'
                )
        );
        return;
    }

    // Set first and last name
    wp_update_user(array(
        'ID' => $user_id,
        'first_name' => $form_data["firstName"],
        'last_name' => $form_data["lastName"],
    ));

    // Set custom user meta data (e.g., birthday, phone number)
    update_user_meta($user_id, 'birthday', $form_data["date"]);
    update_user_meta($user_id, 'phone_number', $form_data["phoneNumber"]);

    $nickname = $form_data["firstName"] . " " . $form_data["lastName"] ;
    update_user_meta( $user_id, "nickname", $nickname );

    update_user_meta( $user_id, "display_name", $nickname );

    if (function_exists('wc_get_product')) {
        update_user_meta( $user_id, "billing_phone", $form_data["phoneNumber"] );
        update_user_meta( $user_id, "shipping_phone", $form_data["phoneNumber"] );
    }


    // Optionally, you can assign a role here if needed
    $user = new WP_User($user_id);
    $user->set_role('subscriber');  // Set role, default is subscriber
    delete_transient( $bhwd_otp_code  );
    // Respond with success
    wp_send_json_success(
        array(
            "isValid" => "success",
            'msg' => 'User created successfully.'
            )
    );
}


add_action('wp_ajax_bhwd_create_user', 'bhwd_create_user');
add_action('wp_ajax_nopriv_bhwd_create_user', 'bhwd_create_user');  // For non-logged in users as well



