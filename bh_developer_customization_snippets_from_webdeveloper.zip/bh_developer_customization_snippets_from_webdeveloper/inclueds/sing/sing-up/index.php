<?php

// Verify username
require_once(plugin_dir_path(__FILE__) . 'verify_username.php');

// Send otp
require_once(plugin_dir_path(__FILE__) . 'send_otp.php');

// Create user
require_once(plugin_dir_path(__FILE__) . 'create_user.php');

// function bhwd_sing_in_enqueue_scripts() {
//     // Define the plugin directory URL
//     $plugin_url = plugin_dir_url(__FILE__);

//     // Enqueue CSS
//     wp_enqueue_style('bhwd-style', $plugin_url . 'style.css', array(), '1.0.0', 'all');

//     // Enqueue JavaScript
//     wp_enqueue_script('bhwd-script', $plugin_url . 'script.js', array('jquery'), '1.0.0', true);
//     $url = "";
//     if(function_exists('wc_get_product')){
//       $url = wc_get_page_permalink( 'myaccount' );
//     }
//     // Pass Ajax URL to script.js (only if needed)
//     wp_localize_script('bhwd-script', 'bhwd_ajax', array(
//       'ajax_url' => admin_url('admin-ajax.php'),
//       "login_url" => $url ? $url : wp_login_url()
//     ));
// }
// add_action('wp_enqueue_scripts', 'bhwd_sing_in_enqueue_scripts'); // Enqueue for frontend0

function bhwd_add_login_registration_admin_menu() {
    add_submenu_page(
        'bhdcsfw-bh-customaization',    // Parent menu slug (ensure this menu exists)
        'Login registration',         // Page title
        'Login registration',         // Submenu title
        'manage_options',               // Capability required to access this menu
        'bhwd-login-registration',             // Menu slug
        'bhwd_login_registration_admin_page'  // Callback function to display the page content
    );
}
add_action('admin_menu', 'bhwd_add_login_registration_admin_menu');


function bhwd_login_registration_admin_page(){
  echo "Login Registration page!" ;
}


function bhwd_registration_form(){
    ob_start();
    if(!is_user_logged_in()){

    //  echo plugin_dir_url(__FILE__);
      $plugin_url = plugin_dir_url(__FILE__);
       $url = "";
    if(function_exists('wc_get_product')){
      $url = wc_get_page_permalink( 'myaccount' );
    }
    ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title><?php echo get_bloginfo('name'); ?></title>
      <link rel="stylesheet" href="<?php echo  $plugin_url . 'style.css' ; ?>">
      <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css" integrity="sha512-Evv84Mr4kqVGRNSgIGL/F/aIDqQb7xQ2vcrdIwxfjThSH8CSR7PBEakCr51Ck+w+/U6swU2Im1vVX0SVk9ABhg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
      <script>
        let bhwd_ajax = {
          ajax_url: "<?php echo admin_url('admin-ajax.php'); ?>",
          login_url : "<?php echo $url ? $url : wp_login_url(); ?>"
        }
      </script>

    </head>
    <body>

      <div class="container bhwd_container mt-5">
        <div class="d-flex align-items-center justify-content-between">
          <!-- Title section -->
          <div class="title">Registration</div>

          <p class="bhwd_login">
            <a href="<?php echo wp_login_url(); ?>"><i class="fa-solid fa-arrow-left"></i> Login</a>
          </p>
        </div>
        
      
      <div class="content">
        <!-- Registration form -->
        <form id="bhwd_registation_form" action="#">
          <div class="user-details" id="user-details">
            <!-- Input for First Name -->
            <div class="input-box">
              <span class="details">First Name</span>
              <input
                class="bhwdFormFieldsData"
                type="text"
                name="frist-name"
                placeholder="Enter your name"
                required
              />
              <br />
              <span class="bhwdErrText">First name is empty. </span>
            </div>

            <!-- Input for Last Name -->
            <div class="input-box">
              <span class="details">Last Name</span>
              <input
                class="bhwdFormFieldsData"
                type="text"
                name="last-name"
                placeholder="Enter your name"
                required
              /><br />
              <span class="bhwdErrText">Last name is empty. </span>
            </div>
            <!-- Input for Username -->
            <div class="input-box">
              <span class="details">Username</span>
              <input
                class="bhwdFormFieldsData"
                type="username"
                name="username"
                placeholder="Enter your username"
                required
              /><br />
              <!-- bhwdCheckValidateUserName -->
              <span class="bhwdErrText">username is empty</span>
            </div>

            <!-- Input for Username -->
            <div class="input-box">
              <span class="details">Birthday</span>
              <input
                class="bhwdFormFieldsData"
                type="date"
                name="date"
                placeholder="Enter your date"
                required
              />
              <br />
              <span class="bhwdErrText"> Birthday is empty. </span>
            </div>

            <!-- Input for Email -->
            <div class="input-box">
              <span class="details">Email</span>
              <input
                class="bhwdFormFieldsData"
                type="email"
                name="email"
                placeholder="Enter your email"
                required
              /><br />
              <span class="bhwdErrText"> Email is empty. </span>
            </div>
            <!-- Input for Phone Number -->
            <div class="input-box">
              <span class="details">Phone Number</span>
              <input
                class="bhwdFormFieldsData"
                type="tel"
                name="phone-number"
                placeholder="Enter your number"
                required
              /><br />
              <span class="bhwdErrText"> Phone number is empty. </span>
            </div>

            <!-- Input your codes -->
            <div class="input-box">
              <span class="details">-</span>
              <button
                type="button"
                id="bhwdSendOtp"
                placeholder="Send OTP"
                value="Send OTP"
                required
              >
                <span>Send OTP</span>
                <span><i class="fa-solid fa-check"></i></span>
              </button>
            </div>
            <!-- Input your codes -->
            <div class="input-box">
              <span class="details">Your OTP</span>
              <input
                class="bhwdFormFieldsData"
                type="otp-code"
                name="otp-code"
                placeholder="Enter your OTP"
                required
              /><br />
              <span class="bhwdErrText"> Not send code. </span>
            </div>

            <!-- Input for Password -->
            <div class="input-box">
              <span class="details"
                >Password
                <button
                  class="bhwd-tooltip border-0 bg-transparent"
                  type="button"
                  data="password"
                  style="padding: 0;"
                >
                  <i class="fa-solid fa-circle-info"></i></button
              ></span>
              <input
                class="bhwdFormFieldsData"
                type="password"
                type-data="password"
                name="password"
                placeholder="Enter your password"
                required
              /><br />
              <span class="bhwdErrText"> Password is invalid. </span>
            </div>
            <!-- Input for Confirm Password -->
            <div class="input-box">
              <span class="details">Confirm Password </span>
              <input
                class="bhwdFormFieldsData"
                type="password"
                type-data="conf-password"
                name="conf-password"
                placeholder="Confirm your password"
                required
              /><br />
              <span class="bhwdErrText"> Password field is empty. </span>
            </div>
          </div>
          <div class="gender-details">
            <!-- Radio buttons for gender selection -->
            <input
              type="radio"
              class="bhwdFormFieldsData"
              checked
              data-gender="Male"
              name="gender"
              id="dot-1"
            />
            <input
              class="bhwdFormFieldsData"
              type="radio"
              data-gender="Female"
              name="gender"
              id="dot-2"
            />
            <input
              class="bhwdFormFieldsData"
              type="radio"
              data-gender="Others"
              name="gender"
              id="dot-3"
            />
            <span class="" class="gender-title">Gender</span>
            <div class="category">
              <!-- Label for Male -->
              <label for="dot-1">
                <span class="dot one"></span>
                <span class="gender">Male</span>
              </label>
              <!-- Label for Female -->
              <label for="dot-2">
                <span class="dot two"></span>
                <span class="gender">Female</span>
              </label>
              <!-- Label for Prefer not to say -->
              <label for="dot-3">
                <span class="dot three"></span>
                <span class="gender">Prefer not to say</span>
              </label>
            </div>
          </div>
          <!-- Submit button -->
          <div class="bhwd_reg_button">
            <input
              type="button"
              id="bhwdFormDataSubmit"
              data="submit"
              value="Register"
            />
          </div>
        </form>
      </div>
    </div>
    <script src="<?php echo includes_url('js/jquery/jquery.js'); ?>"></script>
    <script src="<?php echo  $plugin_url . 'script.js' ; ?>"></script>
    </body>
    </html>
    <?php
    }else{
      $current_user = wp_get_current_user();
      ?>
      <div class="container">
        <p>
          user is logged in already!
        </p>
        <h2 class="bhwd_username">
        <?php 
        echo $current_user->user_login ;
        ?>
        </h2>
        <p>
          <a href="">Go</a>
        </p>
      </div>
      <?php
    }
    return ob_get_clean(); // Return buffered content
};

add_shortcode( "bhwd_registraion", "bhwd_registration_form");
add_action('login_form_register', 'bhwd_custom_registration_form');

function bhwd_custom_registration_form() {
    if (!is_user_logged_in()) {
      // echo bhwd_registration_form();
      echo do_shortcode( "[bhwd_registraion]" );
       // wp_redirect(home_url('/custom-registration')); // Redirect to your custom registration page
        exit;
    } else {
        wp_redirect(home_url()); // If already logged in, redirect to home
        exit;
    }
}

// add_shortcode( "bhwd_registraion", "bhwd_registration_form");