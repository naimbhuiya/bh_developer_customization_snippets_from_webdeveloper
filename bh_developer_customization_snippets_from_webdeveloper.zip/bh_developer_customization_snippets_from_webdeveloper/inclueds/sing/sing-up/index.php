<?php

// Verify username
require_once(plugin_dir_path(__FILE__) . 'verify_username.php');

// Send otp
require_once(plugin_dir_path(__FILE__) . 'send_otp.php');

// Create user
require_once(plugin_dir_path(__FILE__) . 'create_user.php');

function bhwd_sing_in_enqueue_scripts() {
    // Define the plugin directory URL
    $plugin_url = plugin_dir_url(__FILE__);

    // Enqueue CSS
    wp_enqueue_style('bhwd-style', $plugin_url . 'style.css', array(), '1.0.0', 'all');

    // Enqueue JavaScript
    wp_enqueue_script('bhwd-script', $plugin_url . 'script.js', array('jquery'), '1.0.0', true);
    $url = "";
    if(function_exists('wc_get_product')){
      $url = wc_get_page_permalink( 'myaccount' );
    }
    // Pass Ajax URL to script.js (only if needed)
    wp_localize_script('bhwd-script', 'bhwd_ajax', array(
      'ajax_url' => admin_url('admin-ajax.php'),
      "login_url" => $url ? $url : wp_login_url()
    ));
}
add_action('wp_enqueue_scripts', 'bhwd_sing_in_enqueue_scripts'); // Enqueue for frontend0

function bhwd_add_login_registration_admin_menu() {
    add_submenu_page(
        'bhdcsfw-bh-customaization',    // Parent menu slug (ensure this menu exists)
        'Login registration',         // Page title
        'Login registration',         // Submenu title
        'manage_options',               // Capability required to access this menu
        'bhwd-login-registration',             // Menu slug
        'bhwd_login_registration_admin_page'  // Callback function to display the page content
    );
}
add_action('admin_menu', 'bhwd_add_login_registration_admin_menu');


function bhwd_login_registration_admin_page(){
  echo "Login Registration page!" ;
}


function bhwd_registration_form(){
    ob_start();
    if(!is_user_logged_in()){
      
    ?>
    
    <div class="container">
      <!-- Title section -->
      <div class="title">Registration</div>
      <div class="content">
        <!-- Registration form -->
        <form id="bhwd_registation_form" action="#">
          <div class="user-details">
            <!-- Input for First Name -->
            <div class="input-box">
              <span class="details">First Name</span>
              <input
                class="bhwdFormFieldsData"
                type="text"
                name="frist-name"
                placeholder="Enter your name"
                required
              />
              <br />
              <span class="bhwdErrText">First name is empty. </span>
            </div>

            <!-- Input for Last Name -->
            <div class="input-box">
              <span class="details">Last Name</span>
              <input
                class="bhwdFormFieldsData"
                type="text"
                name="last-name"
                placeholder="Enter your name"
                required
              /><br />
              <span class="bhwdErrText">Last name is empty. </span>
            </div>
            <!-- Input for Username -->
            <div class="input-box">
              <span class="details">Username</span>
              <input
                class="bhwdFormFieldsData"
                type="username"
                name="username"
                placeholder="Enter your username"
                required
              /><br />
              <!-- bhwdCheckValidateUserName -->
              <span class="bhwdErrText">username is empty</span>
            </div>

            <!-- Input for Username -->
            <div class="input-box">
              <span class="details">Birthday</span>
              <input
                class="bhwdFormFieldsData"
                type="date"
                name="date"
                placeholder="Enter your date"
                required
              />
              <br />
              <span class="bhwdErrText"> Birthday is empty. </span>
            </div>

            <!-- Input for Email -->
            <div class="input-box">
              <span class="details">Email</span>
              <input
                class="bhwdFormFieldsData"
                type="email"
                name="email"
                placeholder="Enter your email"
                required
              /><br />
              <span class="bhwdErrText"> Email is empty. </span>
            </div>
            <!-- Input for Phone Number -->
            <div class="input-box">
              <span class="details">Phone Number</span>
              <input
                class="bhwdFormFieldsData"
                type="tel"
                name="phone-number"
                placeholder="Enter your number"
                required
              /><br />
              <span class="bhwdErrText"> Phone number is empty. </span>
            </div>

            <!-- Input your codes -->
            <div class="input-box">
              <span class="details">-</span>
              <button
                type="button"
                id="bhwdSendOtp"
                placeholder="Send OTP"
                value="Send OTP"
                required
              >
                <span>Send OTP</span>
                <span><i class="fa-solid fa-check"></i></span>
              </button>
            </div>
            <!-- Input your codes -->
            <div class="input-box">
              <span class="details">Your OTP</span>
              <input
                class="bhwdFormFieldsData"
                type="otp-code"
                name="otp-code"
                placeholder="Enter your OTP"
                required
              /><br />
              <span class="bhwdErrText"> Not send code. </span>
            </div>

            <!-- Input for Password -->
            <div class="input-box">
              <span class="details"
                >Password
                <button
                  class="bhwd-tooltip border-0 bg-transparent"
                  type="button"
                  data="password"
                  style="padding: 0;"
                >
                  <i class="fa-solid fa-circle-info"></i></button
              ></span>
              <input
                class="bhwdFormFieldsData"
                type="password"
                type-data="password"
                name="password"
                placeholder="Enter your password"
                required
              /><br />
              <span class="bhwdErrText"> Password is invalid. </span>
            </div>
            <!-- Input for Confirm Password -->
            <div class="input-box">
              <span class="details">Confirm Password </span>
              <input
                class="bhwdFormFieldsData"
                type="password"
                type-data="conf-password"
                name="conf-password"
                placeholder="Confirm your password"
                required
              /><br />
              <span class="bhwdErrText"> Password field is empty. </span>
            </div>
          </div>
          <div class="gender-details">
            <!-- Radio buttons for gender selection -->
            <input
              type="radio"
              class="bhwdFormFieldsData"
              checked
              data-gender="Male"
              name="gender"
              id="dot-1"
            />
            <input
              class="bhwdFormFieldsData"
              type="radio"
              data-gender="Female"
              name="gender"
              id="dot-2"
            />
            <input
              class="bhwdFormFieldsData"
              type="radio"
              data-gender="Others"
              name="gender"
              id="dot-3"
            />
            <span class="" class="gender-title">Gender</span>
            <div class="category">
              <!-- Label for Male -->
              <label for="dot-1">
                <span class="dot one"></span>
                <span class="gender">Male</span>
              </label>
              <!-- Label for Female -->
              <label for="dot-2">
                <span class="dot two"></span>
                <span class="gender">Female</span>
              </label>
              <!-- Label for Prefer not to say -->
              <label for="dot-3">
                <span class="dot three"></span>
                <span class="gender">Prefer not to say</span>
              </label>
            </div>
          </div>
          <!-- Submit button -->
          <div class="bhwd_reg_button">
            <input
              type="button"
              id="bhwdFormDataSubmit"
              data="submit"
              value="Register"
            />
          </div>
        </form>
      </div>
    </div>
    
    <?php
    }else{
      $current_user = wp_get_current_user();
      ?>
      <div class="container">
        <p>
          user is logged in already!
        </p>
        <h2 class="bhwd_username">
        <?php 
        echo $current_user->user_login ;
        ?>
        </h2>
        <p>
          <a href="">Go</a>
        </p>
      </div>
      <?php
    }
    return ob_get_clean(); // Return buffered content
};


add_shortcode( "bhwd_registraion", "bhwd_registration_form");