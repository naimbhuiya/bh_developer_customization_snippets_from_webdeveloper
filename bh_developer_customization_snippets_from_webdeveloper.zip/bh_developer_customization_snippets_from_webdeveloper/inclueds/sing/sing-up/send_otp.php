<?php 
// Generate and send OTP
function bhwd_send_otp() {
    if (!isset($_POST['email'])) {
        wp_send_json_error(['msg' => 'Email is required']);
    }

    $email = sanitize_email($_POST['email']);
    if (!is_email($email)) {
        wp_send_json_error(['msg' => 'Invalid email address']);
        return;
    }

    if(email_exists( $email )){
        wp_send_json_error(['msg' => 'Already exist user.']);
        return;
    }

    // Generate a 6-digit OTP
    $otp = wp_rand(100000, 999999);

    // Store OTP in a transient for 5 minutes
    set_transient("bhwd_otp_" . $email , $otp, 5 * MINUTE_IN_SECONDS);

    // Email subject & body
    $subject = "Your OTP Code";
    $message = "Your OTP code is: <strong>$otp</strong>. It is valid for 5 minutes.";

    // Send OTP via WordPress mail
    $headers = ['Content-Type: text/html; charset=UTF-8'];
    $sent = wp_mail($email, $subject, $message, $headers);

    if ($sent) {
        wp_send_json_success(['msg' => 'OTP sent successfully']);
    } else {
        wp_send_json_error(['msg' => 'Failed to send OTP']);
    }
}

// Register AJAX action for sending OTP
add_action("wp_ajax_bhwd_send_otp", "bhwd_send_otp");
add_action("wp_ajax_nopriv_bhwd_send_otp", "bhwd_send_otp");