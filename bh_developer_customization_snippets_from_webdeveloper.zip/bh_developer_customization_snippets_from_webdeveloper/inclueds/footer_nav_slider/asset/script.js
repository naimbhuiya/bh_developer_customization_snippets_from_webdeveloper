document.addEventListener("DOMContentLoaded", function () {
  if (document.querySelector(".bhwd-items")) {
    const rightButton = document.querySelector(".bhwd-rightSlidingArrowButton");
    const leftButton = document.querySelector(".bhwd-leftSlidingArrowButton");
    const items = document.querySelector(".bhwd-items");
    let isDragging = false;
    let startX;
    let intervalId;

    const startDragging = (e) => {
      isDragging = true;
      startX = e.type === "touchstart" ? e.touches[0].clientX : e.clientX;
    };

    const dragging = (e) => {
      if (!isDragging) return;
      const currentX =
        e.type === "touchmove" ? e.touches[0].clientX : e.clientX;
      const diffX = currentX - startX;
      items.scrollLeft -= diffX;
      startX = currentX;
      items.style.scrollBehavior = "auto";
    };

    const stopDragging = () => {
      isDragging = false;
      items.style.scrollBehavior = "smooth";
    };

    const autoScrollingControl = () => {
      if (items.scrollLeft + items.clientWidth >= items.scrollWidth) {
        items.scrollLeft = 0;
      } else {
        items.scrollLeft += 140;
      }
    };

    const leftButtonControl = () => {
      items.scrollLeft -= 140;
      if (items.scrollLeft <= 0) {
        items.scrollLeft = items.scrollWidth - items.clientWidth;
      }
    };

    const restartAutoScrolling = () => {
      clearInterval(intervalId);
      intervalId = setInterval(autoScrollingControl, 3000);
    };

    rightButton.addEventListener("click", () => {
      autoScrollingControl();
      restartAutoScrolling();
    });

    leftButton.addEventListener("click", () => {
      leftButtonControl();
      restartAutoScrolling();
    });

    items.addEventListener("mousedown", startDragging);
    items.addEventListener("touchstart", startDragging);
    document.addEventListener("mousemove", dragging);
    document.addEventListener("touchmove", dragging);
    document.addEventListener("mouseup", stopDragging);
    document.addEventListener("touchend", stopDragging);

    restartAutoScrolling();
  } else {
    console.log("You Not have Current Class...");
  }
});
